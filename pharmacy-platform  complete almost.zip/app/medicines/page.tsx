"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ShoppingCart, Search, Filter, Plus, Minus, Heart, Star } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Medicine {
  id: string
  name: string
  generic_name?: string
  manufacturer: string
  category: string
  price: number
  description?: string
  dosage_form: string
  strength: string
  requires_prescription: boolean
  stock_quantity: number
  in_stock: boolean
}

interface CartItem {
  medicine_id: string
  quantity: number
}

export default function MedicinesPage() {
  const [medicines, setMedicines] = useState<Medicine[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [cart, setCart] = useState<CartItem[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const { toast } = useToast()

  const categories = [
    "all",
    "Pain Relief",
    "Antibiotics",
    "Allergy",
    "Gastric",
    "Vitamins",
    "Diabetes",
    "Heart",
    "Skin Care",
    "Cold & Flu",
  ]

  useEffect(() => {
    fetchMedicines()
  }, [searchTerm, selectedCategory, currentPage])

  const fetchMedicines = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "12",
      })

      if (searchTerm) params.append("search", searchTerm)
      if (selectedCategory !== "all") params.append("category", selectedCategory)

      const response = await fetch(`/api/medicines?${params}`)
      const data = await response.json()

      if (response.ok) {
        setMedicines(data.medicines || [])
        setTotalPages(data.pagination?.totalPages || 1)
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch medicines",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching medicines:", error)
      toast({
        title: "Error",
        description: "Failed to load medicines",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const addToCart = async (medicine: Medicine) => {
    try {
      const existingItem = cart.find((item) => item.medicine_id === medicine.id)
      const newQuantity = existingItem ? existingItem.quantity + 1 : 1

      if (newQuantity > medicine.stock_quantity) {
        toast({
          title: "Stock Limit",
          description: `Only ${medicine.stock_quantity} items available`,
          variant: "destructive",
        })
        return
      }

      const response = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          medicine_id: medicine.id,
          quantity: 1,
        }),
      })

      if (response.ok) {
        setCart((prev) => {
          const existing = prev.find((item) => item.medicine_id === medicine.id)
          if (existing) {
            return prev.map((item) =>
              item.medicine_id === medicine.id ? { ...item, quantity: item.quantity + 1 } : item,
            )
          }
          return [...prev, { medicine_id: medicine.id, quantity: 1 }]
        })

        toast({
          title: "Added to Cart",
          description: `${medicine.name} added to cart`,
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add to cart",
        variant: "destructive",
      })
    }
  }

  const getCartQuantity = (medicineId: string) => {
    return cart.find((item) => item.medicine_id === medicineId)?.quantity || 0
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Online Pharmacy</h1>
          <p className="text-gray-600 text-lg">Browse and order medicines from verified pharmacies</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search medicines..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category === "all" ? "All Categories" : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Medicines Grid */}
        {medicines.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <ShoppingCart className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No medicines found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {medicines.map((medicine) => (
              <Card key={medicine.id} className="hover:shadow-lg transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg font-semibold text-gray-900 line-clamp-2">
                        {medicine.name}
                      </CardTitle>
                      {medicine.generic_name && <p className="text-sm text-gray-500 mt-1">{medicine.generic_name}</p>}
                    </div>
                    <Button variant="ghost" size="sm" className="p-1">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {medicine.category}
                    </Badge>
                    {medicine.requires_prescription && (
                      <Badge variant="destructive" className="text-xs">
                        Rx
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">{medicine.manufacturer}</p>
                      <p className="text-sm text-gray-500">
                        {medicine.dosage_form} • {medicine.strength}
                      </p>
                    </div>

                    {medicine.description && (
                      <p className="text-sm text-gray-600 line-clamp-2">{medicine.description}</p>
                    )}

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-green-600">₹{medicine.price}</p>
                        <p className="text-xs text-gray-500">
                          {medicine.in_stock ? `${medicine.stock_quantity} in stock` : "Out of stock"}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs text-gray-600">4.5</span>
                      </div>
                    </div>

                    {medicine.in_stock ? (
                      <div className="flex items-center gap-2">
                        {getCartQuantity(medicine.id) > 0 ? (
                          <div className="flex items-center gap-2 flex-1">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => {
                                /* Handle decrease */
                              }}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium px-2">{getCartQuantity(medicine.id)}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => addToCart(medicine)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <Button onClick={() => addToCart(medicine)} className="flex-1 h-9" size="sm">
                            <ShoppingCart className="h-4 w-4 mr-2" />
                            Add to Cart
                          </Button>
                        )}
                      </div>
                    ) : (
                      <Button disabled className="w-full h-9" size="sm">
                        Out of Stock
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center mt-8 gap-2">
            <Button
              variant="outline"
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <span className="flex items-center px-4 text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </span>
            <Button
              variant="outline"
              onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
