"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Database, Users, Pill, ShoppingCart, Stethoscope, Truck, Activity, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface DatabaseStats {
  users: number
  medicines: number
  orders: number
  doctors: number
  pharmacists: number
  delivery_agents: number
}

interface HealthStatus {
  status: string
  database: string
  timestamp: string
  version?: string
  connection_pool?: {
    total: number
    idle: number
    waiting: number
  }
}

export default function DatabaseAdminPage() {
  const [stats, setStats] = useState<DatabaseStats | null>(null)
  const [health, setHealth] = useState<HealthStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchDatabaseInfo()
  }, [])

  const fetchDatabaseInfo = async () => {
    try {
      setLoading(true)

      // Fetch health status
      const healthResponse = await fetch("/api/health")
      const healthData = await healthResponse.json()
      setHealth(healthData)

      // Fetch database statistics
      const statsResponse = await fetch("/api/admin/database-stats")
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData)
      }

      toast({
        title: "Database Info Updated",
        description: "Successfully fetched database information",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch database information",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const runDatabaseScript = async (scriptName: string) => {
    try {
      const response = await fetch("/api/admin/run-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ script: scriptName }),
      })

      if (response.ok) {
        toast({
          title: "Script Executed",
          description: `Successfully ran ${scriptName}`,
        })
        fetchDatabaseInfo() // Refresh stats
      } else {
        const error = await response.json()
        toast({
          title: "Script Failed",
          description: error.error || "Failed to execute script",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to execute script",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Database className="h-12 w-12 mx-auto mb-4 text-blue-600 animate-pulse" />
            <h2 className="text-2xl font-semibold mb-2">Loading Database Info</h2>
            <p className="text-gray-600">Please wait...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Database Administration</h1>
          <p className="text-gray-600 mt-2">Monitor and manage your PostgreSQL database</p>
        </div>
        <Button onClick={fetchDatabaseInfo} className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
          <TabsTrigger value="scripts">Scripts</TabsTrigger>
          <TabsTrigger value="health">Health</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Database Health Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Database Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Badge variant={health?.database === "connected" ? "default" : "secondary"}>
                    {health?.database === "connected" ? "Connected" : "Disconnected"}
                  </Badge>
                  <span className="text-sm text-gray-600">Status: {health?.status || "Unknown"}</span>
                  {health?.version && <span className="text-sm text-gray-600">Version: {health.version}</span>}
                </div>
                <span className="text-sm text-gray-500">
                  Last checked: {health?.timestamp ? new Date(health.timestamp).toLocaleString() : "Never"}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Database Statistics */}
          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.users}</div>
                  <p className="text-xs text-muted-foreground">All registered users</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Medicines</CardTitle>
                  <Pill className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.medicines}</div>
                  <p className="text-xs text-muted-foreground">Available medicines</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Orders</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.orders}</div>
                  <p className="text-xs text-muted-foreground">Total orders placed</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Doctors</CardTitle>
                  <Stethoscope className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.doctors}</div>
                  <p className="text-xs text-muted-foreground">Registered doctors</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pharmacists</CardTitle>
                  <Pill className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.pharmacists}</div>
                  <p className="text-xs text-muted-foreground">Active pharmacies</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Delivery Agents</CardTitle>
                  <Truck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.delivery_agents}</div>
                  <p className="text-xs text-muted-foreground">Available for delivery</p>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="tables" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Database Tables</CardTitle>
              <CardDescription>View and manage database tables</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start">
                    Users
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Medicines
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Doctors
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Pharmacists
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Orders
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Appointments
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Inventory
                  </Button>
                  <Button variant="outline" className="justify-start">
                    Prescriptions
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scripts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Database Scripts</CardTitle>
              <CardDescription>Run database initialization and maintenance scripts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button
                  onClick={() => runDatabaseScript("complete-database-schema.sql")}
                  variant="outline"
                  className="justify-start"
                >
                  Initialize Database Schema
                </Button>
                <Button
                  onClick={() => runDatabaseScript("comprehensive-demo-data.sql")}
                  variant="outline"
                  className="justify-start"
                >
                  Load Demo Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Database Health</CardTitle>
              <CardDescription>Monitor database connection and performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {health && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium mb-1">Status</h3>
                      <Badge variant={health.database === "connected" ? "default" : "secondary"}>
                        {health.database === "connected" ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium mb-1">Last Updated</h3>
                      <p className="text-sm">
                        {health.timestamp ? new Date(health.timestamp).toLocaleString() : "Unknown"}
                      </p>
                    </div>
                    {health.version && (
                      <div>
                        <h3 className="text-sm font-medium mb-1">Database Version</h3>
                        <p className="text-sm">{health.version}</p>
                      </div>
                    )}
                    {health.connection_pool && (
                      <div>
                        <h3 className="text-sm font-medium mb-1">Connection Pool</h3>
                        <p className="text-sm">
                          Total: {health.connection_pool.total}, Idle: {health.connection_pool.idle}, Waiting:{" "}
                          {health.connection_pool.waiting}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="pt-4">
                    <Button onClick={() => fetchDatabaseInfo()} className="mr-2">
                      Refresh Status
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
