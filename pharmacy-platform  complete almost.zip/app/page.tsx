"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Video,
  Pill,
  Calendar,
  Star,
  ChevronRight,
  Shield,
  Clock,
  Users,
  Award,
  Stethoscope,
  Phone,
} from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { ProfessionalHeader } from "@/components/professional-header"
import { ProfessionalFooter } from "@/components/professional-footer"

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const handleSearch = () => {
    if (searchQuery.trim()) {
      router.push(`/medicines?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  const features = [
    {
      icon: <Video className="h-12 w-12 text-blue-600" />,
      title: "Telemedicine",
      description: "Consult with verified doctors via secure video calls from anywhere",
      color: "bg-blue-50 border-blue-200",
      buttonText: "Start Consultation",
      href: "/telemedicine",
    },
    {
      icon: <Pill className="h-12 w-12 text-green-600" />,
      title: "Online Pharmacy",
      description: "Order medicines with prescription verification and home delivery",
      color: "bg-green-50 border-green-200",
      buttonText: "Order Medicines",
      href: "/medicines",
    },
    {
      icon: <Calendar className="h-12 w-12 text-purple-600" />,
      title: "Book Appointments",
      description: "Schedule appointments with specialists at your convenience",
      color: "bg-purple-50 border-purple-200",
      buttonText: "Book Now",
      href: "/doctors",
    },
    {
      icon: <Stethoscope className="h-12 w-12 text-orange-600" />,
      title: "Lab Tests",
      description: "Book lab tests and health checkups with home sample collection",
      color: "bg-orange-50 border-orange-200",
      buttonText: "Book Tests",
      href: "/lab-tests",
    },
  ]

  const topDoctors = [
    {
      id: 1,
      name: "Dr. Priya Sharma",
      specialty: "Cardiologist",
      experience: "15 years",
      rating: 4.9,
      image: "/placeholder.svg?height=120&width=120",
      consultationFee: 500,
      nextAvailable: "Today 2:00 PM",
      totalConsultations: 1247,
      languages: ["English", "Hindi"],
    },
    {
      id: 2,
      name: "Dr. Rajesh Kumar",
      specialty: "General Physician",
      experience: "12 years",
      rating: 4.8,
      image: "/placeholder.svg?height=120&width=120",
      consultationFee: 300,
      nextAvailable: "Today 4:30 PM",
      totalConsultations: 892,
      languages: ["English", "Hindi", "Marathi"],
    },
    {
      id: 3,
      name: "Dr. Anita Patel",
      specialty: "Dermatologist",
      experience: "10 years",
      rating: 4.7,
      image: "/placeholder.svg?height=120&width=120",
      consultationFee: 400,
      nextAvailable: "Tomorrow 10:00 AM",
      totalConsultations: 654,
      languages: ["English", "Gujarati"],
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <ProfessionalHeader />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Your Health, <span className="text-blue-200">Our Priority</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
            Complete healthcare solution with telemedicine, online pharmacy, lab tests, and expert consultations
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative bg-white rounded-full p-2 shadow-2xl">
              <div className="flex items-center">
                <Search className="absolute left-6 text-gray-400 h-6 w-6" />
                <Input
                  type="text"
                  placeholder="Search for doctors, medicines, lab tests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-14 pr-4 py-4 text-lg border-0 focus:ring-0 text-gray-900 bg-transparent"
                />
                <Button onClick={handleSearch} className="rounded-full px-8 py-4 text-lg font-semibold">
                  Search
                </Button>
              </div>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <Shield className="h-8 w-8 mx-auto mb-2 text-green-400" />
              <p className="font-semibold">100% Secure</p>
              <p className="text-sm opacity-75">HIPAA Compliant</p>
            </div>
            <div className="text-center">
              <Clock className="h-8 w-8 mx-auto mb-2 text-blue-300" />
              <p className="font-semibold">24/7 Available</p>
              <p className="text-sm opacity-75">Round the clock</p>
            </div>
            <div className="text-center">
              <Users className="h-8 w-8 mx-auto mb-2 text-purple-300" />
              <p className="font-semibold">50,000+ Patients</p>
              <p className="text-sm opacity-75">Trust our service</p>
            </div>
            <div className="text-center">
              <Award className="h-8 w-8 mx-auto mb-2 text-yellow-300" />
              <p className="font-semibold">Verified Doctors</p>
              <p className="text-sm opacity-75">Licensed professionals</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Healthcare Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive healthcare solutions designed to meet all your medical needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className={`${feature.color} border-2 hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2`}
                onClick={() => router.push(feature.href)}
              >
                <CardHeader className="text-center pb-4">
                  <div className="flex justify-center mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl font-bold">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <CardDescription className="text-gray-700 mb-6 leading-relaxed">
                    {feature.description}
                  </CardDescription>
                  <Button className="w-full font-semibold">{feature.buttonText}</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Top Doctors Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-2">Top Rated Doctors</h2>
              <p className="text-gray-600">Consult with our verified and experienced doctors</p>
            </div>
            <Button variant="outline" size="lg" onClick={() => router.push("/doctors")}>
              View All Doctors <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {topDoctors.map((doctor) => (
              <Card key={doctor.id} className="hover:shadow-xl transition-shadow duration-300 border-2">
                <CardHeader className="text-center pb-4">
                  <div className="relative mx-auto mb-4">
                    <Image
                      src={doctor.image || "/placeholder.svg"}
                      alt={doctor.name}
                      width={120}
                      height={120}
                      className="rounded-full border-4 border-blue-100"
                    />
                    <div className="absolute -bottom-2 -right-2 bg-green-500 text-white rounded-full p-2">
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold">{doctor.name}</CardTitle>
                  <CardDescription className="text-blue-600 font-semibold text-lg">{doctor.specialty}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Experience:</span>
                      <p className="font-semibold">{doctor.experience}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Consultations:</span>
                      <p className="font-semibold">{doctor.totalConsultations}+</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1">
                      <Star className="h-5 w-5 text-yellow-500 fill-current" />
                      <span className="font-bold text-lg">{doctor.rating}</span>
                      <span className="text-gray-500 text-sm">(245 reviews)</span>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">₹{doctor.consultationFee}</p>
                      <p className="text-xs text-gray-500">consultation fee</p>
                    </div>
                  </div>

                  <div className="bg-green-50 p-3 rounded-lg">
                    <p className="text-sm text-green-700 font-medium">🟢 Next Available: {doctor.nextAvailable}</p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {doctor.languages.map((lang) => (
                      <Badge key={lang} variant="secondary" className="text-xs">
                        {lang}
                      </Badge>
                    ))}
                  </div>

                  <Button
                    className="w-full font-semibold py-3"
                    onClick={() => router.push(`/doctors/${doctor.id}/book`)}
                  >
                    Book Consultation
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Section */}
      <section className="py-16 bg-red-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">Medical Emergency?</h2>
            <p className="text-xl mb-8 opacity-90">
              Get immediate medical assistance 24/7. Our emergency response team is always ready to help.
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Button
                size="lg"
                variant="secondary"
                className="bg-white text-red-600 hover:bg-gray-100 font-bold px-8 py-4"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call Emergency: 102
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-red-600 font-bold px-8 py-4"
                onClick={() => router.push("/emergency")}
              >
                Find Nearest Hospital
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of patients who trust MediCare+ for their healthcare needs. Experience the future of
            healthcare today.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Button
              size="lg"
              variant="secondary"
              className="bg-white text-blue-600 hover:bg-gray-100 font-bold px-8 py-4"
              onClick={() => router.push("/auth/register")}
            >
              Create Free Account
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 font-bold px-8 py-4"
              onClick={() => router.push("/medicines")}
            >
              Browse Medicines
            </Button>
          </div>
        </div>
      </section>

      <ProfessionalFooter />
    </div>
  )
}
