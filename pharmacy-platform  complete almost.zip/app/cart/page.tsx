"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ProfessionalHeader } from "@/components/professional-header"
import { ProfessionalFooter } from "@/components/professional-footer"
import { ShoppingCart, Plus, Minus, Trash2, MapPin, CreditCard, Truck } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

interface CartItem {
  id: string
  medicine_id: string
  name: string
  manufacturer: string
  price: number
  quantity: number
  pharmacy_name: string
  pharmacist_name: string
  requires_prescription: boolean
  dosage_form: string
  strength: string
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState<string | null>(null)
  const [deliveryAddress, setDeliveryAddress] = useState("")
  const [deliveryInstructions, setDeliveryInstructions] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("card")

  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    fetchCartItems()
  }, [])

  const fetchCartItems = async () => {
    try {
      const response = await fetch("/api/cart")
      const data = await response.json()

      if (response.ok) {
        setCartItems(data.items || [])
      }
    } catch (error) {
      console.error("Error fetching cart:", error)
    } finally {
      setLoading(false)
    }
  }

  const updateQuantity = async (cartId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(cartId)
      return
    }

    try {
      setUpdating(cartId)

      const response = await fetch("/api/cart", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cartId, quantity: newQuantity }),
      })

      if (response.ok) {
        setCartItems((items) => items.map((item) => (item.id === cartId ? { ...item, quantity: newQuantity } : item)))
      }
    } catch (error) {
      console.error("Error updating quantity:", error)
      toast({
        title: "Error",
        description: "Failed to update quantity",
        variant: "destructive",
      })
    } finally {
      setUpdating(null)
    }
  }

  const removeItem = async (cartId: string) => {
    try {
      const response = await fetch(`/api/cart?id=${cartId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setCartItems((items) => items.filter((item) => item.id !== cartId))
        toast({
          title: "Item Removed",
          description: "Item removed from cart",
        })
      }
    } catch (error) {
      console.error("Error removing item:", error)
      toast({
        title: "Error",
        description: "Failed to remove item",
        variant: "destructive",
      })
    }
  }

  const calculateTotal = () => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const deliveryFee = subtotal > 500 ? 0 : 50
    const tax = subtotal * 0.05 // 5% tax
    return {
      subtotal,
      deliveryFee,
      tax,
      total: subtotal + deliveryFee + tax,
    }
  }

  const handleCheckout = async () => {
    if (!deliveryAddress.trim()) {
      toast({
        title: "Missing Address",
        description: "Please enter delivery address",
        variant: "destructive",
      })
      return
    }

    try {
      const { total } = calculateTotal()

      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cartItems,
          delivery_address: deliveryAddress,
          delivery_instructions: deliveryInstructions,
          payment_method: paymentMethod,
          total_amount: total,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Order Placed!",
          description: "Your order has been placed successfully",
        })
        router.push(`/orders/${data.order.id}`)
      } else {
        toast({
          title: "Order Failed",
          description: data.error || "Failed to place order",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error placing order:", error)
      toast({
        title: "Error",
        description: "Failed to place order",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ProfessionalHeader />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const { subtotal, deliveryFee, tax, total } = calculateTotal()

  return (
    <div className="min-h-screen bg-gray-50">
      <ProfessionalHeader cartCount={cartItems.length} />

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

        {cartItems.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingCart className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">Your cart is empty</h3>
            <p className="text-gray-500 mb-6">Add some medicines to get started</p>
            <Button onClick={() => router.push("/medicines")}>Browse Medicines</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center">
                        <ShoppingCart className="h-8 w-8 text-gray-400" />
                      </div>

                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{item.name}</h3>
                        <p className="text-gray-600">{item.manufacturer}</p>
                        <p className="text-sm text-gray-500">
                          {item.dosage_form} • {item.strength}
                        </p>
                        <p className="text-sm text-blue-600">From: {item.pharmacy_name}</p>

                        {item.requires_prescription && (
                          <Badge variant="destructive" className="mt-2">
                            Prescription Required
                          </Badge>
                        )}
                      </div>

                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-600">₹{item.price}</p>
                        <p className="text-sm text-gray-500">per unit</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-4 border-t">
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={updating === item.id}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-12 text-center font-semibold">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          disabled={updating === item.id}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center space-x-4">
                        <span className="text-lg font-semibold">₹{(item.price * item.quantity).toFixed(2)}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(item.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal ({cartItems.length} items)</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span>{deliveryFee === 0 ? "FREE" : `₹${deliveryFee.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (5%)</span>
                    <span>₹{tax.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total</span>
                      <span>₹{total.toFixed(2)}</span>
                    </div>
                  </div>

                  {deliveryFee > 0 && (
                    <p className="text-sm text-gray-600">Add ₹{(500 - subtotal).toFixed(2)} more for free delivery</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Delivery Address
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="address">Address *</Label>
                    <Textarea
                      id="address"
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="Enter your complete delivery address..."
                      rows={3}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="instructions">Delivery Instructions</Label>
                    <Input
                      id="instructions"
                      value={deliveryInstructions}
                      onChange={(e) => setDeliveryInstructions(e.target.value)}
                      placeholder="e.g., Ring doorbell, Leave at gate"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Payment Method
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {["card", "upi", "cash"].map((method) => (
                      <label key={method} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="radio"
                          name="payment"
                          value={method}
                          checked={paymentMethod === method}
                          onChange={(e) => setPaymentMethod(e.target.value)}
                          className="text-blue-600"
                        />
                        <span className="capitalize">
                          {method === "card"
                            ? "Credit/Debit Card"
                            : method === "upi"
                              ? "UPI Payment"
                              : "Cash on Delivery"}
                        </span>
                      </label>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Button
                onClick={handleCheckout}
                className="w-full py-3 text-lg font-semibold"
                size="lg"
                disabled={!deliveryAddress.trim()}
              >
                <Truck className="h-5 w-5 mr-2" />
                Place Order - ₹{total.toFixed(2)}
              </Button>
            </div>
          </div>
        )}
      </div>

      <ProfessionalFooter />
    </div>
  )
}
