"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Pill, User, Stethoscope, Building2, Truck, Shield, Eye, EyeOff } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [role, setRole] = useState(searchParams.get("role") || "customer")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  // Test users for demo
  const testUsers = {
    customer: { email: "customer@test.com", password: "test123" },
    doctor: { email: "doctor@test.com", password: "test123" },
    pharmacist: { email: "pharmacist@test.com", password: "test123" },
    delivery: { email: "delivery@test.com", password: "test123" },
    admin: { email: "admin@test.com", password: "test123" },
  }

  const roleConfig = {
    customer: {
      icon: <User className="h-6 w-6" />,
      title: "Customer Login",
      description: "Access your health dashboard, book appointments, and order medicines",
      redirectPath: "/dashboard/customer",
    },
    doctor: {
      icon: <Stethoscope className="h-6 w-6" />,
      title: "Doctor Login",
      description: "Manage appointments, consultations, and patient records",
      redirectPath: "/dashboard/doctor",
    },
    pharmacist: {
      icon: <Building2 className="h-6 w-6" />,
      title: "Pharmacist Login",
      description: "Manage inventory, process prescriptions, and fulfill orders",
      redirectPath: "/dashboard/pharmacist",
    },
    delivery: {
      icon: <Truck className="h-6 w-6" />,
      title: "Delivery Agent Login",
      description: "Manage deliveries, track routes, and update order status",
      redirectPath: "/dashboard/delivery",
    },
    admin: {
      icon: <Shield className="h-6 w-6" />,
      title: "Admin Login",
      description: "Full platform control, user management, and analytics",
      redirectPath: "/dashboard/admin",
    },
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulate API call
    setTimeout(() => {
      const testUser = testUsers[role as keyof typeof testUsers]

      if (email === testUser.email && password === testUser.password) {
        // Create a simple token
        const token = Buffer.from(
          JSON.stringify({
            userId: `user-${role}-${Date.now()}`,
            email,
            role,
            name:
              role === "customer"
                ? "John Doe"
                : role === "doctor"
                  ? "Dr. Priya Sharma"
                  : role === "pharmacist"
                    ? "Raj Pharmacy"
                    : role === "delivery"
                      ? "Delivery Agent"
                      : "Admin User",
            isAuthenticated: true,
            timestamp: Date.now(),
          }),
        ).toString("base64")

        // Store token in cookie
        document.cookie = `token=${token}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Strict`

        // Store user session
        localStorage.setItem(
          "user",
          JSON.stringify({
            email,
            role,
            name:
              role === "customer"
                ? "John Doe"
                : role === "doctor"
                  ? "Dr. Priya Sharma"
                  : role === "pharmacist"
                    ? "Raj Pharmacy"
                    : role === "delivery"
                      ? "Delivery Agent"
                      : "Admin User",
            isAuthenticated: true,
          }),
        )

        router.push(roleConfig[role as keyof typeof roleConfig].redirectPath)
      } else {
        setError("Invalid credentials. Use test credentials provided below.")
      }
      setIsLoading(false)
    }, 1000)
  }

  const fillTestCredentials = () => {
    const testUser = testUsers[role as keyof typeof testUsers]
    setEmail(testUser.email)
    setPassword(testUser.password)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-4">
            <div className="bg-blue-600 text-white p-2 rounded-lg">
              <Pill className="h-6 w-6" />
            </div>
            <span className="text-2xl font-bold text-gray-900">MediCare+</span>
          </Link>
        </div>

        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4 text-blue-600">
              {roleConfig[role as keyof typeof roleConfig].icon}
            </div>
            <CardTitle className="text-2xl">{roleConfig[role as keyof typeof roleConfig].title}</CardTitle>
            <CardDescription>{roleConfig[role as keyof typeof roleConfig].description}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              {/* Role Selection */}
              <div className="space-y-2">
                <Label htmlFor="role">Login As</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="customer">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span>Customer</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="doctor">
                      <div className="flex items-center space-x-2">
                        <Stethoscope className="h-4 w-4" />
                        <span>Doctor</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="pharmacist">
                      <div className="flex items-center space-x-2">
                        <Building2 className="h-4 w-4" />
                        <span>Pharmacist</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="delivery">
                      <div className="flex items-center space-x-2">
                        <Truck className="h-4 w-4" />
                        <span>Delivery Agent</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="admin">
                      <div className="flex items-center space-x-2">
                        <Shield className="h-4 w-4" />
                        <span>Admin</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                />
                <Label htmlFor="remember" className="text-sm">
                  Remember me
                </Label>
              </div>

              {/* Error Message */}
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Test Credentials Helper */}
              <Alert>
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-medium">Test Credentials for {role}:</p>
                    <p className="text-sm">Email: {testUsers[role as keyof typeof testUsers].email}</p>
                    <p className="text-sm">Password: {testUsers[role as keyof typeof testUsers].password}</p>
                    <Button type="button" variant="outline" size="sm" onClick={fillTestCredentials} className="mt-2">
                      Fill Test Credentials
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>

              {/* Submit Button */}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Signing In..." : "Sign In"}
              </Button>
            </form>

            {/* Footer Links */}
            <div className="mt-6 text-center space-y-2">
              <Link href="/auth/forgot-password" className="text-sm text-blue-600 hover:underline">
                Forgot your password?
              </Link>
              <div className="text-sm text-gray-600">
                Don't have an account?{" "}
                <Link href="/auth/register" className="text-blue-600 hover:underline">
                  Sign up
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
