"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Database, CheckCircle, XCircle, RefreshCw, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ConnectionTest {
  name: string
  status: "pending" | "success" | "error"
  message: string
  duration?: number
}

export default function DatabaseTestPage() {
  const [tests, setTests] = useState<ConnectionTest[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [overallStatus, setOverallStatus] = useState<"pending" | "success" | "error">("pending")
  const { toast } = useToast()

  const runTests = async () => {
    setIsRunning(true)
    setOverallStatus("pending")

    const testSuite: ConnectionTest[] = [
      { name: "Database Health Check", status: "pending", message: "Checking database connection..." },
      { name: "Environment Variables", status: "pending", message: "Validating configuration..." },
      { name: "Query Test", status: "pending", message: "Testing database queries..." },
      { name: "Table Structure", status: "pending", message: "Verifying table structure..." },
    ]

    setTests([...testSuite])

    // Test 1: Health Check
    try {
      const start = Date.now()
      const response = await fetch("/api/health")
      const data = await response.json()
      const duration = Date.now() - start

      testSuite[0] = {
        name: "Database Health Check",
        status: data.database === "connected" ? "success" : "error",
        message:
          data.database === "connected"
            ? `Connected successfully (${duration}ms)`
            : `Connection failed: ${data.error || "Unknown error"}`,
        duration,
      }
    } catch (error) {
      testSuite[0] = {
        name: "Database Health Check",
        status: "error",
        message: `Connection failed: ${error.message}`,
      }
    }

    setTests([...testSuite])

    // Test 2: Environment Variables
    try {
      const envCheck = await fetch("/api/test-env")
      const envData = await envCheck.json()

      testSuite[1] = {
        name: "Environment Variables",
        status: envData.hasDatabase ? "success" : "error",
        message: envData.hasDatabase ? "DATABASE_URL is configured" : "DATABASE_URL is missing",
      }
    } catch (error) {
      testSuite[1] = {
        name: "Environment Variables",
        status: "error",
        message: "Failed to check environment variables",
      }
    }

    setTests([...testSuite])

    // Test 3: Query Test
    try {
      const start = Date.now()
      const queryResponse = await fetch("/api/medicines?limit=1")
      const queryData = await queryResponse.json()
      const duration = Date.now() - start

      testSuite[2] = {
        name: "Query Test",
        status: queryResponse.ok ? "success" : "error",
        message: queryResponse.ok ? `Query executed successfully (${duration}ms)` : "Query execution failed",
        duration,
      }
    } catch (error) {
      testSuite[2] = {
        name: "Query Test",
        status: "error",
        message: `Query failed: ${error.message}`,
      }
    }

    setTests([...testSuite])

    // Test 4: Table Structure
    try {
      const tableResponse = await fetch("/api/admin/database-stats")
      const tableData = await tableResponse.json()

      testSuite[3] = {
        name: "Table Structure",
        status: tableResponse.ok ? "success" : "error",
        message: tableResponse.ok
          ? `Tables accessible (${Object.keys(tableData).length} tables)`
          : "Table access failed",
      }
    } catch (error) {
      testSuite[3] = {
        name: "Table Structure",
        status: "error",
        message: `Table check failed: ${error.message}`,
      }
    }

    setTests([...testSuite])

    // Determine overall status
    const hasErrors = testSuite.some((test) => test.status === "error")
    const allSuccess = testSuite.every((test) => test.status === "success")

    setOverallStatus(hasErrors ? "error" : allSuccess ? "success" : "pending")
    setIsRunning(false)

    // Show toast notification
    if (allSuccess) {
      toast({
        title: "Database Tests Passed",
        description: "All database connections are working correctly",
      })
    } else {
      toast({
        title: "Database Issues Detected",
        description: "Some database tests failed. Check the results below.",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    runTests()
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "error":
        return <XCircle className="h-5 w-5 text-red-600" />
      default:
        return <RefreshCw className="h-5 w-5 text-blue-600 animate-spin" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "success":
        return <Badge className="bg-green-100 text-green-800">Success</Badge>
      case "error":
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="secondary">Running...</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <Database className="h-16 w-16 mx-auto mb-4 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Database Connection Test</h1>
          <p className="text-gray-600">Verify your PostgreSQL database connection and configuration</p>
        </div>

        {/* Overall Status */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getStatusIcon(overallStatus)}
              Overall Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              {getStatusBadge(overallStatus)}
              <Button onClick={runTests} disabled={isRunning} className="flex items-center gap-2">
                <RefreshCw className={`h-4 w-4 ${isRunning ? "animate-spin" : ""}`} />
                {isRunning ? "Running Tests..." : "Run Tests Again"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Test Results */}
        <div className="space-y-4">
          {tests.map((test, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(test.status)}
                    <div>
                      <h3 className="font-semibold">{test.name}</h3>
                      <p className="text-sm text-gray-600">{test.message}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(test.status)}
                    {test.duration && <p className="text-xs text-gray-500 mt-1">{test.duration}ms</p>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Configuration Help */}
        {overallStatus === "error" && (
          <Alert className="mt-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Database Connection Issues Detected</strong>
              <br />
              Please check your PostgreSQL configuration:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Ensure PostgreSQL is running on your system</li>
                <li>Verify DATABASE_URL in your .env file</li>
                <li>Check database credentials and permissions</li>
                <li>Confirm the database exists and is accessible</li>
              </ul>
            </AlertDescription>
          </Alert>
        )}

        {/* Success Message */}
        {overallStatus === "success" && (
          <Alert className="mt-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              <strong>Database Connection Successful!</strong>
              <br />
              Your PostgreSQL database is properly configured and all tests passed.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  )
}
