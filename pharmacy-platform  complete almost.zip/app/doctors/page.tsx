"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProfessionalHeader } from "@/components/professional-header"
import { ProfessionalFooter } from "@/components/professional-footer"
import { Search, Star, Calendar, Heart, Filter } from "lucide-react"
import { useRouter } from "next/navigation"

interface Doctor {
  id: string
  user_id: string
  first_name: string
  last_name: string
  specialization: string
  experience_years: number
  consultation_fee: number
  rating: number
  total_consultations: number
  availability_status: string
  bio: string
  education: string
  image_url?: string
}

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSpecialty, setSelectedSpecialty] = useState("all")
  const [sortBy, setSortBy] = useState("rating")
  const router = useRouter()

  const specialties = [
    "all",
    "Cardiologist",
    "Dermatologist",
    "Gynecologist",
    "Orthopedist",
    "Pediatrician",
    "Neurologist",
    "Psychiatrist",
    "General Physician",
  ]

  useEffect(() => {
    fetchDoctors()
  }, [searchTerm, selectedSpecialty, sortBy])

  const fetchDoctors = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (searchTerm) params.append("search", searchTerm)
      if (selectedSpecialty !== "all") params.append("specialty", selectedSpecialty)
      params.append("sort", sortBy)

      const response = await fetch(`/api/doctors?${params}`)
      const data = await response.json()

      if (response.ok) {
        setDoctors(data.doctors || [])
      }
    } catch (error) {
      console.error("Error fetching doctors:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleBookAppointment = (doctorId: string) => {
    router.push(`/doctors/${doctorId}/book`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ProfessionalHeader />
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-32"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    <div className="h-8 bg-gray-200 rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ProfessionalHeader />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Find Expert Doctors</h1>
          <p className="text-xl mb-8 opacity-90">Book appointments with verified healthcare professionals</p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto bg-white rounded-lg p-2 shadow-lg">
            <div className="flex items-center">
              <Search className="absolute left-6 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search doctors by name or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 border-0 focus:ring-0 text-gray-900"
              />
              <Button onClick={fetchDoctors} className="ml-2">
                Search
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="bg-white shadow-sm py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Filters:</span>
            </div>

            <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((specialty) => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty === "all" ? "All Specialties" : specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="experience">Most Experienced</SelectItem>
                <SelectItem value="fee_low">Lowest Fee</SelectItem>
                <SelectItem value="fee_high">Highest Fee</SelectItem>
              </SelectContent>
            </Select>

            <div className="ml-auto text-sm text-gray-600">{doctors.length} doctors found</div>
          </div>
        </div>
      </section>

      {/* Doctors Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {doctors.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No doctors found</h3>
              <p className="text-gray-500">Try adjusting your search or filter criteria</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {doctors.map((doctor) => (
                <Card key={doctor.id} className="hover:shadow-xl transition-shadow duration-300 border-2">
                  <CardHeader className="text-center pb-4">
                    <div className="relative mx-auto mb-4">
                      <Avatar className="w-24 h-24 border-4 border-blue-100">
                        <AvatarImage src={doctor.image_url || "/placeholder.svg"} />
                        <AvatarFallback className="text-lg">
                          {doctor.first_name[0]}
                          {doctor.last_name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-2 -right-2 bg-green-500 text-white rounded-full p-2">
                        <div className="w-3 h-3 bg-white rounded-full"></div>
                      </div>
                    </div>
                    <CardTitle className="text-xl font-bold">
                      Dr. {doctor.first_name} {doctor.last_name}
                    </CardTitle>
                    <p className="text-blue-600 font-semibold text-lg">{doctor.specialization}</p>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Experience:</span>
                        <p className="font-semibold">{doctor.experience_years} years</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Consultations:</span>
                        <p className="font-semibold">{doctor.total_consultations}+</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-1">
                        <Star className="h-5 w-5 text-yellow-500 fill-current" />
                        <span className="font-bold text-lg">{doctor.rating}</span>
                        <span className="text-gray-500 text-sm">(245 reviews)</span>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-600">₹{doctor.consultation_fee}</p>
                        <p className="text-xs text-gray-500">consultation fee</p>
                      </div>
                    </div>

                    {doctor.bio && <p className="text-sm text-gray-600 line-clamp-2">{doctor.bio}</p>}

                    <div className="bg-green-50 p-3 rounded-lg">
                      <p className="text-sm text-green-700 font-medium">🟢 Available for consultation</p>
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 font-semibold" onClick={() => handleBookAppointment(doctor.id)}>
                        <Calendar className="h-4 w-4 mr-2" />
                        Book Appointment
                      </Button>
                      <Button variant="outline" size="icon">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      <ProfessionalFooter />
    </div>
  )
}
