"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ProfessionalHeader } from "@/components/professional-header"
import { ProfessionalFooter } from "@/components/professional-footer"
import { Clock, Video, MapPin, Star, ArrowLeft } from "lucide-react"
import { useRouter, useParams } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

interface Doctor {
  id: string
  first_name: string
  last_name: string
  specialization: string
  experience_years: number
  consultation_fee: number
  rating: number
  bio: string
  education: string
}

export default function BookAppointmentPage() {
  const [doctor, setDoctor] = useState<Doctor | null>(null)
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [selectedTime, setSelectedTime] = useState("")
  const [appointmentType, setAppointmentType] = useState("video")
  const [reason, setReason] = useState("")
  const [patientName, setPatientName] = useState("")
  const [patientPhone, setPatientPhone] = useState("")
  const [loading, setLoading] = useState(true)
  const [booking, setBooking] = useState(false)

  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()

  const timeSlots = [
    "09:00 AM",
    "09:30 AM",
    "10:00 AM",
    "10:30 AM",
    "11:00 AM",
    "11:30 AM",
    "02:00 PM",
    "02:30 PM",
    "03:00 PM",
    "03:30 PM",
    "04:00 PM",
    "04:30 PM",
    "05:00 PM",
    "05:30 PM",
    "06:00 PM",
    "06:30 PM",
    "07:00 PM",
    "07:30 PM",
  ]

  useEffect(() => {
    fetchDoctor()
  }, [params.id])

  const fetchDoctor = async () => {
    try {
      const response = await fetch(`/api/doctors/${params.id}`)
      const data = await response.json()

      if (response.ok) {
        setDoctor(data.doctor)
      } else {
        toast({
          title: "Error",
          description: "Doctor not found",
          variant: "destructive",
        })
        router.push("/doctors")
      }
    } catch (error) {
      console.error("Error fetching doctor:", error)
      toast({
        title: "Error",
        description: "Failed to load doctor information",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleBookAppointment = async () => {
    if (!selectedDate || !selectedTime || !reason || !patientName || !patientPhone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      setBooking(true)

      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          doctor_id: doctor?.id,
          appointment_date: selectedDate.toISOString().split("T")[0],
          appointment_time: selectedTime,
          type: appointmentType,
          reason,
          patient_name: patientName,
          patient_phone: patientPhone,
          consultation_fee: doctor?.consultation_fee,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Appointment Booked!",
          description: "Your appointment has been successfully booked. You will receive a confirmation shortly.",
        })
        router.push("/dashboard/customer")
      } else {
        toast({
          title: "Booking Failed",
          description: data.error || "Failed to book appointment",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error booking appointment:", error)
      toast({
        title: "Error",
        description: "Failed to book appointment",
        variant: "destructive",
      })
    } finally {
      setBooking(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ProfessionalHeader />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <div className="h-96 bg-gray-200 rounded-lg"></div>
              </div>
              <div className="h-64 bg-gray-200 rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!doctor) {
    return (
      <div className="min-h-screen bg-gray-50">
        <ProfessionalHeader />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Doctor Not Found</h1>
          <Button onClick={() => router.push("/doctors")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Doctors
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ProfessionalHeader />

      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <Button variant="ghost" onClick={() => router.back()} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Doctors
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Book Appointment</CardTitle>
                <p className="text-gray-600">
                  Schedule your consultation with Dr. {doctor.first_name} {doctor.last_name}
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Patient Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Patient Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="patientName">Full Name *</Label>
                      <Input
                        id="patientName"
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        placeholder="Enter patient name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="patientPhone">Phone Number *</Label>
                      <Input
                        id="patientPhone"
                        value={patientPhone}
                        onChange={(e) => setPatientPhone(e.target.value)}
                        placeholder="Enter phone number"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Appointment Type */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Consultation Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card
                      className={`cursor-pointer border-2 ${appointmentType === "video" ? "border-blue-500 bg-blue-50" : "border-gray-200"}`}
                      onClick={() => setAppointmentType("video")}
                    >
                      <CardContent className="p-4 text-center">
                        <Video className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                        <h4 className="font-semibold">Video Consultation</h4>
                        <p className="text-sm text-gray-600">Consult from home</p>
                      </CardContent>
                    </Card>
                    <Card
                      className={`cursor-pointer border-2 ${appointmentType === "in_person" ? "border-blue-500 bg-blue-50" : "border-gray-200"}`}
                      onClick={() => setAppointmentType("in_person")}
                    >
                      <CardContent className="p-4 text-center">
                        <MapPin className="h-8 w-8 mx-auto mb-2 text-green-600" />
                        <h4 className="font-semibold">In-Person Visit</h4>
                        <p className="text-sm text-gray-600">Visit clinic</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Date Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Select Date</h3>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date() || date.getDay() === 0}
                    className="rounded-md border"
                  />
                </div>

                {/* Time Selection */}
                {selectedDate && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Select Time</h3>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                      {timeSlots.map((time) => (
                        <Button
                          key={time}
                          variant={selectedTime === time ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedTime(time)}
                          className="text-sm"
                        >
                          {time}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Reason for Visit */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Reason for Consultation *</h3>
                  <Textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Please describe your symptoms or reason for consultation..."
                    rows={4}
                    required
                  />
                </div>

                {/* Book Button */}
                <Button
                  onClick={handleBookAppointment}
                  disabled={booking || !selectedDate || !selectedTime || !reason || !patientName || !patientPhone}
                  className="w-full py-3 text-lg font-semibold"
                  size="lg"
                >
                  {booking ? "Booking..." : `Book Appointment - ₹${doctor.consultation_fee}`}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Doctor Info Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-blue-100">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback className="text-lg">
                      {doctor.first_name[0]}
                      {doctor.last_name[0]}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-xl font-bold">
                    Dr. {doctor.first_name} {doctor.last_name}
                  </h3>
                  <p className="text-blue-600 font-semibold">{doctor.specialization}</p>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Experience:</span>
                    <span className="font-semibold">{doctor.experience_years} years</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Rating:</span>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-current mr-1" />
                      <span className="font-semibold">{doctor.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Consultation Fee:</span>
                    <span className="font-semibold text-green-600">₹{doctor.consultation_fee}</span>
                  </div>
                </div>

                {doctor.bio && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="font-semibold mb-2">About</h4>
                    <p className="text-sm text-gray-600">{doctor.bio}</p>
                  </div>
                )}

                {doctor.education && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="font-semibold mb-2">Education</h4>
                    <p className="text-sm text-gray-600">{doctor.education}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h4 className="font-semibold mb-4">Clinic Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                    <span>Medical Plaza, Delhi</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-gray-400 mr-2" />
                    <span>Mon-Sat: 9:00 AM - 8:00 PM</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <ProfessionalFooter />
    </div>
  )
}
