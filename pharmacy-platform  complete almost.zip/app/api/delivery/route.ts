import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { sendDeliveryUpdate } from "@/lib/sms"

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "delivery") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get delivery agent ID
    const agentResult = await pool.query("SELECT id FROM delivery_agents WHERE user_id = $1", [decoded.userId])
    if (agentResult.rows.length === 0) {
      return NextResponse.json({ error: "Delivery agent not found" }, { status: 404 })
    }

    const agentId = agentResult.rows[0].id

    // Get assigned orders
    const ordersResult = await pool.query(
      `SELECT o.*, 
             u.first_name as customer_first_name, 
             u.last_name as customer_last_name,
             u.phone as customer_phone,
             p.pharmacy_name,
             pu.first_name as pharmacist_first_name,
             pu.last_name as pharmacist_last_name
       FROM orders o
       JOIN users u ON o.customer_id = u.id
       JOIN pharmacists p ON o.pharmacist_id = p.id
       JOIN users pu ON p.user_id = pu.id
       WHERE o.delivery_agent_id = $1
       ORDER BY o.order_date DESC`,
      [agentId],
    )

    return NextResponse.json({ orders: ordersResult.rows })
  } catch (error) {
    console.error("Get delivery orders error:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "delivery") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const { orderId, status, location } = await request.json()

    // Update order status
    await pool.query("UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2", [status, orderId])

    // Update delivery agent location if provided
    if (location) {
      await pool.query("UPDATE delivery_agents SET current_location = $1 WHERE user_id = $2", [
        JSON.stringify(location),
        decoded.userId,
      ])
    }

    // Get customer phone for SMS notification
    const orderResult = await pool.query(
      `SELECT u.phone, o.id as order_id
       FROM orders o
       JOIN users u ON o.customer_id = u.id
       WHERE o.id = $1`,
      [orderId],
    )

    if (orderResult.rows.length > 0) {
      const { phone, order_id } = orderResult.rows[0]
      await sendDeliveryUpdate(phone, order_id, status)
    }

    return NextResponse.json({ message: "Order status updated successfully" })
  } catch (error) {
    console.error("Update delivery status error:", error)
    return NextResponse.json({ error: "Status update failed" }, { status: 500 })
  }
}
