import { NextResponse } from "next/server"

export async function GET() {
  try {
    const envCheck = {
      hasDatabase: !!process.env.DATABASE_URL,
      hasJwtSecret: !!process.env.JWT_SECRET,
      hasSmtp: !!(process.env.SMTP_HOST && process.env.SMTP_USER),
      hasTwilio: !!(process.env.TWILIO_SID && process.env.TWILIO_AUTH_TOKEN),
      hasRazorpay: !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
      hasCloudinary: !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY),
      nodeEnv: process.env.NODE_ENV,
    }

    return NextResponse.json(envCheck)
  } catch (error) {
    return NextResponse.json({ error: "Failed to check environment variables" }, { status: 500 })
  }
}
