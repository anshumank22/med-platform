import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const city = searchParams.get("city")
    const radius = searchParams.get("radius")

    let query = `
      SELECT p.*, u.first_name, u.last_name, u.phone, u.email,
             COUNT(DISTINCT o.id) as total_orders,
             AVG(r.rating) as avg_rating
      FROM pharmacists p
      JOIN users u ON p.user_id = u.id
      LEFT JOIN orders o ON p.id = o.pharmacist_id
      LEFT JOIN reviews r ON p.id = r.pharmacist_id
      WHERE u.is_active = true
    `
    const params: any[] = []

    if (city) {
      query += " AND u.city ILIKE $" + (params.length + 1)
      params.push(`%${city}%`)
    }

    query += `
      GROUP BY p.id, u.id
      ORDER BY avg_rating DESC NULLS LAST, total_orders DESC
    `

    const result = await pool.query(query, params)

    return NextResponse.json({ pharmacists: result.rows })
  } catch (error) {
    console.error("Get pharmacists error:", error)
    return NextResponse.json({ error: "Failed to fetch pharmacists" }, { status: 500 })
  }
}
