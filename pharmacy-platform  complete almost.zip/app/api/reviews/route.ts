import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "customer") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const { doctor_id, delivery_agent_id, order_id, appointment_id, rating, comment } = await request.json()

    await pool.query(
      `INSERT INTO reviews (id, customer_id, doctor_id, delivery_agent_id, order_id, appointment_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [uuidv4(), decoded.userId, doctor_id, delivery_agent_id, order_id, appointment_id, rating, comment],
    )

    // Update doctor rating if applicable
    if (doctor_id) {
      await pool.query(
        `
        UPDATE doctors SET 
          rating = (
            SELECT AVG(rating)::DECIMAL(3,2) 
            FROM reviews 
            WHERE doctor_id = $1
          )
        WHERE id = $1
      `,
        [doctor_id],
      )
    }

    // Update delivery agent rating if applicable
    if (delivery_agent_id) {
      await pool.query(
        `
        UPDATE delivery_agents SET 
          rating = (
            SELECT AVG(rating)::DECIMAL(3,2) 
            FROM reviews 
            WHERE delivery_agent_id = $1
          )
        WHERE id = $1
      `,
        [delivery_agent_id],
      )
    }

    return NextResponse.json({ message: "Review submitted successfully" })
  } catch (error) {
    console.error("Submit review error:", error)
    return NextResponse.json({ error: "Review submission failed" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const doctorId = searchParams.get("doctorId")
    const deliveryAgentId = searchParams.get("deliveryAgentId")

    let query = `
      SELECT r.*, 
             u.first_name as customer_first_name,
             u.last_name as customer_last_name
      FROM reviews r
      JOIN users u ON r.customer_id = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (doctorId) {
      query += " AND r.doctor_id = $" + (params.length + 1)
      params.push(doctorId)
    }

    if (deliveryAgentId) {
      query += " AND r.delivery_agent_id = $" + (params.length + 1)
      params.push(deliveryAgentId)
    }

    query += " ORDER BY r.created_at DESC LIMIT 50"

    const result = await pool.query(query, params)
    return NextResponse.json({ reviews: result.rows })
  } catch (error) {
    console.error("Get reviews error:", error)
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 })
  }
}
