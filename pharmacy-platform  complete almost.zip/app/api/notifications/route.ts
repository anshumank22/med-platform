import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { searchParams } = new URL(request.url)
    const unreadOnly = searchParams.get("unread") === "true"

    let query = "SELECT * FROM notifications WHERE user_id = $1"
    const params = [decoded.userId]

    if (unreadOnly) {
      query += " AND is_read = false"
    }

    query += " ORDER BY created_at DESC LIMIT 50"

    const result = await pool.query(query, params)
    return NextResponse.json({ notifications: result.rows })
  } catch (error) {
    console.error("Get notifications error:", error)
    return NextResponse.json({ error: "Failed to fetch notifications" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { user_id, title, message, type } = await request.json()

    await pool.query("INSERT INTO notifications (id, user_id, title, message, type) VALUES ($1, $2, $3, $4, $5)", [
      uuidv4(),
      user_id,
      title,
      message,
      type,
    ])

    return NextResponse.json({ message: "Notification sent successfully" })
  } catch (error) {
    console.error("Send notification error:", error)
    return NextResponse.json({ error: "Failed to send notification" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { notificationId, is_read } = await request.json()

    await pool.query("UPDATE notifications SET is_read = $1 WHERE id = $2 AND user_id = $3", [
      is_read,
      notificationId,
      decoded.userId,
    ])

    return NextResponse.json({ message: "Notification updated successfully" })
  } catch (error) {
    console.error("Update notification error:", error)
    return NextResponse.json({ error: "Failed to update notification" }, { status: 500 })
  }
}
