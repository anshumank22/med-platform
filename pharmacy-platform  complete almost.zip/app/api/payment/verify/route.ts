import { type NextRequest, NextResponse } from "next/server"
import { verifyRazorpayPayment } from "@/lib/payment"
import { verifyToken } from "@/lib/auth"
import pool from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await request.json()

    // Verify payment with Razorpay
    const isValid = verifyRazorpayPayment(razorpay_order_id, razorpay_payment_id, razorpay_signature)

    if (isValid) {
      // Update order status
      await pool.query(
        `UPDATE orders SET payment_status = 'paid', status = 'confirmed', 
                          razorpay_payment_id = $1, updated_at = NOW()
         WHERE razorpay_order_id = $2 AND customer_id = $3`,
        [razorpay_payment_id, razorpay_order_id, decoded.userId],
      )

      // Clear cart
      await pool.query("DELETE FROM cart WHERE customer_id = $1", [decoded.userId])

      return NextResponse.json({ success: true, message: "Payment verified successfully" })
    } else {
      return NextResponse.json({ error: "Payment verification failed" }, { status: 400 })
    }
  } catch (error) {
    console.error("Verify payment error:", error)
    return NextResponse.json({ error: "Failed to verify payment" }, { status: 500 })
  }
}
