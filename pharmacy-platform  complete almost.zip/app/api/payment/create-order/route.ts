import { type NextRequest, NextResponse } from "next/server"
import { createRazorpayOrder } from "@/lib/payment"
import { verifyToken } from "@/lib/auth"
import pool from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { amount, currency = "INR", deliveryAddress, deliveryInstructions } = await request.json()

    // Create Razorpay order
    const razorpayOrder = await createRazorpayOrder(amount, currency)

    // Create order in database
    const orderResult = await pool.query(
      `INSERT INTO orders (customer_id, total_amount, delivery_address, delivery_instructions, 
                          payment_status, status, razorpay_order_id)
       VALUES ($1, $2, $3, $4, 'pending', 'pending', $5)
       RETURNING id`,
      [decoded.userId, amount, deliveryAddress, deliveryInstructions, razorpayOrder.id],
    )

    // Get cart items and add to order
    const cartItems = await pool.query(
      `SELECT c.*, m.price FROM cart c
       JOIN medicines m ON c.medicine_id = m.id
       WHERE c.customer_id = $1`,
      [decoded.userId],
    )

    for (const item of cartItems.rows) {
      await pool.query(
        `INSERT INTO order_items (order_id, medicine_id, quantity, unit_price, total_price)
         VALUES ($1, $2, $3, $4, $5)`,
        [orderResult.rows[0].id, item.medicine_id, item.quantity, item.price, item.quantity * item.price],
      )
    }

    return NextResponse.json({
      orderId: razorpayOrder.id,
      amount: razorpayOrder.amount,
      currency: razorpayOrder.currency,
      dbOrderId: orderResult.rows[0].id,
    })
  } catch (error) {
    console.error("Create order error:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}
