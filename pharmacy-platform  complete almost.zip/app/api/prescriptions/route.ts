import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "doctor") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const { customer_id, appointment_id, diagnosis, notes, medicines } = await request.json()

    // Get doctor ID
    const doctorResult = await pool.query("SELECT id FROM doctors WHERE user_id = $1", [decoded.userId])
    if (doctorResult.rows.length === 0) {
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 })
    }

    const doctorId = doctorResult.rows[0].id
    const prescriptionId = uuidv4()

    // Create prescription
    await pool.query(
      `INSERT INTO prescriptions (id, doctor_id, customer_id, appointment_id, diagnosis, notes)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [prescriptionId, doctorId, customer_id, appointment_id, diagnosis, notes],
    )

    // Add prescription medicines
    for (const medicine of medicines) {
      await pool.query(
        `INSERT INTO prescription_medicines (id, prescription_id, medicine_id, dosage, frequency, duration, instructions)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [
          uuidv4(),
          prescriptionId,
          medicine.medicine_id,
          medicine.dosage,
          medicine.frequency,
          medicine.duration,
          medicine.instructions,
        ],
      )
    }

    return NextResponse.json({
      message: "Prescription created successfully",
      prescriptionId,
    })
  } catch (error) {
    console.error("Create prescription error:", error)
    return NextResponse.json({ error: "Prescription creation failed" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { searchParams } = new URL(request.url)
    const customerId = searchParams.get("customerId")

    let query = `
      SELECT p.*, 
             d.specialization,
             u.first_name as doctor_first_name, 
             u.last_name as doctor_last_name,
             cu.first_name as customer_first_name,
             cu.last_name as customer_last_name
      FROM prescriptions p
      JOIN doctors d ON p.doctor_id = d.id
      JOIN users u ON d.user_id = u.id
      JOIN users cu ON p.customer_id = cu.id
    `
    const params: any[] = []

    if (decoded.role === "customer") {
      query += " WHERE p.customer_id = $1"
      params.push(decoded.userId)
    } else if (decoded.role === "doctor") {
      query += " WHERE d.user_id = $1"
      params.push(decoded.userId)
    } else if (customerId) {
      query += " WHERE p.customer_id = $1"
      params.push(customerId)
    }

    query += " ORDER BY p.prescription_date DESC"

    const result = await pool.query(query, params)

    // Get prescription medicines for each prescription
    for (const prescription of result.rows) {
      const medicinesResult = await pool.query(
        `SELECT pm.*, m.name, m.generic_name, m.manufacturer
         FROM prescription_medicines pm
         JOIN medicines m ON pm.medicine_id = m.id
         WHERE pm.prescription_id = $1`,
        [prescription.id],
      )
      prescription.medicines = medicinesResult.rows
    }

    return NextResponse.json({ prescriptions: result.rows })
  } catch (error) {
    console.error("Get prescriptions error:", error)
    return NextResponse.json({ error: "Failed to fetch prescriptions" }, { status: 500 })
  }
}
