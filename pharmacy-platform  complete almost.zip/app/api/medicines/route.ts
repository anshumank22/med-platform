import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "12")
    const offset = (page - 1) * limit

    let sql = `
      SELECT 
        m.*,
        COALESCE(i.stock_quantity, 0) as stock_quantity,
        CASE WHEN COALESCE(i.stock_quantity, 0) > 0 THEN true ELSE false END as in_stock
      FROM medicines m
      LEFT JOIN inventory i ON m.id = i.medicine_id
      WHERE m.is_active = true
    `
    const params: any[] = []
    let paramIndex = 1

    if (category && category !== "all") {
      sql += ` AND LOWER(m.category) = LOWER($${paramIndex})`
      params.push(category)
      paramIndex++
    }

    if (search) {
      sql += ` AND (LOWER(m.name) LIKE LOWER($${paramIndex}) OR LOWER(m.generic_name) LIKE LOWER($${paramIndex}))`
      params.push(`%${search}%`)
      paramIndex++
    }

    sql += ` ORDER BY m.name ASC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`
    params.push(limit, offset)

    const result = await query(sql, params)

    // Get total count for pagination
    let countSql = "SELECT COUNT(*) FROM medicines m WHERE m.is_active = true"
    const countParams: any[] = []
    let countParamIndex = 1

    if (category && category !== "all") {
      countSql += ` AND LOWER(m.category) = LOWER($${countParamIndex})`
      countParams.push(category)
      countParamIndex++
    }

    if (search) {
      countSql += ` AND (LOWER(m.name) LIKE LOWER($${countParamIndex}) OR LOWER(m.generic_name) LIKE LOWER($${countParamIndex}))`
      countParams.push(`%${search}%`)
    }

    const countResult = await query(countSql, countParams)
    const totalCount = Number.parseInt(countResult.rows[0]?.count || "0")

    return NextResponse.json({
      medicines: result.rows,
      pagination: {
        page,
        limit,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limit),
        hasNext: page * limit < totalCount,
        hasPrev: page > 1,
      },
    })
  } catch (error) {
    console.error("Error fetching medicines:", error)
    return NextResponse.json({ error: "Failed to fetch medicines" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      name,
      generic_name,
      manufacturer,
      category,
      price,
      description,
      dosage_form,
      strength,
      requires_prescription = false,
    } = body

    // Validate required fields
    if (!name || !manufacturer || !category || !price || !dosage_form || !strength) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const medicineId = `med-${Date.now()}`

    const sql = `
      INSERT INTO medicines (
        id, name, generic_name, manufacturer, category, price, 
        description, dosage_form, strength, requires_prescription, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `

    const params = [
      medicineId,
      name,
      generic_name,
      manufacturer,
      category,
      Number.parseFloat(price),
      description,
      dosage_form,
      strength,
      requires_prescription,
      true,
    ]

    const result = await query(sql, params)

    return NextResponse.json({
      message: "Medicine added successfully",
      medicine: result.rows[0],
    })
  } catch (error) {
    console.error("Error adding medicine:", error)
    return NextResponse.json({ error: "Failed to add medicine" }, { status: 500 })
  }
}
