import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { createPaymentOrder } from "@/lib/payment"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { pharmacistId, items, deliveryAddress, prescriptionId } = await request.json()

    // Calculate total amount
    let totalAmount = 0
    const orderItems = []

    for (const item of items) {
      const medicineResult = await pool.query("SELECT price FROM medicines WHERE id = $1", [item.medicineId])

      if (medicineResult.rows.length === 0) {
        return NextResponse.json({ error: `Medicine not found: ${item.medicineId}` }, { status: 404 })
      }

      const price = medicineResult.rows[0].price
      const itemTotal = price * item.quantity
      totalAmount += itemTotal

      orderItems.push({
        medicineId: item.medicineId,
        quantity: item.quantity,
        unitPrice: price,
        totalPrice: itemTotal,
      })
    }

    const deliveryFee = 50 // Fixed delivery fee
    totalAmount += deliveryFee

    // Create order
    const orderId = uuidv4()
    await pool.query(
      `INSERT INTO orders (id, customer_id, pharmacist_id, prescription_id, total_amount, delivery_fee, status, delivery_address, order_date, payment_status, payment_method)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), $9, $10)`,
      [
        orderId,
        decoded.userId,
        pharmacistId,
        prescriptionId,
        totalAmount,
        deliveryFee,
        "pending",
        deliveryAddress,
        "pending",
        "card",
      ],
    )

    // Create order items
    for (const item of orderItems) {
      await pool.query(
        `INSERT INTO order_items (id, order_id, medicine_id, quantity, unit_price, total_price)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [uuidv4(), orderId, item.medicineId, item.quantity, item.unitPrice, item.totalPrice],
      )
    }

    // Create payment order
    const paymentOrder = await createPaymentOrder(totalAmount, orderId)

    return NextResponse.json({
      message: "Order created successfully",
      orderId,
      paymentOrder,
      totalAmount,
    })
  } catch (error) {
    console.error("Order creation error:", error)
    return NextResponse.json({ error: "Order creation failed" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { searchParams } = new URL(request.url)
    const role = searchParams.get("role") || decoded.role

    let query = ""
    let params = []

    if (role === "customer") {
      query = `
        SELECT o.*, p.pharmacy_name, u.first_name as pharmacist_first_name, u.last_name as pharmacist_last_name
        FROM orders o
        JOIN pharmacists p ON o.pharmacist_id = p.id
        JOIN users u ON p.user_id = u.id
        JOIN customers c ON o.customer_id = c.id
        WHERE c.user_id = $1
        ORDER BY o.order_date DESC
      `
      params = [decoded.userId]
    } else if (role === "pharmacist") {
      query = `
        SELECT o.*, u.first_name as customer_first_name, u.last_name as customer_last_name, u.phone as customer_phone
        FROM orders o
        JOIN customers c ON o.customer_id = c.id
        JOIN users u ON c.user_id = u.id
        JOIN pharmacists p ON o.pharmacist_id = p.id
        WHERE p.user_id = $1
        ORDER BY o.order_date DESC
      `
      params = [decoded.userId]
    }

    const result = await pool.query(query, params)
    return NextResponse.json({ orders: result.rows })
  } catch (error) {
    console.error("Get orders error:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}
