import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    const { searchParams } = new URL(request.url)
    const pharmacistId = searchParams.get("pharmacistId")

    let query = `
      SELECT i.*, m.name, m.generic_name, m.manufacturer, m.category, m.price as medicine_price
      FROM inventory i
      JOIN medicines m ON i.medicine_id = m.id
    `
    const params: any[] = []

    if (decoded.role === "pharmacist") {
      // Get pharmacist ID from user
      const pharmacistResult = await pool.query("SELECT id FROM pharmacists WHERE user_id = $1", [decoded.userId])
      if (pharmacistResult.rows.length === 0) {
        return NextResponse.json({ error: "Pharmacist not found" }, { status: 404 })
      }
      query += " WHERE i.pharmacist_id = $1"
      params.push(pharmacistResult.rows[0].id)
    } else if (pharmacistId) {
      query += " WHERE i.pharmacist_id = $1"
      params.push(pharmacistId)
    }

    query += " ORDER BY i.stock_quantity ASC, i.expiry_date ASC"

    const result = await pool.query(query, params)
    return NextResponse.json({ inventory: result.rows })
  } catch (error) {
    console.error("Get inventory error:", error)
    return NextResponse.json({ error: "Failed to fetch inventory" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "pharmacist") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const { medicine_id, stock_quantity, expiry_date, batch_number, purchase_price, selling_price } =
      await request.json()

    // Get pharmacist ID
    const pharmacistResult = await pool.query("SELECT id FROM pharmacists WHERE user_id = $1", [decoded.userId])
    if (pharmacistResult.rows.length === 0) {
      return NextResponse.json({ error: "Pharmacist not found" }, { status: 404 })
    }

    const pharmacistId = pharmacistResult.rows[0].id

    // Add to inventory
    await pool.query(
      `INSERT INTO inventory (id, pharmacist_id, medicine_id, stock_quantity, expiry_date, batch_number, purchase_price, selling_price)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [uuidv4(), pharmacistId, medicine_id, stock_quantity, expiry_date, batch_number, purchase_price, selling_price],
    )

    return NextResponse.json({ message: "Inventory updated successfully" })
  } catch (error) {
    console.error("Update inventory error:", error)
    return NextResponse.json({ error: "Inventory update failed" }, { status: 500 })
  }
}
