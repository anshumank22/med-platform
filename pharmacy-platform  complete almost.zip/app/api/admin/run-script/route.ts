import { NextResponse } from "next/server"
import { query } from "@/lib/database"
import fs from "fs"
import path from "path"

export async function POST(request: Request) {
  try {
    const { script } = await request.json()

    if (!script) {
      return NextResponse.json({ error: "Script name is required" }, { status: 400 })
    }

    // Security: Only allow specific script files
    const allowedScripts = [
      "database-schema.sql",
      "seed-data.sql",
      "demo-medicines.sql",
      "complete-database-schema.sql",
      "comprehensive-demo-data.sql",
      "fix-database-schema.sql",
      "fixed-seed-data.sql",
      "cart-schema.sql",
    ]

    if (!allowedScripts.includes(script)) {
      return NextResponse.json({ error: "Script not allowed" }, { status: 403 })
    }

    // Read script file
    const scriptPath = path.join(process.cwd(), "scripts", script)

    if (!fs.existsSync(scriptPath)) {
      return NextResponse.json({ error: "Script file not found" }, { status: 404 })
    }

    const sqlContent = fs.readFileSync(scriptPath, "utf8")

    // Execute the SQL script
    await query(sqlContent)

    return NextResponse.json({
      success: true,
      message: `Script ${script} executed successfully`,
    })
  } catch (error) {
    console.error("Script execution error:", error)
    return NextResponse.json({ error: `Failed to execute script: ${error.message}` }, { status: 500 })
  }
}
