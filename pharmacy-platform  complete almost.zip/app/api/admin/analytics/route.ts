import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (decoded.role !== "admin") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get user statistics
    const userStats = await pool.query(`
      SELECT 
        role,
        COUNT(*) as count,
        COUNT(CASE WHEN is_active = true THEN 1 END) as active_count,
        COUNT(CASE WHEN is_verified = true THEN 1 END) as verified_count
      FROM users 
      GROUP BY role
    `)

    // Get order statistics
    const orderStats = await pool.query(`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(total_amount) as total_revenue
      FROM orders 
      WHERE order_date >= CURRENT_DATE - INTERVAL '30 days'
      GROUP BY status
    `)

    // Get appointment statistics
    const appointmentStats = await pool.query(`
      SELECT 
        status,
        COUNT(*) as count
      FROM appointments 
      WHERE appointment_date >= CURRENT_DATE - INTERVAL '30 days'
      GROUP BY status
    `)

    // Get revenue by day (last 30 days)
    const revenueByDay = await pool.query(`
      SELECT 
        DATE(order_date) as date,
        SUM(total_amount) as revenue,
        COUNT(*) as order_count
      FROM orders 
      WHERE order_date >= CURRENT_DATE - INTERVAL '30 days'
        AND payment_status = 'paid'
      GROUP BY DATE(order_date)
      ORDER BY date
    `)

    // Get top medicines
    const topMedicines = await pool.query(`
      SELECT 
        m.name,
        m.category,
        SUM(oi.quantity) as total_sold,
        SUM(oi.total_price) as total_revenue
      FROM order_items oi
      JOIN medicines m ON oi.medicine_id = m.id
      JOIN orders o ON oi.order_id = o.id
      WHERE o.order_date >= CURRENT_DATE - INTERVAL '30 days'
        AND o.payment_status = 'paid'
      GROUP BY m.id, m.name, m.category
      ORDER BY total_sold DESC
      LIMIT 10
    `)

    return NextResponse.json({
      userStats: userStats.rows,
      orderStats: orderStats.rows,
      appointmentStats: appointmentStats.rows,
      revenueByDay: revenueByDay.rows,
      topMedicines: topMedicines.rows,
    })
  } catch (error) {
    console.error("Get analytics error:", error)
    return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 })
  }
}
