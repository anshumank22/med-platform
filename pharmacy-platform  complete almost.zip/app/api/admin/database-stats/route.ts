import { NextResponse } from "next/server"
import { query } from "@/lib/database"

export async function GET() {
  try {
    // Get counts from all major tables
    const [usersResult, medicinesResult, ordersResult, doctorsResult, pharmacistsResult, deliveryAgentsResult] =
      await Promise.all([
        query("SELECT COUNT(*) FROM users"),
        query("SELECT COUNT(*) FROM medicines"),
        query("SELECT COUNT(*) FROM orders"),
        query("SELECT COUNT(*) FROM doctors"),
        query("SELECT COUNT(*) FROM pharmacists"),
        query("SELECT COUNT(*) FROM delivery_agents"),
      ])

    const stats = {
      users: Number.parseInt(usersResult.rows[0].count),
      medicines: Number.parseInt(medicinesResult.rows[0].count),
      orders: Number.parseInt(ordersResult.rows[0].count),
      doctors: Number.parseInt(doctorsResult.rows[0].count),
      pharmacists: Number.parseInt(pharmacistsResult.rows[0].count),
      delivery_agents: Number.parseInt(deliveryAgentsResult.rows[0].count),
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Database stats error:", error)
    return NextResponse.json({ error: "Failed to fetch database statistics" }, { status: 500 })
  }
}
