import { NextResponse } from "next/server"
import { healthCheck } from "@/lib/database"

export async function GET() {
  try {
    const healthStatus = await healthCheck()
    return NextResponse.json(healthStatus)
  } catch (error) {
    console.error("Health check API error:", error)
    return NextResponse.json(
      {
        status: "error",
        database: "error",
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
