import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const doctorId = params.id

    const result = await query(
      `SELECT d.*, u.first_name, u.last_name, u.email, u.phone, u.address, u.city, u.state
       FROM doctors d
       JOIN users u ON d.user_id = u.id
       WHERE d.id = $1 AND u.is_active = true`,
      [doctorId],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 })
    }

    const doctor = result.rows[0]

    return NextResponse.json({
      doctor: {
        id: doctor.id,
        user_id: doctor.user_id,
        first_name: doctor.first_name,
        last_name: doctor.last_name,
        email: doctor.email,
        phone: doctor.phone,
        specialization: doctor.specialization,
        experience_years: doctor.experience_years,
        consultation_fee: Number.parseFloat(doctor.consultation_fee),
        rating: Number.parseFloat(doctor.rating),
        total_consultations: doctor.total_consultations,
        availability_status: doctor.availability_status,
        bio: doctor.bio,
        education: doctor.education,
        certifications: doctor.certifications,
        address: doctor.address,
        city: doctor.city,
        state: doctor.state,
      },
    })
  } catch (error) {
    console.error("Error fetching doctor:", error)
    return NextResponse.json({ error: "Failed to fetch doctor" }, { status: 500 })
  }
}
