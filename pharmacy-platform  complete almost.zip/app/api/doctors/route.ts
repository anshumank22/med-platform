import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const specialty = searchParams.get("specialty")
    const sort = searchParams.get("sort") || "rating"
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "12")
    const offset = (page - 1) * limit

    let sql = `
      SELECT d.*, u.first_name, u.last_name, u.email, u.phone
      FROM doctors d
      JOIN users u ON d.user_id = u.id
      WHERE u.is_active = true AND d.availability_status != 'offline'
    `
    const params: any[] = []
    let paramIndex = 1

    if (search) {
      sql += ` AND (LOWER(u.first_name) LIKE LOWER($${paramIndex}) OR LOWER(u.last_name) LIKE LOWER($${paramIndex}) OR LOWER(d.specialization) LIKE LOWER($${paramIndex}))`
      params.push(`%${search}%`)
      paramIndex++
    }

    if (specialty && specialty !== "all") {
      sql += ` AND LOWER(d.specialization) = LOWER($${paramIndex})`
      params.push(specialty)
      paramIndex++
    }

    // Add sorting
    switch (sort) {
      case "rating":
        sql += " ORDER BY d.rating DESC"
        break
      case "experience":
        sql += " ORDER BY d.experience_years DESC"
        break
      case "fee_low":
        sql += " ORDER BY d.consultation_fee ASC"
        break
      case "fee_high":
        sql += " ORDER BY d.consultation_fee DESC"
        break
      default:
        sql += " ORDER BY d.rating DESC"
    }

    sql += ` LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`
    params.push(limit, offset)

    const result = await query(sql, params)

    // Get total count for pagination
    let countSql = `
      SELECT COUNT(*) FROM doctors d
      JOIN users u ON d.user_id = u.id
      WHERE u.is_active = true AND d.availability_status != 'offline'
    `
    const countParams: any[] = []
    let countParamIndex = 1

    if (search) {
      countSql += ` AND (LOWER(u.first_name) LIKE LOWER($${countParamIndex}) OR LOWER(u.last_name) LIKE LOWER($${countParamIndex}) OR LOWER(d.specialization) LIKE LOWER($${countParamIndex}))`
      countParams.push(`%${search}%`)
      countParamIndex++
    }

    if (specialty && specialty !== "all") {
      countSql += ` AND LOWER(d.specialization) = LOWER($${countParamIndex})`
      countParams.push(specialty)
    }

    const countResult = await query(countSql, countParams)
    const totalCount = Number.parseInt(countResult.rows[0]?.count || "0")

    const doctors = result.rows.map((row) => ({
      id: row.id,
      user_id: row.user_id,
      first_name: row.first_name,
      last_name: row.last_name,
      email: row.email,
      phone: row.phone,
      specialization: row.specialization,
      experience_years: row.experience_years,
      consultation_fee: Number.parseFloat(row.consultation_fee),
      rating: Number.parseFloat(row.rating),
      total_consultations: row.total_consultations,
      availability_status: row.availability_status,
      bio: row.bio,
      education: row.education,
    }))

    return NextResponse.json({
      doctors,
      pagination: {
        page,
        limit,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limit),
        hasNext: page * limit < totalCount,
        hasPrev: page > 1,
      },
    })
  } catch (error) {
    console.error("Error fetching doctors:", error)
    return NextResponse.json({ error: "Failed to fetch doctors" }, { status: 500 })
  }
}
