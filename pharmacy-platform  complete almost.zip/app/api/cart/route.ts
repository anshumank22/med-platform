import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const result = await pool.query(
      `SELECT c.*, m.name, m.price, m.manufacturer, m.dosage_form, m.strength,
              p.pharmacy_name, u.first_name as pharmacist_name
       FROM cart c
       JOIN medicines m ON c.medicine_id = m.id
       JOIN pharmacists p ON c.pharmacist_id = p.id
       JOIN users u ON p.user_id = u.id
       WHERE c.customer_id = $1
       ORDER BY c.created_at DESC`,
      [decoded.userId],
    )

    const countResult = await pool.query("SELECT COUNT(*) as count FROM cart WHERE customer_id = $1", [decoded.userId])

    return NextResponse.json({
      items: result.rows,
      count: Number.parseInt(countResult.rows[0].count),
    })
  } catch (error) {
    console.error("Get cart error:", error)
    return NextResponse.json({ error: "Failed to fetch cart" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { medicineId, quantity, pharmacistId } = await request.json()

    // Check if item already exists in cart
    const existingItem = await pool.query(
      "SELECT * FROM cart WHERE customer_id = $1 AND medicine_id = $2 AND pharmacist_id = $3",
      [decoded.userId, medicineId, pharmacistId],
    )

    if (existingItem.rows.length > 0) {
      // Update quantity
      await pool.query("UPDATE cart SET quantity = quantity + $1, updated_at = NOW() WHERE id = $2", [
        quantity,
        existingItem.rows[0].id,
      ])
    } else {
      // Add new item
      await pool.query(
        `INSERT INTO cart (customer_id, medicine_id, pharmacist_id, quantity)
         VALUES ($1, $2, $3, $4)`,
        [decoded.userId, medicineId, pharmacistId, quantity],
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Add to cart error:", error)
    return NextResponse.json({ error: "Failed to add to cart" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { cartId, quantity } = await request.json()

    if (quantity <= 0) {
      await pool.query("DELETE FROM cart WHERE id = $1 AND customer_id = $2", [cartId, decoded.userId])
    } else {
      await pool.query("UPDATE cart SET quantity = $1, updated_at = NOW() WHERE id = $2 AND customer_id = $3", [
        quantity,
        cartId,
        decoded.userId,
      ])
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Update cart error:", error)
    return NextResponse.json({ error: "Failed to update cart" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const token = request.headers.get("authorization")?.replace("Bearer ", "")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const cartId = searchParams.get("id")

    await pool.query("DELETE FROM cart WHERE id = $1 AND customer_id = $2", [cartId, decoded.userId])

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete cart item error:", error)
    return NextResponse.json({ error: "Failed to delete cart item" }, { status: 500 })
  }
}
