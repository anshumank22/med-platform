import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { v4 as uuidv4 } from "uuid"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")
    const doctorId = searchParams.get("doctor_id")
    const status = searchParams.get("status")

    let sql = `
      SELECT a.*, 
             d.specialization, d.consultation_fee,
             u_doctor.first_name as doctor_first_name, u_doctor.last_name as doctor_last_name,
             u_customer.first_name as customer_first_name, u_customer.last_name as customer_last_name
      FROM appointments a
      JOIN doctors d ON a.doctor_id = d.id
      JOIN users u_doctor ON d.user_id = u_doctor.id
      JOIN customers c ON a.customer_id = c.id
      JOIN users u_customer ON c.user_id = u_customer.id
      WHERE 1=1
    `
    const params: any[] = []
    let paramIndex = 1

    if (userId) {
      sql += ` AND (u_doctor.id = $${paramIndex} OR u_customer.id = $${paramIndex})`
      params.push(userId)
      paramIndex++
    }

    if (doctorId) {
      sql += ` AND a.doctor_id = $${paramIndex}`
      params.push(doctorId)
      paramIndex++
    }

    if (status) {
      sql += ` AND a.status = $${paramIndex}`
      params.push(status)
      paramIndex++
    }

    sql += " ORDER BY a.appointment_date DESC, a.appointment_time DESC"

    const result = await query(sql, params)

    return NextResponse.json({
      appointments: result.rows,
    })
  } catch (error) {
    console.error("Error fetching appointments:", error)
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      doctor_id,
      appointment_date,
      appointment_time,
      type = "video",
      reason,
      patient_name,
      patient_phone,
      consultation_fee,
    } = body

    // For demo purposes, we'll create a customer if not exists
    // In production, this should be handled by authentication
    const customerId = "850e8400-e29b-41d4-a716-446655440001" // Default demo customer

    const appointmentId = uuidv4()

    const sql = `
      INSERT INTO appointments (
        id, customer_id, doctor_id, appointment_date, appointment_time,
        type, status, reason, consultation_fee, payment_status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `

    const params = [
      appointmentId,
      customerId,
      doctor_id,
      appointment_date,
      appointment_time,
      type,
      "scheduled",
      reason,
      consultation_fee,
      "pending",
    ]

    const result = await query(sql, params)

    return NextResponse.json({
      message: "Appointment booked successfully",
      appointment: result.rows[0],
    })
  } catch (error) {
    console.error("Error booking appointment:", error)
    return NextResponse.json({ error: "Failed to book appointment" }, { status: 500 })
  }
}
