import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { userId, otp } = await request.json()

    // Verify OTP
    const otpResult = await pool.query(
      "SELECT * FROM otps WHERE user_id = $1 AND otp = $2 AND expires_at > NOW() AND is_used = false",
      [userId, otp],
    )

    if (otpResult.rows.length === 0) {
      return NextResponse.json({ error: "Invalid or expired OTP" }, { status: 400 })
    }

    // Mark OTP as used
    await pool.query("UPDATE otps SET is_used = true WHERE user_id = $1 AND otp = $2", [userId, otp])

    // Mark user as verified
    await pool.query("UPDATE users SET is_verified = true WHERE id = $1", [userId])

    return NextResponse.json({ message: "Email verified successfully" })
  } catch (error) {
    console.error("OTP verification error:", error)
    return NextResponse.json({ error: "Verification failed" }, { status: 500 })
  }
}
