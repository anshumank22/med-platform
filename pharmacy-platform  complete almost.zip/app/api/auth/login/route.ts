import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { verifyPassword, generateToken } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Get user
    const userResult = await pool.query("SELECT * FROM users WHERE email = $1 AND is_active = true", [email])

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const user = userResult.rows[0]

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password_hash)
    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Check if email is verified
    if (!user.is_verified) {
      return NextResponse.json({ error: "Please verify your email first" }, { status: 401 })
    }

    // Generate token
    const token = generateToken(user)

    // Get role-specific data
    let roleData = {}
    if (user.role === "doctor") {
      const doctorResult = await pool.query("SELECT * FROM doctors WHERE user_id = $1", [user.id])
      roleData = doctorResult.rows[0] || {}
    } else if (user.role === "pharmacist") {
      const pharmacistResult = await pool.query("SELECT * FROM pharmacists WHERE user_id = $1", [user.id])
      roleData = pharmacistResult.rows[0] || {}
    } else if (user.role === "delivery") {
      const deliveryResult = await pool.query("SELECT * FROM delivery_agents WHERE user_id = $1", [user.id])
      roleData = deliveryResult.rows[0] || {}
    } else if (user.role === "customer") {
      const customerResult = await pool.query("SELECT * FROM customers WHERE user_id = $1", [user.id])
      roleData = customerResult.rows[0] || {}
    }

    const response = NextResponse.json({
      message: "Login successful",
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        firstName: user.first_name,
        lastName: user.last_name,
        phone: user.phone,
        ...roleData,
      },
    })

    // Set HTTP-only cookie
    response.cookies.set("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    })

    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
