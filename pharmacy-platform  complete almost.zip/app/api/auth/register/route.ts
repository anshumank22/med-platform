import { type NextRequest, NextResponse } from "next/server"
import pool from "@/lib/database"
import { hashPassword, generateOTP } from "@/lib/auth"
import { sendOTPEmail } from "@/lib/email"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, role, firstName, lastName, phone, ...additionalData } = body

    // Check if user already exists
    const existingUser = await pool.query("SELECT id FROM users WHERE email = $1", [email])
    if (existingUser.rows.length > 0) {
      return NextResponse.json({ error: "User already exists" }, { status: 400 })
    }

    // Hash password
    const passwordHash = await hashPassword(password)
    const userId = uuidv4()

    // Create user
    await pool.query(
      `INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, is_verified, is_active, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())`,
      [userId, email, passwordHash, role, firstName, lastName, phone, false, true],
    )

    // Create role-specific record
    if (role === "doctor") {
      await pool.query(
        `INSERT INTO doctors (id, user_id, license_number, specialization, experience_years, consultation_fee, rating, total_consultations, availability_status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [
          uuidv4(),
          userId,
          additionalData.licenseNumber,
          additionalData.specialization,
          additionalData.experience || 0,
          500,
          0,
          0,
          "offline",
        ],
      )
    } else if (role === "pharmacist") {
      await pool.query(
        `INSERT INTO pharmacists (id, user_id, pharmacy_name, pharmacy_license, pharmacy_address, operating_hours, delivery_radius)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [
          uuidv4(),
          userId,
          additionalData.pharmacyName,
          additionalData.pharmacyLicense,
          additionalData.address,
          "9:00 AM - 10:00 PM",
          25,
        ],
      )
    } else if (role === "delivery") {
      await pool.query(
        `INSERT INTO delivery_agents (id, user_id, vehicle_number, driving_license, availability_status, rating, total_deliveries)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [uuidv4(), userId, additionalData.vehicleNumber, additionalData.drivingLicense, "offline", 0, 0],
      )
    } else if (role === "customer") {
      await pool.query(`INSERT INTO customers (id, user_id) VALUES ($1, $2)`, [uuidv4(), userId])
    }

    // Generate and send OTP
    const otp = generateOTP()
    await pool.query(
      "INSERT INTO otps (user_id, otp, expires_at, created_at) VALUES ($1, $2, NOW() + INTERVAL '10 minutes', NOW())",
      [userId, otp],
    )

    await sendOTPEmail(email, otp)

    return NextResponse.json({
      message: "Registration successful. Please verify your email.",
      userId,
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Registration failed" }, { status: 500 })
  }
}
