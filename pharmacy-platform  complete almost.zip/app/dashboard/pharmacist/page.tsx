"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { useRouter } from "next/navigation"
import {
  Package,
  ShoppingCart,
  AlertTriangle,
  Eye,
  DollarSign,
  CheckCircle,
  XCircle,
  Truck,
  Settings,
} from "lucide-react"

export default function PharmacistDashboard() {
  const [user, setUser] = useState<any>(null)
  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([])
  const router = useRouter()

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUser(parsedUser)
      } catch (error) {
        console.error("Failed to parse user data:", error)
        router.push("/auth/login")
      }
    } else {
      router.push("/auth/login")
    }
  }, [router])

  const handleLogout = () => {
    // Clear token cookie
    document.cookie = "token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Strict"
    // Clear localStorage
    localStorage.removeItem("user")
    router.push("/auth/login")
  }

  const stats = [
    { label: "Total Inventory", value: "2,847", icon: <Package className="h-5 w-5" />, color: "text-blue-600" },
    { label: "Pending Orders", value: "23", icon: <ShoppingCart className="h-5 w-5" />, color: "text-orange-600" },
    { label: "Today's Sales", value: "₹12,450", icon: <DollarSign className="h-5 w-5" />, color: "text-green-600" },
    { label: "Low Stock Items", value: "15", icon: <AlertTriangle className="h-5 w-5" />, color: "text-red-600" },
  ]

  const pendingOrders = [
    {
      id: "ORD001",
      customer: "John Doe",
      items: ["Paracetamol 500mg", "Vitamin D3"],
      total: 245,
      status: "pending_verification",
      prescriptionImage: "/placeholder.svg?height=100&width=100",
      orderTime: "10:30 AM",
      customerPhone: "+91 98765 43210",
    },
    {
      id: "ORD002",
      customer: "Sarah Wilson",
      items: ["Crocin", "ORS Packets", "Cough Syrup"],
      total: 320,
      status: "verified",
      prescriptionImage: "/placeholder.svg?height=100&width=100",
      orderTime: "11:15 AM",
      customerPhone: "+91 98765 43211",
    },
    {
      id: "ORD003",
      customer: "Mike Johnson",
      items: ["Insulin", "Glucometer Strips"],
      total: 1250,
      status: "ready_for_pickup",
      prescriptionImage: "/placeholder.svg?height=100&width=100",
      orderTime: "9:45 AM",
      customerPhone: "+91 98765 43212",
    },
  ]

  const inventory = [
    {
      id: 1,
      name: "Paracetamol 500mg",
      category: "Pain Relief",
      price: 25,
      stock: 150,
      minStock: 50,
      expiry: "2025-06-15",
      manufacturer: "Sun Pharma",
      available: true,
    },
    {
      id: 2,
      name: "Crocin 650mg",
      category: "Pain Relief",
      price: 35,
      stock: 8,
      minStock: 20,
      expiry: "2024-12-30",
      manufacturer: "GSK",
      available: true,
    },
    {
      id: 3,
      name: "Vitamin D3",
      category: "Vitamins",
      price: 180,
      stock: 75,
      minStock: 25,
      expiry: "2025-03-20",
      manufacturer: "Abbott",
      available: true,
    },
    {
      id: 4,
      name: "Insulin Pen",
      category: "Diabetes",
      price: 450,
      stock: 0,
      minStock: 10,
      expiry: "2024-08-15",
      manufacturer: "Novo Nordisk",
      available: false,
    },
  ]

  const handleMedicineToggle = (medicineId: string) => {
    setSelectedMedicines((prev) =>
      prev.includes(medicineId) ? prev.filter((id) => id !== medicineId) : [...prev, medicineId],
    )
  }

  const handleOrderAction = (orderId: string, action: string) => {
    console.log(`${action} order ${orderId}`)
    // Handle order actions (approve, reject, mark ready, etc.)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Package className="h-12 w-12 mx-auto mb-4 text-green-600 animate-pulse" />
          <h2 className="text-2xl font-semibold mb-2">Loading Pharmacist Dashboard</h2>
          <p className="text-gray-600">Please wait...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <Package className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">MediCare+</h1>
                <p className="text-sm text-gray-600">Pharmacist Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-6 rounded-lg">
            <h1 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h1>
            <p className="opacity-90">Manage your pharmacy inventory and fulfill customer orders efficiently.</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`${stat.color}`}>{stat.icon}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Content */}
          <Tabs defaultValue="orders" className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="inventory">Inventory</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="orders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Pending Orders
                  </CardTitle>
                  <CardDescription>Review and process customer orders</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {pendingOrders.map((order) => (
                      <div key={order.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="font-semibold">Order #{order.id}</h4>
                            <p className="text-sm text-gray-600">
                              {order.customer} • {order.orderTime}
                            </p>
                            <p className="text-sm text-gray-500">{order.customerPhone}</p>
                          </div>
                          <Badge
                            variant={
                              order.status === "pending_verification"
                                ? "destructive"
                                : order.status === "verified"
                                  ? "default"
                                  : "secondary"
                            }
                          >
                            {order.status.replace("_", " ")}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                          <div className="lg:col-span-2">
                            <h5 className="font-medium mb-2">Ordered Items:</h5>
                            <div className="space-y-2">
                              {order.items.map((item, idx) => (
                                <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                                  <span className="text-sm">{item}</span>
                                  <Checkbox
                                    checked={selectedMedicines.includes(`${order.id}-${idx}`)}
                                    onCheckedChange={() => handleMedicineToggle(`${order.id}-${idx}`)}
                                  />
                                </div>
                              ))}
                            </div>
                            <div className="mt-3 flex items-center justify-between">
                              <span className="font-semibold">Total: ₹{order.total}</span>
                              <div className="flex gap-2">
                                {order.status === "pending_verification" && (
                                  <>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleOrderAction(order.id, "reject")}
                                    >
                                      <XCircle className="h-4 w-4 mr-2" />
                                      Reject
                                    </Button>
                                    <Button size="sm" onClick={() => handleOrderAction(order.id, "verify")}>
                                      <CheckCircle className="h-4 w-4 mr-2" />
                                      Verify & Accept
                                    </Button>
                                  </>
                                )}
                                {order.status === "verified" && (
                                  <Button size="sm" onClick={() => handleOrderAction(order.id, "ready")}>
                                    <Package className="h-4 w-4 mr-2" />
                                    Mark Ready
                                  </Button>
                                )}
                                {order.status === "ready_for_pickup" && (
                                  <Button size="sm" onClick={() => handleOrderAction(order.id, "dispatch")}>
                                    <Truck className="h-4 w-4 mr-2" />
                                    Dispatch
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>

                          <div>
                            <h5 className="font-medium mb-2">Prescription:</h5>
                            <div className="border rounded-lg p-2">
                              <img
                                src={order.prescriptionImage || "/placeholder.svg"}
                                alt="Prescription"
                                className="w-full h-32 object-cover rounded"
                              />
                              <Button variant="outline" size="sm" className="w-full mt-2">
                                <Eye className="h-4 w-4 mr-2" />
                                View Full Size
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Add other tab contents */}
            <TabsContent value="inventory">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Inventory Management
                  </CardTitle>
                  <CardDescription>Manage your medicine inventory</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Medicine</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Category</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Price</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Stock</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Expiry</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Status</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {inventory.map((item) => (
                          <tr key={item.id} className="border-t">
                            <td className="px-4 py-3">
                              <div>
                                <p className="font-medium">{item.name}</p>
                                <p className="text-xs text-gray-500">{item.manufacturer}</p>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm">{item.category}</td>
                            <td className="px-4 py-3 text-sm">₹{item.price}</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center">
                                <span
                                  className={`inline-block w-2 h-2 rounded-full mr-2 ${
                                    item.stock === 0
                                      ? "bg-red-500"
                                      : item.stock < item.minStock
                                        ? "bg-yellow-500"
                                        : "bg-green-500"
                                  }`}
                                ></span>
                                <span className="text-sm">{item.stock}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm">{item.expiry}</td>
                            <td className="px-4 py-3">
                              <Badge variant={item.available ? "default" : "secondary"}>
                                {item.available ? "In Stock" : "Out of Stock"}
                              </Badge>
                            </td>
                            <td className="px-4 py-3">
                              <Button variant="outline" size="sm">
                                Update
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Sales Analytics
                  </CardTitle>
                  <CardDescription>Track your pharmacy performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <Card>
                      <CardContent className="p-6 text-center">
                        <DollarSign className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <h3 className="font-medium">Monthly Revenue</h3>
                        <p className="text-2xl font-bold">₹1,45,250</p>
                        <p className="text-xs text-green-600">↑ 12% from last month</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-6 text-center">
                        <ShoppingCart className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <h3 className="font-medium">Total Orders</h3>
                        <p className="text-2xl font-bold">324</p>
                        <p className="text-xs text-green-600">↑ 8% from last month</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-6 text-center">
                        <AlertTriangle className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                        <h3 className="font-medium">Expiring Soon</h3>
                        <p className="text-2xl font-bold">12</p>
                        <p className="text-xs text-gray-500">Items expiring in 30 days</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Sales chart will be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Pharmacy Settings
                  </CardTitle>
                  <CardDescription>Manage your pharmacy profile and preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Pharmacy Name</label>
                        <input type="text" className="w-full p-2 border rounded-md" defaultValue="Apollo Pharmacy" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">License Number</label>
                        <input type="text" className="w-full p-2 border rounded-md" defaultValue="PH987654321" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Contact Email</label>
                        <input
                          type="email"
                          className="w-full p-2 border rounded-md"
                          defaultValue="apollo@example.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Contact Phone</label>
                        <input type="tel" className="w-full p-2 border rounded-md" defaultValue="+91 98765 43212" />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-sm font-medium">Address</label>
                        <textarea
                          className="w-full p-2 border rounded-md"
                          rows={3}
                          defaultValue="789 Pharmacy Road, Mumbai, Maharashtra - 400003"
                        ></textarea>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Operating Hours</label>
                        <input type="text" className="w-full p-2 border rounded-md" defaultValue="9:00 AM - 10:00 PM" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Delivery Radius (km)</label>
                        <input type="number" className="w-full p-2 border rounded-md" defaultValue="25" />
                      </div>
                    </div>
                    <Button>Save Settings</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
