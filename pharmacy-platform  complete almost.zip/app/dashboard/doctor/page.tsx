"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"
import {
  Calendar,
  Clock,
  Video,
  FileText,
  Users,
  Stethoscope,
  PillIcon as Prescription,
  DollarSign,
  Star,
  Settings,
  Search,
} from "lucide-react"

export default function DoctorDashboard() {
  const [user, setUser] = useState<any>(null)
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUser(parsedUser)
      } catch (error) {
        console.error("Failed to parse user data:", error)
        router.push("/auth/login")
      }
    } else {
      router.push("/auth/login")
    }
  }, [router])

  const handleLogout = () => {
    // Clear token cookie
    document.cookie = "token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Strict"
    // Clear localStorage
    localStorage.removeItem("user")
    router.push("/auth/login")
  }

  const handleStartCall = (appointmentId: number) => {
    alert(`Starting video call for appointment ${appointmentId}`)
    // In a real app, this would open the video call interface
  }

  const handleEndConsultation = (appointmentId: number) => {
    if (confirm("Are you sure you want to end this consultation?")) {
      alert(`Consultation ${appointmentId} ended`)
      // In a real app, this would update the appointment status
    }
  }

  const handleViewDetails = (appointmentId: number) => {
    alert(`Viewing details for appointment ${appointmentId}`)
    // In a real app, this would open the appointment details modal
  }

  const handleStartConsultation = (patientId: number) => {
    alert(`Starting consultation with patient ${patientId}`)
    // In a real app, this would open the consultation interface
  }

  const handleViewRecord = (patientId: number) => {
    alert(`Viewing full record for patient ${patientId}`)
    // In a real app, this would open the patient record viewer
  }

  const handleCreatePrescription = (patientId?: number) => {
    if (patientId) {
      alert(`Creating prescription for patient ${patientId}`)
    } else {
      alert("Opening prescription creation form")
    }
    // In a real app, this would open the prescription form
  }

  const todayAppointments = [
    {
      id: 1,
      patient: "John Doe",
      time: "10:00 AM",
      type: "Video Consultation",
      status: "upcoming",
      reason: "Follow-up checkup",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      patient: "Sarah Wilson",
      time: "11:30 AM",
      type: "In-person",
      status: "in_progress",
      reason: "Chest pain",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 3,
      patient: "Mike Johnson",
      time: "2:00 PM",
      type: "Video Consultation",
      status: "upcoming",
      reason: "Diabetes consultation",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 4,
      patient: "Emily Davis",
      time: "3:30 PM",
      type: "In-person",
      status: "upcoming",
      reason: "Routine checkup",
      image: "/placeholder.svg?height=40&width=40",
    },
  ]

  const recentPatients = [
    {
      id: 1,
      name: "John Doe",
      age: 45,
      lastVisit: "2024-01-15",
      condition: "Hypertension",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      name: "Sarah Wilson",
      age: 32,
      lastVisit: "2024-01-14",
      condition: "Anxiety",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 3,
      name: "Mike Johnson",
      age: 58,
      lastVisit: "2024-01-12",
      condition: "Diabetes Type 2",
      image: "/placeholder.svg?height=40&width=40",
    },
  ]

  const stats = [
    { label: "Today's Appointments", value: "8", icon: <Calendar className="h-5 w-5" />, color: "text-blue-600" },
    { label: "Total Patients", value: "1,247", icon: <Users className="h-5 w-5" />, color: "text-green-600" },
    {
      label: "This Month Earnings",
      value: "₹45,000",
      icon: <DollarSign className="h-5 w-5" />,
      color: "text-purple-600",
    },
    { label: "Average Rating", value: "4.9", icon: <Star className="h-5 w-5" />, color: "text-yellow-600" },
  ]

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Stethoscope className="h-12 w-12 mx-auto mb-4 text-blue-600 animate-pulse" />
          <h2 className="text-2xl font-semibold mb-2">Loading Doctor Dashboard</h2>
          <p className="text-gray-600">Please wait...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <Stethoscope className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">MediCare+</h1>
                <p className="text-sm text-gray-600">Doctor Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-lg">
            <h1 className="text-2xl font-bold mb-2">Good morning, {user.name}!</h1>
            <p className="opacity-90">You have 8 appointments scheduled for today. Ready to help your patients?</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`${stat.color}`}>{stat.icon}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Content */}
          <Tabs defaultValue="appointments" className="space-y-4">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="appointments">Appointments</TabsTrigger>
              <TabsTrigger value="patients">Patients</TabsTrigger>
              <TabsTrigger value="consultation">Consultation</TabsTrigger>
              <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="appointments" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Today's Schedule */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5" />
                      Today's Schedule
                    </CardTitle>
                    <CardDescription>January 20, 2024</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {todayAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar>
                          <AvatarImage src={appointment.image || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.patient
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h4 className="font-semibold">{appointment.patient}</h4>
                          <p className="text-sm text-gray-600">{appointment.reason}</p>
                          <div className="flex items-center gap-4 mt-2 text-sm">
                            <span className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {appointment.time}
                            </span>
                            <Badge variant={appointment.type === "Video Consultation" ? "default" : "secondary"}>
                              {appointment.type === "Video Consultation" ? (
                                <Video className="h-3 w-3 mr-1" />
                              ) : (
                                <Stethoscope className="h-3 w-3 mr-1" />
                              )}
                              {appointment.type}
                            </Badge>
                            <Badge
                              variant={
                                appointment.status === "in_progress"
                                  ? "destructive"
                                  : appointment.status === "completed"
                                    ? "default"
                                    : "secondary"
                              }
                            >
                              {appointment.status.replace("_", " ")}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          {appointment.status === "upcoming" && appointment.type === "Video Consultation" && (
                            <Button size="sm" onClick={() => handleStartCall(appointment.id)}>
                              <Video className="h-4 w-4 mr-2" />
                              Start Call
                            </Button>
                          )}
                          {appointment.status === "in_progress" && (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleEndConsultation(appointment.id)}
                            >
                              End Consultation
                            </Button>
                          )}
                          <Button variant="outline" size="sm" onClick={() => handleViewDetails(appointment.id)}>
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      className="w-full justify-start"
                      variant="outline"
                      onClick={() => alert("Opening calendar...")}
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      View Full Calendar
                    </Button>
                    <Button
                      className="w-full justify-start"
                      variant="outline"
                      onClick={() => alert("Opening patient records...")}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Patient Records
                    </Button>
                    <Button
                      className="w-full justify-start"
                      variant="outline"
                      onClick={() => handleCreatePrescription()}
                    >
                      <Prescription className="h-4 w-4 mr-2" />
                      Create Prescription
                    </Button>
                    <Button
                      className="w-full justify-start"
                      variant="outline"
                      onClick={() => alert("Opening medical notes...")}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Medical Notes
                    </Button>
                    <Button
                      className="w-full justify-start"
                      variant="outline"
                      onClick={() => alert("Opening availability settings...")}
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Availability Settings
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="patients">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Patient Records</CardTitle>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input placeholder="Search patients..." className="pl-10" />
                      </div>
                      <Button onClick={() => alert("Adding new patient...")}>Add Patient</Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentPatients.map((patient) => (
                        <div
                          key={patient.id}
                          className="flex items-center space-x-4 p-4 border rounded-lg cursor-pointer hover:bg-gray-50"
                          onClick={() => setSelectedPatient(patient)}
                        >
                          <Avatar>
                            <AvatarImage src={patient.image || "/placeholder.svg"} />
                            <AvatarFallback>
                              {patient.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <h4 className="font-semibold">{patient.name}</h4>
                            <p className="text-sm text-gray-600">
                              Age: {patient.age} • Last visit: {patient.lastVisit}
                            </p>
                            <p className="text-sm text-gray-500">{patient.condition}</p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleViewRecord(patient.id)
                            }}
                          >
                            View Record
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {selectedPatient && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Patient Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center">
                        <Avatar className="h-20 w-20 mx-auto mb-4">
                          <AvatarImage src={selectedPatient.image || "/placeholder.svg"} />
                          <AvatarFallback>
                            {selectedPatient.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <h3 className="font-semibold text-lg">{selectedPatient.name}</h3>
                        <p className="text-gray-600">Age: {selectedPatient.age}</p>
                      </div>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm font-medium">Primary Condition</Label>
                          <p className="text-sm">{selectedPatient.condition}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Last Visit</Label>
                          <p className="text-sm">{selectedPatient.lastVisit}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Contact</Label>
                          <p className="text-sm">+91 98765 43210</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Button
                          className="w-full"
                          size="sm"
                          onClick={() => handleStartConsultation(selectedPatient.id)}
                        >
                          <Video className="h-4 w-4 mr-2" />
                          Start Consultation
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          size="sm"
                          onClick={() => handleViewRecord(selectedPatient.id)}
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          View Full Record
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          size="sm"
                          onClick={() => handleCreatePrescription(selectedPatient.id)}
                        >
                          <Prescription className="h-4 w-4 mr-2" />
                          Create Prescription
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            <TabsContent value="consultation">
              <div className="text-center p-8">
                <Video className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Video Consultation</h3>
                <p className="text-gray-600 mb-4">Consultation interface will be implemented here</p>
                <Button onClick={() => alert("Starting video consultation...")}>
                  <Video className="h-4 w-4 mr-2" />
                  Start New Consultation
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="prescriptions">
              <div className="text-center p-8">
                <Prescription className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Prescription Management</h3>
                <p className="text-gray-600 mb-4">Prescription creation interface will be implemented here</p>
                <Button onClick={() => handleCreatePrescription()}>
                  <Prescription className="h-4 w-4 mr-2" />
                  Create New Prescription
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="analytics">
              <div className="text-center p-8">
                <Star className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Analytics Dashboard</h3>
                <p className="text-gray-600 mb-4">Performance analytics will be implemented here</p>
                <Button onClick={() => alert("Opening analytics dashboard...")}>View Analytics</Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
