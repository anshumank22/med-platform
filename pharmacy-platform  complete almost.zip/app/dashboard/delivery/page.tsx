"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Truck, MapPin, Navigation, Clock, Phone, CheckCircle, Package, DollarSign, Star, Route } from "lucide-react"

export default function DeliveryDashboard() {
  const [user, setUser] = useState<any>(null)
  const [currentLocation, setCurrentLocation] = useState({ lat: 19.076, lng: 72.8777 }) // Mumbai coordinates

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [])

  const stats = [
    { label: "Today's Deliveries", value: "12", icon: <Package className="h-5 w-5" />, color: "text-blue-600" },
    { label: "Completed", value: "8", icon: <CheckCircle className="h-5 w-5" />, color: "text-green-600" },
    { label: "Today's Earnings", value: "₹960", icon: <DollarSign className="h-5 w-5" />, color: "text-purple-600" },
    { label: "Rating", value: "4.8", icon: <Star className="h-5 w-5" />, color: "text-yellow-600" },
  ]

  const assignedDeliveries = [
    {
      id: "DEL001",
      orderId: "ORD001",
      customer: "John Doe",
      phone: "+91 98765 43210",
      address: "123 Linking Road, Bandra West, Mumbai - 400050",
      items: ["Paracetamol 500mg", "Vitamin D3"],
      amount: 245,
      status: "picked_up",
      pharmacy: "Apollo Pharmacy, Bandra",
      estimatedTime: "15 mins",
      otp: "1234",
      priority: "normal",
    },
    {
      id: "DEL002",
      orderId: "ORD002",
      customer: "Sarah Wilson",
      phone: "+91 98765 43211",
      address: "456 Hill Road, Bandra West, Mumbai - 400050",
      items: ["Crocin", "ORS Packets", "Cough Syrup"],
      amount: 320,
      status: "assigned",
      pharmacy: "MedPlus, Bandra",
      estimatedTime: "25 mins",
      otp: "5678",
      priority: "urgent",
    },
    {
      id: "DEL003",
      orderId: "ORD003",
      customer: "Mike Johnson",
      phone: "+91 98765 43212",
      address: "789 Carter Road, Bandra West, Mumbai - 400050",
      items: ["Insulin", "Glucometer Strips"],
      amount: 1250,
      status: "out_for_delivery",
      pharmacy: "Wellness Pharmacy, Bandra",
      estimatedTime: "10 mins",
      otp: "9012",
      priority: "urgent",
    },
  ]

  const deliveryHistory = [
    {
      id: "DEL_H001",
      date: "2024-01-19",
      deliveries: 15,
      earnings: 1200,
      rating: 4.9,
    },
    {
      id: "DEL_H002",
      date: "2024-01-18",
      deliveries: 12,
      earnings: 960,
      rating: 4.8,
    },
    {
      id: "DEL_H003",
      date: "2024-01-17",
      deliveries: 18,
      earnings: 1440,
      rating: 4.7,
    },
  ]

  const handleStatusUpdate = (deliveryId: string, newStatus: string) => {
    console.log(`Updating delivery ${deliveryId} to ${newStatus}`)
    // Handle status update logic
  }

  const handleGetDirections = (address: string) => {
    // Open Google Maps with directions
    const encodedAddress = encodeURIComponent(address)
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, "_blank")
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-orange-600 text-white p-2 rounded-lg">
                <Truck className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">MediCare+</h1>
                <p className="text-sm text-gray-600">Delivery Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button
                variant="outline"
                onClick={() => {
                  localStorage.removeItem("user")
                  window.location.href = "/auth/login"
                }}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white p-6 rounded-lg">
            <h1 className="text-2xl font-bold mb-2">Ready for deliveries, {user.name}!</h1>
            <p className="opacity-90">You have 4 deliveries assigned for today. Let's make them happen!</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`${stat.color}`}>{stat.icon}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Content */}
          <Tabs defaultValue="deliveries" className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="deliveries">Active Deliveries</TabsTrigger>
              <TabsTrigger value="map">Route Map</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
              <TabsTrigger value="profile">Profile</TabsTrigger>
            </TabsList>

            <TabsContent value="deliveries" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    Assigned Deliveries
                  </CardTitle>
                  <CardDescription>Manage your delivery queue and update status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {assignedDeliveries.map((delivery) => (
                      <div key={delivery.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold">Delivery #{delivery.id}</h4>
                              <Badge variant={delivery.priority === "urgent" ? "destructive" : "secondary"}>
                                {delivery.priority}
                              </Badge>
                              <Badge
                                variant={
                                  delivery.status === "assigned"
                                    ? "secondary"
                                    : delivery.status === "picked_up"
                                      ? "default"
                                      : delivery.status === "out_for_delivery"
                                        ? "default"
                                        : "default"
                                }
                              >
                                {delivery.status.replace("_", " ")}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">Order #{delivery.orderId}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">₹{delivery.amount}</p>
                            <p className="text-sm text-gray-500">Est: {delivery.estimatedTime}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                          <div className="space-y-3">
                            <div>
                              <Label className="text-sm font-medium">Customer</Label>
                              <p className="text-sm">{delivery.customer}</p>
                              <p className="text-sm text-gray-600">{delivery.phone}</p>
                            </div>
                            <div>
                              <Label className="text-sm font-medium">Pickup Location</Label>
                              <p className="text-sm">{delivery.pharmacy}</p>
                            </div>
                            <div>
                              <Label className="text-sm font-medium">Delivery Address</Label>
                              <p className="text-sm">{delivery.address}</p>
                            </div>
                            <div>
                              <Label className="text-sm font-medium">Items</Label>
                              <p className="text-sm">{delivery.items.join(", ")}</p>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <Label className="text-sm font-medium">Delivery OTP</Label>
                              <div className="bg-gray-100 p-2 rounded text-center">
                                <span className="text-2xl font-bold text-blue-600">{delivery.otp}</span>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <Button
                                className="w-full"
                                variant="outline"
                                onClick={() => handleGetDirections(delivery.address)}
                              >
                                <Navigation className="h-4 w-4 mr-2" />
                                Get Directions
                              </Button>

                              <Button
                                className="w-full"
                                variant="outline"
                                onClick={() => window.open(`tel:${delivery.phone}`)}
                              >
                                <Phone className="h-4 w-4 mr-2" />
                                Call Customer
                              </Button>
                            </div>

                            <div className="space-y-2">
                              {delivery.status === "assigned" && (
                                <Button className="w-full" onClick={() => handleStatusUpdate(delivery.id, "picked_up")}>
                                  <Package className="h-4 w-4 mr-2" />
                                  Mark as Picked Up
                                </Button>
                              )}

                              {delivery.status === "picked_up" && (
                                <Button
                                  className="w-full"
                                  onClick={() => handleStatusUpdate(delivery.id, "out_for_delivery")}
                                >
                                  <Truck className="h-4 w-4 mr-2" />
                                  Out for Delivery
                                </Button>
                              )}

                              {delivery.status === "out_for_delivery" && (
                                <Button className="w-full" onClick={() => handleStatusUpdate(delivery.id, "delivered")}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Mark as Delivered
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="map">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Delivery Route Map
                  </CardTitle>
                  <CardDescription>Optimized route for your deliveries</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-200 rounded-lg aspect-video flex items-center justify-center mb-4">
                    <div className="text-center text-gray-600">
                      <MapPin className="h-12 w-12 mx-auto mb-2" />
                      <p>Interactive Google Maps would be integrated here</p>
                      <p className="text-sm">Showing optimized route for all deliveries</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Route className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <p className="font-semibold">Total Distance</p>
                        <p className="text-2xl font-bold">24.5 km</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Clock className="h-8 w-8 text-green-600 mx-auto mb-2" />
                        <p className="font-semibold">Estimated Time</p>
                        <p className="text-2xl font-bold">2h 15m</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Truck className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                        <p className="font-semibold">Stops</p>
                        <p className="text-2xl font-bold">4</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <div className="text-center p-8">
                <Clock className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Delivery History</h3>
                <p className="text-gray-600">Past delivery records will be shown here</p>
              </div>
            </TabsContent>

            <TabsContent value="profile">
              <div className="text-center p-8">
                <Star className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Profile Settings</h3>
                <p className="text-gray-600">Profile management interface will be implemented here</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
