"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"
import {
  Calendar,
  Pill,
  FileText,
  Clock,
  MapPin,
  Video,
  Upload,
  Heart,
  Activity,
  TrendingUp,
  Package,
  Truck,
} from "lucide-react"

export default function CustomerDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/auth/login")
  }

  const handleBookAppointment = () => {
    router.push("/doctors")
  }

  const handleOrderMedicinesAction = () => {
    router.push("/medicines")
  }

  const handleLabTests = () => {
    router.push("/lab-tests")
  }

  const handleUploadPrescription = () => {
    router.push("/upload-prescription")
  }

  const handleJoinCall = (appointmentId: number) => {
    alert(`Starting video call for appointment ${appointmentId}`)
    // In a real app, this would open the video call interface
  }

  const handleReschedule = (appointmentId: number) => {
    alert(`Rescheduling appointment ${appointmentId}`)
    // In a real app, this would open the reschedule modal
  }

  const handleCancelAppointment = (appointmentId: number) => {
    if (confirm("Are you sure you want to cancel this appointment?")) {
      alert(`Appointment ${appointmentId} cancelled`)
      // In a real app, this would call the API to cancel
    }
  }

  const handleTrackOrder = (orderId: string) => {
    alert(`Tracking order ${orderId}`)
    // In a real app, this would open the order tracking page
  }

  const handleReorder = (orderId: string) => {
    alert(`Reordering items from order ${orderId}`)
    // In a real app, this would add items to cart
  }

  const handleViewPrescription = (prescriptionId: number) => {
    alert(`Viewing prescription ${prescriptionId}`)
    // In a real app, this would open the prescription viewer
  }

  const handleOrderMedicines = (prescriptionId: number) => {
    alert(`Ordering medicines from prescription ${prescriptionId}`)
    // In a real app, this would redirect to pharmacy with prescription
  }

  const handleDownloadPrescription = (prescriptionId: number) => {
    alert(`Downloading prescription ${prescriptionId} as PDF`)
    // In a real app, this would generate and download PDF
  }

  const handleUpdateHealthInfo = () => {
    alert("Opening health information update form")
    // In a real app, this would open a form modal
  }

  const handleDownloadRecords = () => {
    alert("Downloading health records")
    // In a real app, this would generate and download health records
  }

  const handleShareWithDoctor = () => {
    alert("Opening doctor sharing options")
    // In a real app, this would open sharing modal
  }

  const upcomingAppointments = [
    {
      id: 1,
      doctor: "Dr. Priya Sharma",
      specialty: "Cardiologist",
      date: "Today",
      time: "2:00 PM",
      type: "Video Consultation",
      status: "confirmed",
      image: "/placeholder.svg?height=50&width=50",
    },
    {
      id: 2,
      doctor: "Dr. Rajesh Kumar",
      specialty: "General Physician",
      date: "Tomorrow",
      time: "10:30 AM",
      type: "In-person",
      status: "confirmed",
      image: "/placeholder.svg?height=50&width=50",
    },
  ]

  const recentOrders = [
    {
      id: "ORD001",
      items: ["Paracetamol 500mg", "Vitamin D3"],
      total: 245,
      status: "delivered",
      date: "2024-01-15",
      pharmacy: "Apollo Pharmacy",
    },
    {
      id: "ORD002",
      items: ["Crocin", "ORS Packets"],
      total: 180,
      status: "in_transit",
      date: "2024-01-18",
      pharmacy: "MedPlus",
    },
  ]

  const healthMetrics = [
    { label: "Blood Pressure", value: "120/80", status: "normal", icon: <Heart className="h-4 w-4" /> },
    { label: "Heart Rate", value: "72 bpm", status: "normal", icon: <Activity className="h-4 w-4" /> },
    { label: "Weight", value: "68 kg", status: "normal", icon: <TrendingUp className="h-4 w-4" /> },
    { label: "BMI", value: "22.5", status: "normal", icon: <Activity className="h-4 w-4" /> },
  ]

  const prescriptions = [
    {
      id: 1,
      doctor: "Dr. Priya Sharma",
      date: "2024-01-15",
      medicines: ["Paracetamol 500mg", "Vitamin D3", "Calcium"],
      status: "active",
    },
    {
      id: 2,
      doctor: "Dr. Rajesh Kumar",
      date: "2024-01-10",
      medicines: ["Crocin", "ORS Packets"],
      status: "completed",
    },
  ]

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <Pill className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">MediCare+</h1>
                <p className="text-sm text-gray-600">Customer Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-lg">
            <h1 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h1>
            <p className="opacity-90">Your health dashboard is ready. Stay on top of your wellness journey.</p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Book Appointment</h3>
                <p className="text-sm text-gray-600 mb-3">Find and book with verified doctors</p>
                <Button size="sm" onClick={handleBookAppointment}>
                  Book Now
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <Pill className="h-8 w-8 text-green-600 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Order Medicines</h3>
                <p className="text-sm text-gray-600 mb-3">Upload prescription and order</p>
                <Button size="sm" onClick={handleOrderMedicinesAction}>
                  Order Now
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <FileText className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Lab Tests</h3>
                <p className="text-sm text-gray-600 mb-3">Book diagnostic tests</p>
                <Button size="sm" onClick={handleLabTests}>
                  Book Test
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <Upload className="h-8 w-8 text-orange-600 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Upload Prescription</h3>
                <p className="text-sm text-gray-600 mb-3">Quick medicine order</p>
                <Button size="sm" onClick={handleUploadPrescription}>
                  Upload
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="appointments">Appointments</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
              <TabsTrigger value="health">Health Records</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Upcoming Appointments */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5" />
                      Upcoming Appointments
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {upcomingAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar>
                          <AvatarImage src={appointment.image || "/placeholder.svg"} />
                          <AvatarFallback>{appointment.doctor.split(" ").map((n) => n[0])}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h4 className="font-semibold">{appointment.doctor}</h4>
                          <p className="text-sm text-gray-600">{appointment.specialty}</p>
                          <div className="flex items-center gap-4 mt-2 text-sm">
                            <span className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {appointment.date} at {appointment.time}
                            </span>
                            <Badge variant={appointment.type === "Video Consultation" ? "default" : "secondary"}>
                              {appointment.type === "Video Consultation" ? (
                                <Video className="h-3 w-3 mr-1" />
                              ) : (
                                <MapPin className="h-3 w-3 mr-1" />
                              )}
                              {appointment.type}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          {appointment.type === "Video Consultation" && appointment.date === "Today" && (
                            <Button size="sm" onClick={() => handleJoinCall(appointment.id)}>
                              <Video className="h-4 w-4 mr-2" />
                              Join Call
                            </Button>
                          )}
                          <Button variant="outline" size="sm" onClick={() => handleReschedule(appointment.id)}>
                            Reschedule
                          </Button>
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full" onClick={() => alert("Viewing all appointments...")}>
                      View All Appointments
                    </Button>
                  </CardContent>
                </Card>

                {/* Health Metrics */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      Health Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {healthMetrics.map((metric, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {metric.icon}
                          <span className="text-sm font-medium">{metric.label}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{metric.value}</div>
                          <Badge variant={metric.status === "normal" ? "default" : "destructive"} className="text-xs">
                            {metric.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full" onClick={() => alert("Viewing health details...")}>
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Orders */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Recent Orders
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentOrders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="bg-blue-100 p-2 rounded-lg">
                            <Package className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Order #{order.id}</h4>
                            <p className="text-sm text-gray-600">{order.items.join(", ")}</p>
                            <p className="text-sm text-gray-500">
                              {order.pharmacy} • {order.date}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">₹{order.total}</div>
                          <Badge variant={order.status === "delivered" ? "default" : "secondary"}>
                            {order.status === "delivered" ? "Delivered" : "In Transit"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full mt-4" onClick={() => alert("Viewing all orders...")}>
                    View All Orders
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="appointments">
              <Card>
                <CardHeader>
                  <CardTitle>All Appointments</CardTitle>
                  <CardDescription>Manage your upcoming and past appointments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcomingAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <Avatar>
                            <AvatarImage src={appointment.image || "/placeholder.svg"} />
                            <AvatarFallback>{appointment.doctor.split(" ").map((n) => n[0])}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{appointment.doctor}</h4>
                            <p className="text-sm text-gray-600">{appointment.specialty}</p>
                            <div className="flex items-center gap-4 mt-2 text-sm">
                              <span className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {appointment.date} at {appointment.time}
                              </span>
                              <Badge variant={appointment.type === "Video Consultation" ? "default" : "secondary"}>
                                {appointment.type}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleReschedule(appointment.id)}>
                            Reschedule
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleCancelAppointment(appointment.id)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle>Order History</CardTitle>
                  <CardDescription>Track your medicine orders and deliveries</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentOrders.map((order) => (
                      <div key={order.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-semibold">Order #{order.id}</h4>
                          <Badge variant={order.status === "delivered" ? "default" : "secondary"}>
                            {order.status === "delivered" ? "Delivered" : "In Transit"}
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Items:</strong> {order.items.join(", ")}
                          </p>
                          <p>
                            <strong>Pharmacy:</strong> {order.pharmacy}
                          </p>
                          <p>
                            <strong>Date:</strong> {order.date}
                          </p>
                          <p>
                            <strong>Total:</strong> ₹{order.total}
                          </p>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button variant="outline" size="sm" onClick={() => alert(`Viewing details for ${order.id}`)}>
                            View Details
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleReorder(order.id)}>
                            Reorder
                          </Button>
                          {order.status === "in_transit" && (
                            <Button variant="outline" size="sm" onClick={() => handleTrackOrder(order.id)}>
                              <Truck className="h-4 w-4 mr-2" />
                              Track Order
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="prescriptions">
              <Card>
                <CardHeader>
                  <CardTitle>My Prescriptions</CardTitle>
                  <CardDescription>View and manage your digital prescriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {prescriptions.map((prescription) => (
                      <div key={prescription.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-semibold">Prescription from {prescription.doctor}</h4>
                          <Badge variant={prescription.status === "active" ? "default" : "secondary"}>
                            {prescription.status}
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Date:</strong> {prescription.date}
                          </p>
                          <p>
                            <strong>Medicines:</strong> {prescription.medicines.join(", ")}
                          </p>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button variant="outline" size="sm" onClick={() => handleViewPrescription(prescription.id)}>
                            View Full Prescription
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleOrderMedicines(prescription.id)}>
                            Order Medicines
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownloadPrescription(prescription.id)}
                          >
                            Download PDF
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="health">
              <Card>
                <CardHeader>
                  <CardTitle>Health Records</CardTitle>
                  <CardDescription>Your comprehensive health information and history</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Vital Signs</h3>
                      {healthMetrics.map((metric, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2">
                            {metric.icon}
                            <span className="font-medium">{metric.label}</span>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{metric.value}</div>
                            <Badge variant={metric.status === "normal" ? "default" : "destructive"} className="text-xs">
                              {metric.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="space-y-4">
                      <h3 className="font-semibold">Medical History</h3>
                      <div className="space-y-3">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <h4 className="font-medium">Allergies</h4>
                          <p className="text-sm text-gray-600">Penicillin, Shellfish</p>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <h4 className="font-medium">Chronic Conditions</h4>
                          <p className="text-sm text-gray-600">None reported</p>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <h4 className="font-medium">Blood Type</h4>
                          <p className="text-sm text-gray-600">O+</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex gap-2">
                    <Button variant="outline" onClick={handleUpdateHealthInfo}>
                      Update Health Info
                    </Button>
                    <Button variant="outline" onClick={handleDownloadRecords}>
                      Download Records
                    </Button>
                    <Button variant="outline" onClick={handleShareWithDoctor}>
                      Share with Doctor
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
