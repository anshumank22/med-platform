"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import {
  Shield,
  Users,
  DollarSign,
  Activity,
  Search,
  Edit,
  Eye,
  CheckCircle,
  XCircle,
  Settings,
  BarChart3,
  UserCheck,
  UserX,
  Building2,
  Truck,
  Stethoscope,
  Package,
  AlertTriangle,
  TrendingUp,
  FileText,
} from "lucide-react"

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null)
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUser(parsedUser)
      } catch (error) {
        console.error("Failed to parse user data:", error)
        router.push("/auth/login")
      }
    } else {
      router.push("/auth/login")
    }
  }, [router])

  const handleLogout = () => {
    // Clear token cookie
    document.cookie = "token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Strict"
    // Clear localStorage
    localStorage.removeItem("user")
    router.push("/auth/login")
  }

  const stats = [
    { label: "Total Users", value: "12,847", icon: <Users className="h-5 w-5" />, color: "text-blue-600" },
    { label: "Total Revenue", value: "₹2,45,600", icon: <DollarSign className="h-5 w-5" />, color: "text-green-600" },
    { label: "Active Orders", value: "156", icon: <Package className="h-5 w-5" />, color: "text-purple-600" },
    { label: "System Health", value: "99.9%", icon: <Activity className="h-5 w-5" />, color: "text-orange-600" },
  ]

  const pendingApprovals = [
    {
      id: 1,
      name: "Dr. Amit Sharma",
      type: "doctor",
      email: "amit.sharma@email.com",
      phone: "+91 98765 43210",
      specialization: "Cardiology",
      license: "MH123456789",
      joinDate: "2024-01-20",
      status: "pending",
    },
    {
      id: 2,
      name: "MedPlus Pharmacy",
      type: "pharmacist",
      email: "medplus@email.com",
      phone: "+91 98765 43211",
      license: "PH987654321",
      address: "Mumbai, Maharashtra",
      joinDate: "2024-01-19",
      status: "pending",
    },
    {
      id: 3,
      name: "Raj Kumar",
      type: "delivery",
      email: "raj.delivery@email.com",
      phone: "+91 98765 43212",
      vehicle: "MH01AB1234",
      license: "DL123456789",
      joinDate: "2024-01-18",
      status: "pending",
    },
  ]

  const allUsers = [
    {
      id: 1,
      name: "John Doe",
      type: "customer",
      email: "john@email.com",
      phone: "+91 98765 43213",
      joinDate: "2024-01-15",
      status: "active",
      lastActive: "2 hours ago",
    },
    {
      id: 2,
      name: "Dr. Priya Sharma",
      type: "doctor",
      email: "priya@email.com",
      phone: "+91 98765 43214",
      specialization: "General Physician",
      joinDate: "2024-01-10",
      status: "active",
      lastActive: "1 hour ago",
    },
    {
      id: 3,
      name: "Apollo Pharmacy",
      type: "pharmacist",
      email: "apollo@email.com",
      phone: "+91 98765 43215",
      joinDate: "2024-01-08",
      status: "active",
      lastActive: "30 minutes ago",
    },
    {
      id: 4,
      name: "Delivery Agent 1",
      type: "delivery",
      email: "delivery1@email.com",
      phone: "+91 98765 43216",
      joinDate: "2024-01-05",
      status: "active",
      lastActive: "5 minutes ago",
    },
  ]

  const systemAlerts = [
    {
      id: 1,
      type: "warning",
      message: "High server load detected - 85% CPU usage",
      timestamp: "2 minutes ago",
    },
    {
      id: 2,
      type: "info",
      message: "Daily backup completed successfully",
      timestamp: "1 hour ago",
    },
    {
      id: 3,
      type: "error",
      message: "Payment gateway timeout - 3 failed transactions",
      timestamp: "3 hours ago",
    },
  ]

  const recentOrders = [
    {
      id: "ORD001",
      customer: "John Doe",
      pharmacy: "Apollo Pharmacy",
      amount: 245,
      status: "delivered",
      date: "2024-01-20",
    },
    {
      id: "ORD002",
      customer: "Sarah Wilson",
      pharmacy: "MedPlus",
      amount: 320,
      status: "in_transit",
      date: "2024-01-20",
    },
    {
      id: "ORD003",
      customer: "Mike Johnson",
      pharmacy: "Wellness Pharmacy",
      amount: 1250,
      status: "processing",
      date: "2024-01-19",
    },
  ]

  const handleApproval = (userId: number, action: "approve" | "reject") => {
    console.log(`${action} user ${userId}`)
    // Handle approval/rejection logic
  }

  const handleUserAction = (userId: number, action: string) => {
    console.log(`${action} user ${userId}`)
    // Handle user actions (suspend, activate, delete, etc.)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-red-600 text-white p-2 rounded-lg">
                <Shield className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">MediCare+ Admin</h1>
                <p className="text-sm text-gray-600">System Administration Panel</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.name}</span>
              <Button
                variant="outline"
                onClick={() => {
                  localStorage.removeItem("user")
                  window.location.href = "/auth/login"
                }}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-red-600 to-purple-600 text-white p-6 rounded-lg">
            <h1 className="text-2xl font-bold mb-2">Admin Control Center</h1>
            <p className="opacity-90">
              Complete platform oversight with user management, analytics, and system monitoring.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`${stat.color}`}>{stat.icon}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* System Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                System Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {systemAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      alert.type === "error"
                        ? "bg-red-50 border border-red-200"
                        : alert.type === "warning"
                          ? "bg-yellow-50 border border-yellow-200"
                          : "bg-blue-50 border border-blue-200"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <AlertTriangle
                        className={`h-4 w-4 ${
                          alert.type === "error"
                            ? "text-red-600"
                            : alert.type === "warning"
                              ? "text-yellow-600"
                              : "text-blue-600"
                        }`}
                      />
                      <div>
                        <p className="text-sm font-medium">{alert.message}</p>
                        <p className="text-xs text-gray-500">{alert.timestamp}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Resolve
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Main Content */}
          <Tabs defaultValue="approvals" className="space-y-4">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="approvals">Approvals</TabsTrigger>
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="logs">System Logs</TabsTrigger>
            </TabsList>

            <TabsContent value="approvals" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserCheck className="h-5 w-5" />
                    Pending Approvals
                  </CardTitle>
                  <CardDescription>Review and approve new user registrations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {pendingApprovals.map((approval) => (
                      <div key={approval.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="bg-gray-100 p-2 rounded-lg">
                              {approval.type === "doctor" && <Stethoscope className="h-5 w-5" />}
                              {approval.type === "pharmacist" && <Building2 className="h-5 w-5" />}
                              {approval.type === "delivery" && <Truck className="h-5 w-5" />}
                            </div>
                            <div>
                              <h4 className="font-semibold">{approval.name}</h4>
                              <p className="text-sm text-gray-600 capitalize">{approval.type}</p>
                              <p className="text-sm text-gray-500">Applied: {approval.joinDate}</p>
                            </div>
                          </div>
                          <Badge variant="secondary">{approval.status}</Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div className="space-y-2 text-sm">
                            <p>
                              <strong>Email:</strong> {approval.email}
                            </p>
                            <p>
                              <strong>Phone:</strong> {approval.phone}
                            </p>
                            {approval.type === "doctor" && (
                              <>
                                <p>
                                  <strong>Specialization:</strong> {approval.specialization}
                                </p>
                                <p>
                                  <strong>License:</strong> {approval.license}
                                </p>
                              </>
                            )}
                            {approval.type === "pharmacist" && (
                              <>
                                <p>
                                  <strong>License:</strong> {approval.license}
                                </p>
                                <p>
                                  <strong>Address:</strong> {approval.address}
                                </p>
                              </>
                            )}
                            {approval.type === "delivery" && (
                              <>
                                <p>
                                  <strong>Vehicle:</strong> {approval.vehicle}
                                </p>
                                <p>
                                  <strong>License:</strong> {approval.license}
                                </p>
                              </>
                            )}
                          </div>
                          <div className="space-y-2">
                            <Button variant="outline" size="sm" className="w-full">
                              <Eye className="h-4 w-4 mr-2" />
                              View Documents
                            </Button>
                            <Button variant="outline" size="sm" className="w-full">
                              <FileText className="h-4 w-4 mr-2" />
                              Background Check
                            </Button>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleApproval(approval.id, "approve")} className="flex-1">
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleApproval(approval.id, "reject")}
                            className="flex-1"
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="users" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    User Management
                  </CardTitle>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input placeholder="Search users..." className="pl-10" />
                    </div>
                    <Select>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Filter by role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Users</SelectItem>
                        <SelectItem value="customer">Customers</SelectItem>
                        <SelectItem value="doctor">Doctors</SelectItem>
                        <SelectItem value="pharmacist">Pharmacists</SelectItem>
                        <SelectItem value="delivery">Delivery Agents</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {allUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg" />
                            <AvatarFallback>
                              {user.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{user.name}</h4>
                            <p className="text-sm text-gray-600">{user.email}</p>
                            <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                              <span className="capitalize">{user.type}</span>
                              <span>Joined: {user.joinDate}</span>
                              <span>Last active: {user.lastActive}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={user.status === "active" ? "default" : "destructive"}>{user.status}</Badge>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <UserX className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Order Management
                  </CardTitle>
                  <CardDescription>Monitor and manage all platform orders</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentOrders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h4 className="font-semibold">Order #{order.id}</h4>
                          <p className="text-sm text-gray-600">
                            {order.customer} → {order.pharmacy}
                          </p>
                          <p className="text-sm text-gray-500">{order.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">₹{order.amount}</p>
                          <Badge
                            variant={
                              order.status === "delivered"
                                ? "default"
                                : order.status === "in_transit"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {order.status.replace("_", " ")}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Platform Analytics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Total Users</span>
                        <span className="font-semibold">12,847</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Active Doctors</span>
                        <span className="font-semibold">1,247</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Active Pharmacies</span>
                        <span className="font-semibold">456</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Delivery Agents</span>
                        <span className="font-semibold">234</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Monthly Revenue</span>
                        <span className="font-semibold">₹2,45,600</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Growth Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>User Growth (Monthly)</span>
                        <span className="font-semibold text-green-600">+12.5%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Order Volume</span>
                        <span className="font-semibold text-green-600">+18.3%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Revenue Growth</span>
                        <span className="font-semibold text-green-600">+15.7%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Customer Satisfaction</span>
                        <span className="font-semibold">4.8/5</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Platform Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="platform-name">Platform Name</Label>
                      <Input id="platform-name" defaultValue="MediCare+" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="support-email">Support Email</Label>
                      <Input id="support-email" defaultValue="support@medicareplus.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="max-delivery-distance">Max Delivery Distance (km)</Label>
                      <Input id="max-delivery-distance" type="number" defaultValue="25" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="commission-rate">Platform Commission (%)</Label>
                      <Input id="commission-rate" type="number" defaultValue="5" />
                    </div>
                    <Button>Save Settings</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>System Maintenance</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button variant="outline" className="w-full justify-start">
                      <Activity className="h-4 w-4 mr-2" />
                      System Health Check
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Package className="h-4 w-4 mr-2" />
                      Database Backup
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Generate Reports
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Settings className="h-4 w-4 mr-2" />
                      Clear Cache
                    </Button>
                    <Button variant="destructive" className="w-full justify-start">
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Maintenance Mode
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="logs" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    System Logs
                  </CardTitle>
                  <CardDescription>Monitor system activities and audit trails</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-gray-50 rounded-lg text-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">User Login: john@email.com</span>
                        <span className="text-gray-500">2 minutes ago</span>
                      </div>
                      <p className="text-gray-600">Customer login from IP: 192.168.1.1</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg text-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Order Created: ORD001</span>
                        <span className="text-gray-500">5 minutes ago</span>
                      </div>
                      <p className="text-gray-600">New order placed by John Doe - ₹245</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg text-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Doctor Approved: Dr. Amit Sharma</span>
                        <span className="text-gray-500">1 hour ago</span>
                      </div>
                      <p className="text-gray-600">New doctor registration approved by admin</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
