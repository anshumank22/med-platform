import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Simplified middleware without JWT verification for now
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Public routes that don't require authentication
  const publicRoutes = ["/", "/auth/login", "/auth/register", "/auth/forgot-password"]

  if (publicRoutes.includes(pathname)) {
    return NextResponse.next()
  }

  // Check for authentication token
  const token = request.cookies.get("token")?.value

  if (!token) {
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }

  try {
    // Simple token verification
    const payload = JSON.parse(Buffer.from(token, "base64").toString())

    // Check if token is not older than 7 days
    if (Date.now() - payload.timestamp > 7 * 24 * 60 * 60 * 1000) {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    // Role-based access control
    if (pathname.startsWith("/dashboard/admin") && payload.role !== "admin") {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    if (pathname.startsWith("/dashboard/doctor") && payload.role !== "doctor") {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    if (pathname.startsWith("/dashboard/pharmacist") && payload.role !== "pharmacist") {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    if (pathname.startsWith("/dashboard/delivery") && payload.role !== "delivery") {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    if (pathname.startsWith("/dashboard/customer") && payload.role !== "customer") {
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }

    return NextResponse.next()
  } catch (error) {
    return NextResponse.redirect(new URL("/auth/login", request.url))
  }
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
