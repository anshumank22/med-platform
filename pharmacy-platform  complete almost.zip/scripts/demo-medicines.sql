-- Demo medicines data for MediCare+ platform

-- Pain Relief & Fever
INSERT INTO medicines (id, name, generic_name, manufacturer, category, price, description, dosage_form, strength, requires_prescription) VALUES
(gen_random_uuid(), 'Paracetamol 500mg', 'Acetaminophen', 'Sun Pharma', 'Pain Relief', 25.00, 'Effective pain reliever and fever reducer for headaches, body aches, and fever', 'Tablet', '500mg', FALSE),
(gen_random_uuid(), 'Crocin Advance', 'Acetaminophen', 'GSK', 'Pain Relief', 35.00, 'Fast-acting pain relief with OptiZorb technology', 'Tablet', '650mg', FALSE),
(gen_random_uuid(), 'Ibuprofen', 'Ibuprofen', 'Cipla', 'Pain Relief', 45.00, 'Anti-inflammatory pain reliever for muscle pain and inflammation', 'Tablet', '400mg', FALSE),
(gen_random_uuid(), 'Aspirin', 'Acetylsalicylic Acid', 'Bayer', 'Pain Relief', 55.00, 'Pain reliever and blood thinner for heart health', 'Tablet', '75mg', FALSE),
(gen_random_uuid(), 'Diclofenac Gel', 'Diclofenac Sodium', 'Novartis', 'Pain Relief', 85.00, 'Topical anti-inflammatory gel for joint and muscle pain', 'Gel', '1%', FALSE),

-- Antibiotics (Prescription Required)
(gen_random_uuid(), 'Amoxicillin', 'Amoxicillin', 'Cipla', 'Antibiotics', 120.00, 'Broad-spectrum antibiotic for bacterial infections', 'Capsule', '500mg', TRUE),
(gen_random_uuid(), 'Azithromycin', 'Azithromycin', 'Pfizer', 'Antibiotics', 180.00, 'Macrolide antibiotic for respiratory tract infections', 'Tablet', '500mg', TRUE),
(gen_random_uuid(), 'Ciprofloxacin', 'Ciprofloxacin HCl', 'Ranbaxy', 'Antibiotics', 95.00, 'Fluoroquinolone antibiotic for urinary tract infections', 'Tablet', '500mg', TRUE),
(gen_random_uuid(), 'Doxycycline', 'Doxycycline Hyclate', 'Sun Pharma', 'Antibiotics', 110.00, 'Tetracycline antibiotic for various bacterial infections', 'Capsule', '100mg', TRUE),

-- Vitamins & Supplements
(gen_random_uuid(), 'Vitamin D3 60K', 'Cholecalciferol', 'Abbott', 'Vitamins', 180.00, 'High-strength Vitamin D supplement for bone health', 'Capsule', '60000 IU', FALSE),
(gen_random_uuid(), 'Vitamin B-Complex', 'B-Complex Vitamins', 'Himalaya', 'Vitamins', 125.00, 'Complete B-vitamin complex for energy and metabolism', 'Tablet', 'Multi', FALSE),
(gen_random_uuid(), 'Vitamin C 1000mg', 'Ascorbic Acid', 'Amway', 'Vitamins', 450.00, 'High-potency Vitamin C for immune support', 'Tablet', '1000mg', FALSE),
(gen_random_uuid(), 'Calcium + Magnesium', 'Calcium Carbonate', 'Shelcal', 'Vitamins', 165.00, 'Bone health supplement with Vitamin D3', 'Tablet', '500mg', FALSE),
(gen_random_uuid(), 'Iron Tablets', 'Ferrous Sulfate', 'Ranbaxy', 'Vitamins', 85.00, 'Iron supplement for anemia prevention', 'Tablet', '325mg', FALSE),
(gen_random_uuid(), 'Omega-3 Fish Oil', 'EPA/DHA', 'Seven Seas', 'Vitamins', 650.00, 'Heart and brain health supplement', 'Capsule', '1000mg', FALSE),

-- Diabetes Management (Prescription Required)
(gen_random_uuid(), 'Metformin', 'Metformin HCl', 'Sun Pharma', 'Diabetes', 95.00, 'First-line diabetes medication for blood sugar control', 'Tablet', '500mg', TRUE),
(gen_random_uuid(), 'Glimepiride', 'Glimepiride', 'Sanofi', 'Diabetes', 125.00, 'Sulfonylurea for Type 2 diabetes management', 'Tablet', '2mg', TRUE),
(gen_random_uuid(), 'Insulin Pen', 'Human Insulin', 'Novo Nordisk', 'Diabetes', 450.00, 'Fast-acting insulin for diabetes management', 'Injection', '100 IU/ml', TRUE),
(gen_random_uuid(), 'Glucometer Strips', 'Test Strips', 'Accu-Chek', 'Diabetes', 850.00, 'Blood glucose test strips (50 count)', 'Test Strip', '50 strips', FALSE),

-- Heart & Blood Pressure (Prescription Required)
(gen_random_uuid(), 'Amlodipine', 'Amlodipine Besylate', 'Pfizer', 'Heart Disease', 75.00, 'Calcium channel blocker for high blood pressure', 'Tablet', '5mg', TRUE),
(gen_random_uuid(), 'Atenolol', 'Atenolol', 'Cipla', 'Heart Disease', 65.00, 'Beta-blocker for hypertension and heart conditions', 'Tablet', '50mg', TRUE),
(gen_random_uuid(), 'Atorvastatin', 'Atorvastatin Calcium', 'Lipitor', 'Heart Disease', 185.00, 'Statin for cholesterol management', 'Tablet', '20mg', TRUE),
(gen_random_uuid(), 'Clopidogrel', 'Clopidogrel Bisulfate', 'Plavix', 'Heart Disease', 245.00, 'Antiplatelet medication for heart attack prevention', 'Tablet', '75mg', TRUE),

-- Digestive Health
(gen_random_uuid(), 'Omeprazole', 'Omeprazole', 'Dr. Reddy''s', 'Digestive Health', 85.00, 'Proton pump inhibitor for acid reflux and ulcers', 'Capsule', '20mg', TRUE),
(gen_random_uuid(), 'Pantoprazole', 'Pantoprazole Sodium', 'Sun Pharma', 'Digestive Health', 95.00, 'PPI for gastroesophageal reflux disease', 'Tablet', '40mg', TRUE),
(gen_random_uuid(), 'Ranitidine', 'Ranitidine HCl', 'GSK', 'Digestive Health', 45.00, 'H2 receptor blocker for heartburn relief', 'Tablet', '150mg', FALSE),
(gen_random_uuid(), 'Probiotics', 'Lactobacillus', 'Yakult', 'Digestive Health', 285.00, 'Probiotic supplement for digestive health', 'Capsule', '10 Billion CFU', FALSE),
(gen_random_uuid(), 'Antacid Syrup', 'Aluminum Hydroxide', 'ENO', 'Digestive Health', 65.00, 'Fast-acting antacid for acidity relief', 'Syrup', '200ml', FALSE),

-- Allergy & Respiratory
(gen_random_uuid(), 'Cetirizine', 'Cetirizine HCl', 'Cipla', 'Allergy', 45.00, 'Antihistamine for allergic reactions and hay fever', 'Tablet', '10mg', FALSE),
(gen_random_uuid(), 'Loratadine', 'Loratadine', 'Claritin', 'Allergy', 85.00, 'Non-drowsy antihistamine for seasonal allergies', 'Tablet', '10mg', FALSE),
(gen_random_uuid(), 'Salbutamol Inhaler', 'Salbutamol Sulfate', 'Ventolin', 'Respiratory', 185.00, 'Bronchodilator inhaler for asthma relief', 'Inhaler', '100mcg', TRUE),
(gen_random_uuid(), 'Cough Syrup', 'Dextromethorphan', 'Benadryl', 'Respiratory', 125.00, 'Cough suppressant for dry cough relief', 'Syrup', '100ml', FALSE),
(gen_random_uuid(), 'Throat Lozenges', 'Benzocaine', 'Strepsils', 'Respiratory', 35.00, 'Medicated lozenges for sore throat relief', 'Lozenge', '16 pieces', FALSE),

-- Skin Care
(gen_random_uuid(), 'Hydrocortisone Cream', 'Hydrocortisone', 'Johnson & Johnson', 'Skin Care', 95.00, 'Topical steroid for eczema and dermatitis', 'Cream', '1%', FALSE),
(gen_random_uuid(), 'Antifungal Cream', 'Clotrimazole', 'Candid', 'Skin Care', 75.00, 'Antifungal treatment for skin infections', 'Cream', '1%', FALSE),
(gen_random_uuid(), 'Sunscreen SPF 50', 'Zinc Oxide', 'Neutrogena', 'Skin Care', 450.00, 'Broad-spectrum sun protection', 'Lotion', '100ml', FALSE),
(gen_random_uuid(), 'Moisturizing Lotion', 'Ceramides', 'CeraVe', 'Skin Care', 650.00, 'Daily moisturizer for dry skin', 'Lotion', '355ml', FALSE),

-- Women's Health
(gen_random_uuid(), 'Folic Acid', 'Folic Acid', 'Abbott', 'Women''s Health', 45.00, 'Essential vitamin for pregnancy and women''s health', 'Tablet', '5mg', FALSE),
(gen_random_uuid(), 'Iron + Folic Acid', 'Ferrous Sulfate + Folic Acid', 'Himalaya', 'Women''s Health', 125.00, 'Combination supplement for anemia in women', 'Tablet', '100mg+1.5mg', FALSE),
(gen_random_uuid(), 'Calcium for Women', 'Calcium Citrate', 'Citracal', 'Women''s Health', 485.00, 'Calcium supplement specifically for women', 'Tablet', '630mg', FALSE),

-- Mental Health (Prescription Required)
(gen_random_uuid(), 'Sertraline', 'Sertraline HCl', 'Pfizer', 'Mental Health', 185.00, 'SSRI antidepressant for depression and anxiety', 'Tablet', '50mg', TRUE),
(gen_random_uuid(), 'Alprazolam', 'Alprazolam', 'Pfizer', 'Mental Health', 95.00, 'Benzodiazepine for anxiety disorders', 'Tablet', '0.5mg', TRUE),
(gen_random_uuid(), 'Melatonin', 'Melatonin', 'Nature Made', 'Mental Health', 285.00, 'Natural sleep aid supplement', 'Tablet', '3mg', FALSE),

-- First Aid & Emergency
(gen_random_uuid(), 'Antiseptic Solution', 'Povidone Iodine', 'Betadine', 'First Aid', 85.00, 'Antiseptic for wound cleaning and disinfection', 'Solution', '100ml', FALSE),
(gen_random_uuid(), 'Bandages', 'Adhesive Bandages', 'Band-Aid', 'First Aid', 125.00, 'Sterile adhesive bandages for wound care', 'Bandage', '50 pieces', FALSE),
(gen_random_uuid(), 'Thermometer', 'Digital Thermometer', 'Omron', 'First Aid', 350.00, 'Digital thermometer for accurate temperature reading', 'Device', 'Digital', FALSE),
(gen_random_uuid(), 'Hand Sanitizer', 'Ethyl Alcohol', 'Dettol', 'First Aid', 65.00, 'Alcohol-based hand sanitizer', 'Gel', '200ml', FALSE);

-- Update inventory for demo medicines
INSERT INTO inventory (id, pharmacist_id, medicine_id, stock_quantity, min_stock_level, expiry_date, batch_number, purchase_price, selling_price)
SELECT 
    gen_random_uuid(),
    (SELECT id FROM pharmacists LIMIT 1),
    m.id,
    FLOOR(RANDOM() * 100) + 20, -- Random stock between 20-120
    10,
    CURRENT_DATE + INTERVAL '2 years',
    'BATCH' || LPAD(FLOOR(RANDOM() * 10000)::text, 4, '0'),
    m.price * 0.7, -- Purchase price is 70% of selling price
    m.price
FROM medicines m
WHERE m.name IN (
    'Paracetamol 500mg', 'Crocin Advance', 'Ibuprofen', 'Aspirin', 'Diclofenac Gel',
    'Amoxicillin', 'Azithromycin', 'Vitamin D3 60K', 'Vitamin B-Complex', 'Vitamin C 1000mg',
    'Metformin', 'Insulin Pen', 'Amlodipine', 'Omeprazole', 'Cetirizine',
    'Hydrocortisone Cream', 'Folic Acid', 'Antiseptic Solution', 'Hand Sanitizer'
);
