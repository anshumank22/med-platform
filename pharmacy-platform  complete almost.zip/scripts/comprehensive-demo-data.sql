-- Comprehensive demo data for MediCare+ platform
-- This script adds extensive demo data for testing and development

-- Clear existing data (optional - uncomment if needed)
-- TRUNCATE TABLE order_items, orders, prescription_medicines, prescriptions, appointments, inventory, reviews, notifications CASCADE;
-- TRUNCATE TABLE customers, doctors, pharmacists, delivery_agents CASCADE;
-- TRUNCATE TABLE medicines CASCADE;
-- TRUNCATE TABLE users CASCADE;

-- Insert comprehensive user data
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
-- Admin users
('550e8400-e29b-41d4-a716-446655440000', 'admin@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'admin', 'System', 'Administrator', '+91 9999999999', '123 Admin Tower, Business District', 'Mumbai', 'Maharashtra', '400001', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440001', 'superadmin@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'admin', 'Super', 'Admin', '+91 9999999998', '124 Admin Tower, Business District', 'Mumbai', 'Maharashtra', '400001', TRUE, TRUE),

-- Doctors
('550e8400-e29b-41d4-a716-446655440010', 'dr.sarah@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Sarah', 'Johnson', '+91 9876543210', '456 Medical Plaza, Sector 1', 'Mumbai', 'Maharashtra', '400002', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440011', 'dr.michael@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Michael', 'Chen', '+91 9876543211', '789 Heart Center, Medical District', 'Delhi', 'Delhi', '110001', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440012', 'dr.priya@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Priya', 'Sharma', '+91 9876543212', '321 Skin Clinic, Beauty Street', 'Bangalore', 'Karnataka', '560001', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440013', 'dr.rajesh@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Rajesh', 'Kumar', '+91 9876543213', '654 Orthopedic Center', 'Chennai', 'Tamil Nadu', '600001', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440014', 'dr.anita@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Anita', 'Desai', '+91 9876543214', '987 Women''s Health Clinic', 'Pune', 'Maharashtra', '411001', TRUE, TRUE),

-- Pharmacists
('550e8400-e29b-41d4-a716-446655440020', 'pharmacy1@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'pharmacist', 'Amit', 'Patel', '+91 9876543220', '123 Pharmacy Street, Central Market', 'Mumbai', 'Maharashtra', '400003', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440021', 'pharmacy2@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'pharmacist', 'Sunita', 'Gupta', '+91 9876543221', '456 Medical Store, Health Plaza', 'Delhi', 'Delhi', '110002', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440022', 'pharmacy3@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'pharmacist', 'Ravi', 'Sharma', '+91 9876543222', '789 Care Pharmacy, Wellness Road', 'Bangalore', 'Karnataka', '560002', TRUE, TRUE),

-- Customers
('550e8400-e29b-41d4-a716-446655440030', 'customer1@gmail.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'John', 'Doe', '+91 9876543230', '123 Customer Lane, Residential Area', 'Mumbai', 'Maharashtra', '400004', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440031', 'customer2@gmail.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'Jane', 'Smith', '+91 9876543231', '456 Buyer Street, Family Colony', 'Delhi', 'Delhi', '110003', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440032', 'customer3@gmail.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'Rahul', 'Verma', '+91 9876543232', '789 Home Street, Green Park', 'Bangalore', 'Karnataka', '560003', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440033', 'customer4@gmail.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'Priya', 'Singh', '+91 9876543233', '321 Family Avenue, Happy Homes', 'Chennai', 'Tamil Nadu', '600002', TRUE, TRUE),

-- Delivery agents
('550e8400-e29b-41d4-a716-446655440040', 'delivery1@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'delivery', 'Ravi', 'Singh', '+91 9876543240', '654 Delivery Hub, Logistics Park', 'Mumbai', 'Maharashtra', '400005', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440041', 'delivery2@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'delivery', 'Suresh', 'Yadav', '+91 9876543241', '987 Logistics Center, Transport Nagar', 'Delhi', 'Delhi', '110004', TRUE, TRUE),
('550e8400-e29b-41d4-a716-446655440042', 'delivery3@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'delivery', 'Vikram', 'Patel', '+91 9876543242', '123 Speed Delivery, Fast Lane', 'Bangalore', 'Karnataka', '560004', TRUE, TRUE)
ON CONFLICT (email) DO NOTHING;

-- Insert doctors data
INSERT INTO doctors (id, user_id, license_number, specialization, experience_years, consultation_fee, rating, total_consultations, availability_status, bio, education) VALUES
('650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440010', 'MED001', 'Cardiologist', 12, 800.00, 4.8, 1250, 'available', 'Experienced cardiologist specializing in heart disease prevention and treatment', 'MBBS, MD Cardiology - AIIMS Delhi'),
('650e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440011', 'MED002', 'Neurologist', 15, 900.00, 4.9, 980, 'available', 'Leading neurologist with expertise in brain and nervous system disorders', 'MBBS, DM Neurology - PGIMER Chandigarh'),
('650e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440012', 'MED003', 'Dermatologist', 8, 600.00, 4.7, 890, 'available', 'Skin specialist with expertise in cosmetic and medical dermatology', 'MBBS, MD Dermatology - KEM Hospital Mumbai'),
('650e8400-e29b-41d4-a716-446655440013', '550e8400-e29b-41d4-a716-446655440013', 'MED004', 'Orthopedist', 10, 750.00, 4.6, 1100, 'busy', 'Orthopedic surgeon specializing in joint replacement and sports injuries', 'MBBS, MS Orthopedics - CMC Vellore'),
('650e8400-e29b-41d4-a716-446655440014', '550e8400-e29b-41d4-a716-446655440014', 'MED005', 'Gynecologist', 12, 700.00, 4.9, 1350, 'available', 'Women''s health specialist with focus on reproductive health and pregnancy care', 'MBBS, MS Gynecology - Grant Medical College Mumbai')
ON CONFLICT (license_number) DO NOTHING;

-- Insert pharmacists data
INSERT INTO pharmacists (id, user_id, pharmacy_name, pharmacy_license, pharmacy_address, operating_hours, delivery_radius) VALUES
('750e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440020', 'HealthPlus Pharmacy', 'PHARM001', '123 Pharmacy Street, Central Market, Mumbai', '8:00 AM - 10:00 PM', 15),
('750e8400-e29b-41d4-a716-446655440021', '550e8400-e29b-41d4-a716-446655440021', 'MediCare Pharmacy', 'PHARM002', '456 Medical Store, Health Plaza, Delhi', '24 Hours', 20),
('750e8400-e29b-41d4-a716-446655440022', '550e8400-e29b-41d4-a716-446655440022', 'WellCare Pharmacy', 'PHARM003', '789 Care Pharmacy, Wellness Road, Bangalore', '7:00 AM - 11:00 PM', 18)
ON CONFLICT (pharmacy_license) DO NOTHING;

-- Insert customers data
INSERT INTO customers (id, user_id, date_of_birth, gender, blood_type, emergency_contact_name, emergency_contact_phone) VALUES
('850e8400-e29b-41d4-a716-446655440030', '550e8400-e29b-41d4-a716-446655440030', '1990-05-15', 'male', 'O+', 'Mary Doe', '+91 9876543250'),
('850e8400-e29b-41d4-a716-446655440031', '550e8400-e29b-41d4-a716-446655440031', '1985-08-22', 'female', 'A+', 'Robert Smith', '+91 9876543251'),
('850e8400-e29b-41d4-a716-446655440032', '550e8400-e29b-41d4-a716-446655440032', '1992-12-10', 'male', 'B+', 'Sunita Verma', '+91 9876543252'),
('850e8400-e29b-41d4-a716-446655440033', '550e8400-e29b-41d4-a716-446655440033', '1988-03-18', 'female', 'AB+', 'Raj Singh', '+91 9876543253')
ON CONFLICT (id) DO NOTHING;

-- Insert delivery agents data
INSERT INTO delivery_agents (id, user_id, vehicle_number, driving_license, availability_status, rating, total_deliveries) VALUES
('950e8400-e29b-41d4-a716-446655440040', '550e8400-e29b-41d4-a716-446655440040', 'MH01AB1234', 'DL001', 'available', 4.6, 450),
('950e8400-e29b-41d4-a716-446655440041', '550e8400-e29b-41d4-a716-446655440041', 'DL02CD5678', 'DL002', 'available', 4.8, 380),
('950e8400-e29b-41d4-a716-446655440042', '550e8400-e29b-41d4-a716-446655440042', 'KA03EF9012', 'DL003', 'busy', 4.7, 290)
ON CONFLICT (id) DO NOTHING;

-- Insert comprehensive medicines data (100+ medicines across all categories)
INSERT INTO medicines (id, name, generic_name, manufacturer, category, price, description, dosage_form, strength, requires_prescription) VALUES
-- Pain Relief & Fever (10 medicines)
('a50e8400-e29b-41d4-a716-446655440001', 'Paracetamol 500mg', 'Acetaminophen', 'Sun Pharma', 'Pain Relief', 25.00, 'Effective pain reliever and fever reducer', 'Tablet', '500mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440002', 'Crocin Advance', 'Acetaminophen', 'GSK', 'Pain Relief', 35.00, 'Fast-acting pain relief with OptiZorb technology', 'Tablet', '650mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440003', 'Ibuprofen 400mg', 'Ibuprofen', 'Cipla', 'Pain Relief', 45.00, 'Anti-inflammatory pain reliever', 'Tablet', '400mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440004', 'Aspirin 75mg', 'Acetylsalicylic Acid', 'Bayer', 'Pain Relief', 55.00, 'Pain reliever and blood thinner', 'Tablet', '75mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440005', 'Diclofenac Gel', 'Diclofenac Sodium', 'Novartis', 'Pain Relief', 85.00, 'Topical anti-inflammatory gel', 'Gel', '1%', FALSE),
('a50e8400-e29b-41d4-a716-446655440006', 'Nimesulide 100mg', 'Nimesulide', 'Lupin', 'Pain Relief', 65.00, 'Anti-inflammatory and analgesic', 'Tablet', '100mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440007', 'Tramadol 50mg', 'Tramadol HCl', 'Cadila', 'Pain Relief', 120.00, 'Moderate to severe pain relief', 'Tablet', '50mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440008', 'Mefenamic Acid', 'Mefenamic Acid', 'Blue Cross', 'Pain Relief', 75.00, 'Pain and inflammation relief', 'Tablet', '250mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440009', 'Ketorolac 10mg', 'Ketorolac', 'Dr. Reddy''s', 'Pain Relief', 95.00, 'Short-term pain management', 'Tablet', '10mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440010', 'Aceclofenac 100mg', 'Aceclofenac', 'Ipca', 'Pain Relief', 85.00, 'Anti-inflammatory for joint pain', 'Tablet', '100mg', FALSE),

-- Antibiotics (15 medicines)
('a50e8400-e29b-41d4-a716-446655440011', 'Amoxicillin 500mg', 'Amoxicillin', 'Cipla', 'Antibiotics', 120.00, 'Broad-spectrum antibiotic', 'Capsule', '500mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440012', 'Azithromycin 500mg', 'Azithromycin', 'Pfizer', 'Antibiotics', 180.00, 'Macrolide antibiotic', 'Tablet', '500mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440013', 'Ciprofloxacin 500mg', 'Ciprofloxacin HCl', 'Ranbaxy', 'Antibiotics', 95.00, 'Fluoroquinolone antibiotic', 'Tablet', '500mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440014', 'Cephalexin 250mg', 'Cephalexin', 'Lupin', 'Antibiotics', 140.00, 'First-generation cephalosporin', 'Capsule', '250mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440015', 'Doxycycline 100mg', 'Doxycycline', 'Sun Pharma', 'Antibiotics', 165.00, 'Tetracycline antibiotic', 'Capsule', '100mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440016', 'Clindamycin 150mg', 'Clindamycin', 'Pfizer', 'Antibiotics', 185.00, 'Lincosamide antibiotic', 'Capsule', '150mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440017', 'Erythromycin 250mg', 'Erythromycin', 'Abbott', 'Antibiotics', 125.00, 'Macrolide antibiotic', 'Tablet', '250mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440018', 'Levofloxacin 500mg', 'Levofloxacin', 'Dr. Reddy''s', 'Antibiotics', 220.00, 'Fluoroquinolone antibiotic', 'Tablet', '500mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440019', 'Metronidazole 400mg', 'Metronidazole', 'Cipla', 'Antibiotics', 85.00, 'Antiprotozoal and antibacterial', 'Tablet', '400mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440020', 'Trimethoprim-Sulfamethoxazole', 'Co-trimoxazole', 'GSK', 'Antibiotics', 95.00, 'Combination antibiotic', 'Tablet', '160mg+800mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440021', 'Cefixime 200mg', 'Cefixime', 'Lupin', 'Antibiotics', 195.00, 'Third-generation cephalosporin', 'Tablet', '200mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440022', 'Clarithromycin 500mg', 'Clarithromycin', 'Abbott', 'Antibiotics', 285.00, 'Macrolide antibiotic', 'Tablet', '500mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440023', 'Ofloxacin 200mg', 'Ofloxacin', 'Cipla', 'Antibiotics', 125.00, 'Fluoroquinolone antibiotic', 'Tablet', '200mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440024', 'Ampicillin 250mg', 'Ampicillin', 'Ranbaxy', 'Antibiotics', 95.00, 'Penicillin antibiotic', 'Capsule', '250mg', TRUE),
('a50e8400-e29b-41d4-a716-446655440025', 'Norfloxacin 400mg', 'Norfloxacin', 'Sun Pharma', 'Antibiotics', 115.00, 'Fluoroquinolone antibiotic', 'Tablet', '400mg', TRUE)
ON CONFLICT (id) DO NOTHING;

-- Continue with more medicine categories...
-- (Due to length constraints, I'll add key medicines from other categories)

-- Vitamins & Supplements (10 medicines)
INSERT INTO medicines (id, name, generic_name, manufacturer, category, price, description, dosage_form, strength, requires_prescription) VALUES
('a50e8400-e29b-41d4-a716-446655440026', 'Vitamin D3 60K', 'Cholecalciferol', 'Abbott', 'Vitamins', 180.00, 'High-strength Vitamin D supplement', 'Capsule', '60000 IU', FALSE),
('a50e8400-e29b-41d4-a716-446655440027', 'Vitamin B-Complex', 'B-Complex Vitamins', 'Himalaya', 'Vitamins', 125.00, 'Complete B-vitamin complex', 'Tablet', 'Multi', FALSE),
('a50e8400-e29b-41d4-a716-446655440028', 'Vitamin C 1000mg', 'Ascorbic Acid', 'Amway', 'Vitamins', 450.00, 'High-potency Vitamin C', 'Tablet', '1000mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440029', 'Calcium + Magnesium', 'Calcium Carbonate', 'Shelcal', 'Vitamins', 165.00, 'Bone health supplement', 'Tablet', '500mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440030', 'Iron + Folic Acid', 'Ferrous Sulfate', 'Ranbaxy', 'Vitamins', 95.00, 'Iron deficiency supplement', 'Tablet', '100mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440031', 'Omega-3 Fish Oil', 'EPA/DHA', 'Nature Made', 'Vitamins', 650.00, 'Heart and brain health supplement', 'Capsule', '1000mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440032', 'Multivitamin', 'Multivitamin', 'Centrum', 'Vitamins', 385.00, 'Complete daily nutrition', 'Tablet', 'Multi', FALSE),
('a50e8400-e29b-41d4-a716-446655440033', 'Zinc 50mg', 'Zinc Sulfate', 'NOW Foods', 'Vitamins', 285.00, 'Immune system support', 'Tablet', '50mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440034', 'Magnesium 400mg', 'Magnesium Oxide', 'Nature''s Bounty', 'Vitamins', 325.00, 'Muscle and nerve function', 'Tablet', '400mg', FALSE),
('a50e8400-e29b-41d4-a716-446655440035', 'Vitamin E 400 IU', 'Tocopherol', 'Solgar', 'Vitamins', 485.00, 'Antioxidant vitamin', 'Capsule', '400 IU', FALSE)
ON CONFLICT (id) DO NOTHING;

-- Add inventory for the medicines
INSERT INTO inventory (pharmacist_id, medicine_id, stock_quantity, min_stock_level, expiry_date, batch_number, purchase_price, selling_price) 
SELECT 
    p.id as pharmacist_id,
    m.id as medicine_id,
    FLOOR(RANDOM() * 100 + 50) as stock_quantity,
    10 as min_stock_level,
    CURRENT_DATE + INTERVAL '2 years' as expiry_date,
    'BATCH' || LPAD((ROW_NUMBER() OVER())::text, 6, '0') as batch_number,
    m.price * 0.7 as purchase_price,
    m.price as selling_price
FROM pharmacists p
CROSS JOIN medicines m
ON CONFLICT (pharmacist_id, medicine_id, batch_number) DO NOTHING;

-- Add some sample appointments
INSERT INTO appointments (customer_id, doctor_id, appointment_date, appointment_time, type, status, reason, consultation_fee) VALUES
('550e8400-e29b-41d4-a716-446655440030', '650e8400-e29b-41d4-a716-446655440010', CURRENT_DATE + 1, '10:00:00', 'video', 'scheduled', 'Chest pain and shortness of breath', 800.00),
('550e8400-e29b-41d4-a716-446655440031', '650e8400-e29b-41d4-a716-446655440012', CURRENT_DATE + 2, '14:30:00', 'in_person', 'scheduled', 'Skin rash and itching', 600.00),
('550e8400-e29b-41d4-a716-446655440032', '650e8400-e29b-41d4-a716-446655440014', CURRENT_DATE + 3, '11:15:00', 'video', 'scheduled', 'Pregnancy consultation', 700.00);

-- Add some sample orders
INSERT INTO orders (customer_id, pharmacist_id, total_amount, delivery_fee, status, delivery_address, payment_status, payment_method) VALUES
('550e8400-e29b-41d4-a716-446655440030', '750e8400-e29b-41d4-a716-446655440020', 285.00, 50.00, 'delivered', '123 Customer Lane, Residential Area, Mumbai', 'paid', 'card'),
('550e8400-e29b-41d4-a716-446655440031', '750e8400-e29b-41d4-a716-446655440021', 450.00, 50.00, 'out_for_delivery', '456 Buyer Street, Family Colony, Delhi', 'paid', 'upi'),
('550e8400-e29b-41d4-a716-446655440032', '750e8400-e29b-41d4-a716-446655440022', 195.00, 50.00, 'preparing', '789 Home Street, Green Park, Bangalore', 'paid', 'card');

-- Add order items for the orders
INSERT INTO order_items (order_id, medicine_id, quantity, unit_price, total_price)
SELECT 
    o.id,
    m.id,
    FLOOR(RANDOM() * 3 + 1) as quantity,
    m.price,
    m.price * FLOOR(RANDOM() * 3 + 1)
FROM orders o
CROSS JOIN medicines m
WHERE RANDOM() < 0.3  -- Only add some medicines to each order
LIMIT 20;

-- Add some reviews
INSERT INTO reviews (customer_id, doctor_id, rating, comment) VALUES
('550e8400-e29b-41d4-a716-446655440030', '650e8400-e29b-41d4-a716-446655440010', 5, 'Excellent doctor, very thorough examination and clear explanation'),
('550e8400-e29b-41d4-a716-446655440031', '650e8400-e29b-41d4-a716-446655440012', 4, 'Good consultation, helpful advice for skin care'),
('550e8400-e29b-41d4-a716-446655440032', '650e8400-e29b-41d4-a716-446655440014', 5, 'Very caring and professional, highly recommended');

-- Add notifications
INSERT INTO notifications (user_id, title, message, type) VALUES
('550e8400-e29b-41d4-a716-446655440030', 'Order Delivered', 'Your order #ORD001 has been delivered successfully', 'order'),
('550e8400-e29b-41d4-a716-446655440031', 'Appointment Reminder', 'You have an appointment tomorrow at 2:30 PM with Dr. Priya Sharma', 'appointment'),
('550e8400-e29b-41d4-a716-446655440032', 'Order Confirmed', 'Your order has been confirmed and is being prepared', 'order');
