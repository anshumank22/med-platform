-- Fixed seed data script with proper password hashes and consistent UUIDs

-- Insert demo users with proper password hashes (password: password123)
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
-- Admin user
('550e8400-e29b-41d4-a716-446655440000', 'admin@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'admin', 'Admin', 'User', '+91-9876543210', '123 Admin Street', 'Mumbai', 'Maharashtra', '400001', true, true),

-- Doctors
('550e8400-e29b-41d4-a716-446655440010', 'dr.sarah@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Sarah', 'Johnson', '+91-9876543211', '456 Medical Plaza', 'Delhi', 'Delhi', '110001', true, true),
('550e8400-e29b-41d4-a716-446655440011', 'dr.michael@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Dr. Michael', 'Chen', '+91-9876543212', '789 Heart Center', 'Bangalore', 'Karnataka', '560001', true, true),

-- Pharmacists
('550e8400-e29b-41d4-a716-446655440020', 'pharmacy1@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'pharmacist', 'Amit', 'Patel', '+91-9876543215', '123 Pharmacy Street', 'Mumbai', 'Maharashtra', '400002', true, true),

-- Customers
('550e8400-e29b-41d4-a716-446655440030', 'customer1@gmail.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'John', 'Doe', '+91-9876543217', '789 Customer Lane', 'Mumbai', 'Maharashtra', '400003', true, true),

-- Delivery agents
('550e8400-e29b-41d4-a716-446655440040', 'delivery1@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'delivery', 'Ravi', 'Singh', '+91-9876543219', '654 Delivery Hub', 'Mumbai', 'Maharashtra', '400004', true, true)
ON CONFLICT (email) DO NOTHING;

-- Insert doctors data
INSERT INTO doctors (id, user_id, license_number, specialization, experience_years, consultation_fee, rating, total_consultations, availability_status, bio, education) VALUES
('650e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440010', 'MED001', 'Cardiologist', 12, 800.00, 4.8, 1250, 'available', 'Experienced cardiologist specializing in heart disease prevention and treatment', 'MBBS, MD Cardiology - AIIMS Delhi'),
('650e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440011', 'MED002', 'Neurologist', 15, 900.00, 4.9, 980, 'available', 'Leading neurologist with expertise in brain and nervous system disorders', 'MBBS, DM Neurology - PGIMER Chandigarh')
ON CONFLICT (license_number) DO NOTHING;

-- Insert pharmacists data
INSERT INTO pharmacists (id, user_id, pharmacy_name, pharmacy_license, pharmacy_address, operating_hours, delivery_radius) VALUES
('750e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440020', 'HealthPlus Pharmacy', 'PHARM001', '123 Pharmacy Street, Central Market, Mumbai', '8:00 AM - 10:00 PM', 15)
ON CONFLICT (pharmacy_license) DO NOTHING;

-- Insert customers data
INSERT INTO customers (id, user_id, date_of_birth, gender, blood_type, emergency_contact_name, emergency_contact_phone) VALUES
('850e8400-e29b-41d4-a716-446655440030', '550e8400-e29b-41d4-a716-446655440030', '1990-05-15', 'male', 'O+', 'Mary Doe', '+91 9876543250')
ON CONFLICT (id) DO NOTHING;

-- Insert delivery agents data
INSERT INTO delivery_agents (id, user_id, vehicle_number, driving_license, availability_status, rating, total_deliveries) VALUES
('950e8400-e29b-41d4-a716-446655440040', '550e8400-e29b-41d4-a716-446655440040', 'MH01AB1234', 'DL001', 'available', 4.6, 450)
ON CONFLICT (id) DO NOTHING;

-- Insert basic medicines data (5 essential medicines)
INSERT INTO medicines (id, name, generic_name, manufacturer, category, price, description, dosage_form, strength, requires_prescription, image_url) VALUES
-- Pain Relief & Fever
('a50e8400-e29b-41d4-a716-446655440001', 'Paracetamol 500mg', 'Acetaminophen', 'Sun Pharma', 'Pain Relief', 25.00, 'Effective pain reliever and fever reducer', 'Tablet', '500mg', false, '/placeholder.svg?height=200&width=200'),
-- Antibiotics
('a50e8400-e29b-41d4-a716-446655440011', 'Amoxicillin 500mg', 'Amoxicillin', 'Cipla', 'Antibiotics', 120.00, 'Broad-spectrum antibiotic', 'Capsule', '500mg', true, '/placeholder.svg?height=200&width=200'),
-- Vitamins
('a50e8400-e29b-41d4-a716-446655440026', 'Vitamin D3 60K', 'Cholecalciferol', 'Abbott', 'Vitamins', 180.00, 'High-strength Vitamin D supplement', 'Capsule', '60000 IU', false, '/placeholder.svg?height=200&width=200'),
-- Allergy
('a50e8400-e29b-41d4-a716-446655440029', 'Cetirizine 10mg', 'Cetirizine HCl', 'Cipla', 'Allergy', 45.00, 'Antihistamine for allergies', 'Tablet', '10mg', false, '/placeholder.svg?height=200&width=200'),
-- Diabetes
('a50e8400-e29b-41d4-a716-446655440016', 'Metformin 500mg', 'Metformin HCl', 'Sun Pharma', 'Diabetes', 95.00, 'First-line diabetes medication', 'Tablet', '500mg', true, '/placeholder.svg?height=200&width=200')
ON CONFLICT (id) DO NOTHING;

-- Add inventory for the medicines
INSERT INTO inventory (pharmacist_id, medicine_id, stock_quantity, min_stock_level, expiry_date, batch_number, purchase_price, selling_price) VALUES
('750e8400-e29b-41d4-a716-446655440020', 'a50e8400-e29b-41d4-a716-446655440001', 100, 10, CURRENT_DATE + INTERVAL '2 years', 'BATCH000001', 17.50, 25.00),
('750e8400-e29b-41d4-a716-446655440020', 'a50e8400-e29b-41d4-a716-446655440011', 50, 10, CURRENT_DATE + INTERVAL '2 years', 'BATCH000002', 84.00, 120.00),
('750e8400-e29b-41d4-a716-446655440020', 'a50e8400-e29b-41d4-a716-446655440026', 75, 10, CURRENT_DATE + INTERVAL '2 years', 'BATCH000003', 126.00, 180.00),
('750e8400-e29b-41d4-a716-446655440020', 'a50e8400-e29b-41d4-a716-446655440029', 120, 10, CURRENT_DATE + INTERVAL '2 years', 'BATCH000004', 31.50, 45.00),
('750e8400-e29b-41d4-a716-446655440020', 'a50e8400-e29b-41d4-a716-446655440016', 80, 10, CURRENT_DATE + INTERVAL '2 years', 'BATCH000005', 66.50, 95.00)
ON CONFLICT (pharmacist_id, medicine_id, batch_number) DO NOTHING;
