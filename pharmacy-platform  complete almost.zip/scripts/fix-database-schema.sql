-- Fix database schema issues and ensure all tables have proper constraints

-- Check if uuid-ossp extension exists and create if not
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Fix inventory table if pharmacist_id column is missing
DO $$
BEGIN
  -- Check if pharmacist_id column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'inventory' 
    AND column_name = 'pharmacist_id'
  ) THEN
    -- Add the pharmacist_id column if it doesn't exist
    ALTER TABLE inventory ADD COLUMN pharmacist_id UUID;
    
    -- Add foreign key constraint
    ALTER TABLE inventory 
    ADD CONSTRAINT inventory_pharmacist_id_fkey 
    FOREIGN KEY (pharmacist_id) 
    REFERENCES pharmacists(id) ON DELETE CASCADE;
    
    -- Create index for better performance
    CREATE INDEX IF NOT EXISTS idx_inventory_pharmacist ON inventory(pharmacist_id);
  END IF;
END
$$;

-- Fix appointments table if missing prescription_id column
DO $$
BEGIN
  -- Check if prescription_id column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'appointments' 
    AND column_name = 'prescription_id'
  ) THEN
    -- Add the prescription_id column if it doesn't exist
    ALTER TABLE appointments ADD COLUMN prescription_id UUID;
    
    -- Add foreign key constraint with deferred check (to avoid circular reference)
    ALTER TABLE appointments 
    ADD CONSTRAINT appointments_prescription_id_fkey 
    FOREIGN KEY (prescription_id) 
    REFERENCES prescriptions(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;
  END IF;
END
$$;

-- Fix prescriptions table if missing appointment_id column
DO $$
BEGIN
  -- Check if appointment_id column exists in prescriptions
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'prescriptions' 
    AND column_name = 'appointment_id'
  ) THEN
    -- Add the appointment_id column if it doesn't exist
    ALTER TABLE prescriptions ADD COLUMN appointment_id UUID;
    
    -- Add foreign key constraint with deferred check (to avoid circular reference)
    ALTER TABLE prescriptions 
    ADD CONSTRAINT prescriptions_appointment_id_fkey 
    FOREIGN KEY (appointment_id) 
    REFERENCES appointments(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;
  END IF;
END
$$;

-- Fix orders table if missing prescription_id column
DO $$
BEGIN
  -- Check if prescription_id column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'orders' 
    AND column_name = 'prescription_id'
  ) THEN
    -- Add the prescription_id column if it doesn't exist
    ALTER TABLE orders ADD COLUMN prescription_id UUID;
    
    -- Add foreign key constraint
    ALTER TABLE orders 
    ADD CONSTRAINT orders_prescription_id_fkey 
    FOREIGN KEY (prescription_id) 
    REFERENCES prescriptions(id) ON DELETE SET NULL;
  END IF;
END
$$;

-- Create missing indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_appointments_customer ON appointments(customer_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_pharmacist ON orders(pharmacist_id);
CREATE INDEX IF NOT EXISTS idx_inventory_medicine ON inventory(medicine_id);
CREATE INDEX IF NOT EXISTS idx_medicines_category ON medicines(category);
CREATE INDEX IF NOT EXISTS idx_medicines_name ON medicines(name);

-- Fix any missing updated_at triggers
DO $$
BEGIN
  -- Create the function if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
    CREATE FUNCTION update_updated_at_column()
    RETURNS TRIGGER AS $$
    BEGIN
      NEW.updated_at = CURRENT_TIMESTAMP;
      RETURN NEW;
    END;
    $$ language 'plpgsql';
  END IF;
  
  -- Create triggers for tables with updated_at columns
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at'
  ) THEN
    CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_medicines_updated_at'
  ) THEN
    CREATE TRIGGER update_medicines_updated_at BEFORE UPDATE ON medicines
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
END
$$;

-- Ensure all tables have proper primary keys
DO $$
DECLARE
  tables RECORD;
BEGIN
  FOR tables IN 
    SELECT table_name 
    FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_type = 'BASE TABLE'
  LOOP
    -- Check if table has a primary key
    IF NOT EXISTS (
      SELECT 1 
      FROM information_schema.table_constraints 
      WHERE constraint_type = 'PRIMARY KEY' 
      AND table_name = tables.table_name
    ) THEN
      RAISE NOTICE 'Table % is missing a primary key', tables.table_name;
    END IF;
  END LOOP;
END
$$;

-- Output success message
DO $$
BEGIN
  RAISE NOTICE 'Database schema fixes applied successfully';
END
$$;
