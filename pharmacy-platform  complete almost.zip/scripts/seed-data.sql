-- Seed data for MediCare+ platform

-- Insert sample medicines
INSERT INTO medicines (id, name, generic_name, manufacturer, category, price, description, dosage_form, strength, requires_prescription) VALUES
(gen_random_uuid(), 'Paracetamol', 'Acetaminophen', 'Sun Pharma', 'Pain Relief', 25.00, 'Pain reliever and fever reducer', 'Tablet', '500mg', FALSE),
(gen_random_uuid(), 'Crocin', 'Acetaminophen', 'GSK', 'Pain Relief', 35.00, 'Pain reliever and fever reducer', 'Tablet', '650mg', FALSE),
(gen_random_uuid(), 'Vitamin D3', 'Cholecalciferol', 'Abbott', 'Vitamins', 180.00, 'Vitamin D supplement', 'Capsule', '60000 IU', FALSE),
(gen_random_uuid(), 'Insulin Pen', 'Human Insulin', 'Novo Nordisk', 'Diabetes', 450.00, 'Insulin for diabetes management', 'Injection', '100 IU/ml', TRUE),
(gen_random_uuid(), 'Amoxicillin', 'Amoxicillin', 'Cipla', 'Antibiotics', 120.00, 'Antibiotic for bacterial infections', 'Capsule', '500mg', TRUE),
(gen_random_uuid(), 'Omeprazole', 'Omeprazole', 'Dr. Reddy''s', 'Gastro', 85.00, 'Proton pump inhibitor for acid reflux', 'Capsule', '20mg', TRUE),
(gen_random_uuid(), 'Cetirizine', 'Cetirizine HCl', 'Cipla', 'Allergy', 45.00, 'Antihistamine for allergies', 'Tablet', '10mg', FALSE),
(gen_random_uuid(), 'Metformin', 'Metformin HCl', 'Sun Pharma', 'Diabetes', 95.00, 'Diabetes medication', 'Tablet', '500mg', TRUE);

-- Insert admin user
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, is_verified, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'admin@medicareplus.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'admin', 'System', 'Administrator', '+91 9999999999', TRUE, TRUE);

-- Insert sample customer
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'customer@test.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'customer', 'John', 'Doe', '+91 9876543210', '123 Main Street', 'Mumbai', 'Maharashtra', '400001', TRUE, TRUE);

INSERT INTO customers (id, user_id, date_of_birth, gender, blood_type) VALUES
(gen_random_uuid(), '550e8400-e29b-41d4-a716-446655440001', '1985-06-15', 'male', 'O+');

-- Insert sample doctor
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440002', 'doctor@test.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'doctor', 'Priya', 'Sharma', '+91 9876543211', '456 Medical Street', 'Mumbai', 'Maharashtra', '400002', TRUE, TRUE);

INSERT INTO doctors (id, user_id, license_number, specialization, experience_years, consultation_fee, rating, total_consultations, availability_status, bio) VALUES
(gen_random_uuid(), '550e8400-e29b-41d4-a716-446655440002', 'MH123456789', 'Cardiologist', 15, 500.00, 4.9, 1247, 'available', 'Experienced cardiologist with expertise in heart disease prevention and treatment.');

-- Insert sample pharmacist
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440003', 'pharmacist@test.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'pharmacist', 'Raj', 'Pharmacy', '+91 9876543212', '789 Pharmacy Road', 'Mumbai', 'Maharashtra', '400003', TRUE, TRUE);

INSERT INTO pharmacists (id, user_id, pharmacy_name, pharmacy_license, pharmacy_address, operating_hours, delivery_radius) VALUES
(gen_random_uuid(), '550e8400-e29b-41d4-a716-446655440003', 'Apollo Pharmacy', 'PH987654321', '789 Pharmacy Road, Mumbai', '9:00 AM - 10:00 PM', 25);

-- Insert sample delivery agent
INSERT INTO users (id, email, password_hash, role, first_name, last_name, phone, address, city, state, pincode, is_verified, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440004', 'delivery@test.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/8VfuFvO', 'delivery', 'Delivery', 'Agent', '+91 9876543213', '321 Delivery Lane', 'Mumbai', 'Maharashtra', '400004', TRUE, TRUE);

INSERT INTO delivery_agents (id, user_id, vehicle_number, driving_license, availability_status, rating, total_deliveries) VALUES
(gen_random_uuid(), '550e8400-e29b-41d4-a716-446655440004', 'MH01AB1234', 'DL123456789', 'available', 4.8, 234);
