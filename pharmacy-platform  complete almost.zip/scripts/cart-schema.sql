-- Cart schema for MediCare+ platform

-- Create cart table if it doesn't exist
CREATE TABLE IF NOT EXISTS carts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create cart items table if it doesn't exist
CREATE TABLE IF NOT EXISTS cart_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cart_id UUID NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
    medicine_id UUID NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(cart_id, medicine_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_carts_customer ON carts(customer_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_cart ON cart_items(cart_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_medicine ON cart_items(medicine_id);

-- Create triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_cart_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_carts_updated_at BEFORE UPDATE ON carts
    FOR EACH ROW EXECUTE FUNCTION update_cart_updated_at_column();

CREATE TRIGGER update_cart_items_updated_at BEFORE UPDATE ON cart_items
    FOR EACH ROW EXECUTE FUNCTION update_cart_updated_at_column();

-- Create function to get cart total
CREATE OR REPLACE FUNCTION get_cart_total(p_cart_id UUID)
RETURNS DECIMAL(10,2) AS $$
DECLARE
    total DECIMAL(10,2);
BEGIN
    SELECT COALESCE(SUM(ci.quantity * m.price), 0)
    INTO total
    FROM cart_items ci
    JOIN medicines m ON ci.medicine_id = m.id
    WHERE ci.cart_id = p_cart_id;
    
    RETURN total;
END;
$$ LANGUAGE plpgsql;

-- Create function to get or create cart
CREATE OR REPLACE FUNCTION get_or_create_cart(p_customer_id UUID)
RETURNS UUID AS $$
DECLARE
    v_cart_id UUID;
BEGIN
    -- Check if cart exists
    SELECT id INTO v_cart_id
    FROM carts
    WHERE customer_id = p_customer_id;
    
    -- If not, create one
    IF v_cart_id IS NULL THEN
        INSERT INTO carts (customer_id)
        VALUES (p_customer_id)
        RETURNING id INTO v_cart_id;
    END IF;
    
    RETURN v_cart_id;
END;
$$ LANGUAGE plpgsql;
