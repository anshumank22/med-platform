"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface ResponsiveCardProps {
  title: string
  description?: string
  children: React.ReactNode
  className?: string
  fullWidth?: boolean
}

export function ResponsiveCard({ title, description, children, className, fullWidth = false }: ResponsiveCardProps) {
  return (
    <Card
      className={cn(
        "w-full",
        fullWidth ? "max-w-none" : "max-w-md md:max-w-lg lg:max-w-xl",
        "mx-auto md:mx-0",
        className,
      )}
    >
      <CardHeader className="space-y-1">
        <CardTitle className="text-lg md:text-xl lg:text-2xl">{title}</CardTitle>
        {description && <CardDescription className="text-sm md:text-base">{description}</CardDescription>}
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  )
}
