"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Database, Terminal, Settings, CheckCircle } from "lucide-react"

export function DatabaseSetupGuide() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center">
        <Database className="h-16 w-16 mx-auto mb-4 text-blue-600" />
        <h1 className="text-3xl font-bold mb-2">PostgreSQL Database Setup</h1>
        <p className="text-gray-600">Complete guide to set up your database connection</p>
      </div>

      {/* Step 1: Install PostgreSQL */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            Step 1: Install PostgreSQL
          </CardTitle>
          <CardDescription>Install PostgreSQL and pgAdmin4 on your system</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Badge variant="outline">Ubuntu/Debian</Badge>
              <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">
                {`sudo apt update
sudo apt install postgresql postgresql-contrib
sudo apt install pgadmin4`}
              </pre>
            </div>
            <div className="space-y-2">
              <Badge variant="outline">macOS</Badge>
              <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">
                {`brew install postgresql
brew install --cask pgadmin4
brew services start postgresql`}
              </pre>
            </div>
            <div className="space-y-2">
              <Badge variant="outline">Windows</Badge>
              <div className="text-sm">
                <p>Download from:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>postgresql.org</li>
                  <li>pgadmin.org</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step 2: Create Database */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Step 2: Create Database
          </CardTitle>
          <CardDescription>Set up the Medicare Plus database</CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto">
            {`# Connect to PostgreSQL as superuser
sudo -u postgres psql

# Create database and user
CREATE DATABASE medicare_plus;
CREATE USER medicare_admin WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE medicare_plus TO medicare_admin;

# Exit PostgreSQL
\\q`}
          </pre>
        </CardContent>
      </Card>

      {/* Step 3: Configure Environment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Step 3: Configure Environment
          </CardTitle>
          <CardDescription>Set up your .env file</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription>
              Create a <code>.env</code> file in your project root with the following:
            </AlertDescription>
          </Alert>
          <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto mt-4">
            {`# PostgreSQL Database Configuration
DATABASE_URL=postgresql://medicare_admin:your_secure_password@localhost:5432/medicare_plus

# Other required environment variables
JWT_SECRET=your-super-secret-jwt-key-here-make-it-long-and-random
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development`}
          </pre>
        </CardContent>
      </Card>

      {/* Step 4: pgAdmin4 Setup */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Step 4: pgAdmin4 Connection
          </CardTitle>
          <CardDescription>Connect to your database using pgAdmin4</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2">Connection Details:</h4>
              <ul className="space-y-1 text-sm">
                <li>
                  <strong>Host:</strong> localhost
                </li>
                <li>
                  <strong>Port:</strong> 5432
                </li>
                <li>
                  <strong>Database:</strong> medicare_plus
                </li>
                <li>
                  <strong>Username:</strong> medicare_admin
                </li>
                <li>
                  <strong>Password:</strong> your_secure_password
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Steps:</h4>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>Open pgAdmin4</li>
                <li>Right-click "Servers"</li>
                <li>Select "Create" → "Server"</li>
                <li>Enter connection details</li>
                <li>Click "Save"</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Troubleshooting */}
      <Alert>
        <AlertDescription>
          <strong>Common Issues:</strong>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>
              PostgreSQL service not running: <code>sudo systemctl start postgresql</code>
            </li>
            <li>Connection refused: Check if PostgreSQL is listening on port 5432</li>
            <li>Authentication failed: Verify username and password</li>
            <li>Database doesn't exist: Make sure you created the database</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  )
}
