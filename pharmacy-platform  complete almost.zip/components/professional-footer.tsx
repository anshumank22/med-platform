"use client"

import { Pill, Phone, Mail, MapPin, Clock, Shield, Award, Users } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function ProfessionalFooter() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Trust Indicators */}
      <div className="bg-gray-800 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Shield className="h-8 w-8 text-green-400 mb-2" />
              <h3 className="font-semibold">100% Secure</h3>
              <p className="text-sm text-gray-400">HIPAA Compliant</p>
            </div>
            <div className="flex flex-col items-center">
              <Award className="h-8 w-8 text-blue-400 mb-2" />
              <h3 className="font-semibold">Verified Doctors</h3>
              <p className="text-sm text-gray-400">Licensed Professionals</p>
            </div>
            <div className="flex flex-col items-center">
              <Users className="h-8 w-8 text-purple-400 mb-2" />
              <h3 className="font-semibold">50,000+ Patients</h3>
              <p className="text-sm text-gray-400">Trust Our Service</p>
            </div>
            <div className="flex flex-col items-center">
              <Clock className="h-8 w-8 text-orange-400 mb-2" />
              <h3 className="font-semibold">24/7 Support</h3>
              <p className="text-sm text-gray-400">Always Available</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="bg-blue-600 text-white p-2 rounded-lg">
                  <Pill className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">MediCare+</h2>
                  <p className="text-sm text-gray-400">Your Health Partner</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                India's most trusted healthcare platform providing comprehensive medical services including
                telemedicine, online pharmacy, lab tests, and expert consultations.
              </p>
              <div className="flex space-x-4">
                <Button size="sm" variant="outline" className="text-white border-gray-600">
                  Download App
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/doctors" className="hover:text-white transition-colors">
                    Find Doctors
                  </Link>
                </li>
                <li>
                  <Link href="/medicines" className="hover:text-white transition-colors">
                    Buy Medicines
                  </Link>
                </li>
                <li>
                  <Link href="/lab-tests" className="hover:text-white transition-colors">
                    Book Lab Tests
                  </Link>
                </li>
                <li>
                  <Link href="/packages" className="hover:text-white transition-colors">
                    Health Packages
                  </Link>
                </li>
                <li>
                  <Link href="/emergency" className="hover:text-white transition-colors">
                    Emergency Care
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
              </ul>
            </div>

            {/* For Professionals */}
            <div>
              <h3 className="text-lg font-semibold mb-4">For Professionals</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/auth/login?role=doctor" className="hover:text-white transition-colors">
                    Doctor Login
                  </Link>
                </li>
                <li>
                  <Link href="/auth/login?role=pharmacist" className="hover:text-white transition-colors">
                    Pharmacist Login
                  </Link>
                </li>
                <li>
                  <Link href="/auth/login?role=delivery" className="hover:text-white transition-colors">
                    Delivery Partner
                  </Link>
                </li>
                <li>
                  <Link href="/auth/login?role=admin" className="hover:text-white transition-colors">
                    Admin Portal
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/partner" className="hover:text-white transition-colors">
                    Partner With Us
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact & Newsletter */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <div className="space-y-3 text-gray-400 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>+91 1800-123-4567</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>support@medicareplus.com</span>
                </div>
                <div className="flex items-start space-x-2">
                  <MapPin className="h-4 w-4 mt-1" />
                  <span>MediCare+ Tower, Bandra Kurla Complex, Mumbai, Maharashtra 400051</span>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-semibold mb-2">Newsletter</h4>
                <p className="text-sm text-gray-400 mb-3">Get health tips and updates</p>
                <div className="flex space-x-2">
                  <Input placeholder="Enter email" className="bg-gray-800 border-gray-700 text-white" />
                  <Button size="sm">Subscribe</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">© 2024 MediCare+. All rights reserved.</div>
            <div className="flex space-x-6 text-sm text-gray-400">
              <Link href="/privacy" className="hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link href="/refund" className="hover:text-white transition-colors">
                Refund Policy
              </Link>
              <Link href="/sitemap" className="hover:text-white transition-colors">
                Sitemap
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-400">Certified by:</span>
              <div className="flex space-x-2">
                <div className="bg-green-600 text-white px-2 py-1 rounded text-xs font-semibold">ISO 27001</div>
                <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-semibold">HIPAA</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
