"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Database, Wifi, WifiOff, AlertTriangle, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface DatabaseHealth {
  status: string
  database: string
  timestamp: string
  version?: string
  error?: string
  mock_mode?: boolean
  connection_pool?: {
    total: number
    idle: number
    waiting: number
  }
}

export function DatabaseStatus() {
  const [health, setHealth] = useState<DatabaseHealth | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    checkHealth()
    const interval = setInterval(checkHealth, 30000) // Check every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const checkHealth = async () => {
    try {
      setIsLoading(true)
      const response = await fetch("/api/health")
      const data = await response.json()
      setHealth(data)

      if (data.database === "connected" && !health?.database) {
        toast({
          title: "Database Connected",
          description: "Successfully connected to PostgreSQL",
        })
      } else if (data.database !== "connected" && health?.database === "connected") {
        toast({
          title: "Database Disconnected",
          description: "Lost connection to PostgreSQL",
          variant: "destructive",
        })
      }
    } catch (error) {
      setHealth({
        status: "error",
        database: "error",
        timestamp: new Date().toISOString(),
        error: "Failed to check database status",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusColor = () => {
    if (!health) return "secondary"
    switch (health.database) {
      case "connected":
        return "default"
      case "mock":
        return "secondary"
      default:
        return "destructive"
    }
  }

  const getStatusIcon = () => {
    if (isLoading) return <RefreshCw className="h-3 w-3 animate-spin" />
    if (!health) return <Database className="h-3 w-3" />

    switch (health.database) {
      case "connected":
        return <Wifi className="h-3 w-3" />
      case "mock":
        return <Database className="h-3 w-3" />
      default:
        return <WifiOff className="h-3 w-3" />
    }
  }

  const getStatusText = () => {
    if (isLoading) return "Checking..."
    if (!health) return "Unknown"

    switch (health.database) {
      case "connected":
        return "PostgreSQL Connected"
      case "mock":
        return "Demo Mode"
      case "disconnected":
        return "Database Offline"
      default:
        return "Connection Error"
    }
  }

  if (!health && !isLoading) return null

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="flex flex-col items-end gap-2">
        {/* Status Badge */}
        <Badge
          variant={getStatusColor()}
          className="flex items-center gap-2 px-3 py-1 cursor-pointer"
          onClick={() => setShowDetails(!showDetails)}
        >
          {getStatusIcon()}
          <span className="text-xs">{getStatusText()}</span>
        </Badge>

        {/* Detailed Status Card */}
        {showDetails && (
          <Card className="w-80 shadow-lg">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-sm">Database Status</h3>
                  <Button size="sm" variant="outline" onClick={checkHealth} disabled={isLoading} className="h-6 px-2">
                    <RefreshCw className={`h-3 w-3 ${isLoading ? "animate-spin" : ""}`} />
                  </Button>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <Badge variant={getStatusColor()} className="text-xs">
                      {health?.database || "Unknown"}
                    </Badge>
                  </div>

                  {health?.version && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Version:</span>
                      <span>{health.version}</span>
                    </div>
                  )}

                  {health?.connection_pool && (
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Pool Total:</span>
                        <span>{health.connection_pool.total}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Pool Idle:</span>
                        <span>{health.connection_pool.idle}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Pool Waiting:</span>
                        <span>{health.connection_pool.waiting}</span>
                      </div>
                    </div>
                  )}

                  {health?.mock_mode && (
                    <div className="flex items-center gap-1 text-amber-600">
                      <AlertTriangle className="h-3 w-3" />
                      <span>Using mock data</span>
                    </div>
                  )}

                  {health?.error && (
                    <div className="text-red-600 text-xs">
                      <strong>Error:</strong> {health.error}
                    </div>
                  )}

                  <div className="flex justify-between text-gray-500">
                    <span>Last Check:</span>
                    <span>{health?.timestamp ? new Date(health.timestamp).toLocaleTimeString() : "Never"}</span>
                  </div>
                </div>

                {health?.database !== "connected" && (
                  <div className="mt-3 p-2 bg-amber-50 rounded text-xs">
                    <strong>Setup Required:</strong>
                    <br />
                    Configure DATABASE_URL in your .env file to connect to PostgreSQL.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
