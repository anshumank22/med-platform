"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Menu, Bell, User, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

interface ResponsiveLayoutProps {
  children: React.ReactNode
  user?: {
    name: string
    role: string
    email: string
  }
  navigation: {
    name: string
    href: string
    icon: React.ComponentType<any>
    current?: boolean
  }[]
  onLogout?: () => void
}

export function ResponsiveLayout({ children, user, navigation, onLogout }: ResponsiveLayoutProps) {
  const [isMobile, setIsMobile] = useState(false)
  const [notifications, setNotifications] = useState(0)

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkScreenSize()
    window.addEventListener("resize", checkScreenSize)

    return () => window.removeEventListener("resize", checkScreenSize)
  }, [])

  const NavigationItems = ({ mobile = false }: { mobile?: boolean }) => (
    <nav className={`${mobile ? "space-y-1" : "space-y-1"}`}>
      {navigation.map((item) => {
        const Icon = item.icon
        return (
          <a
            key={item.name}
            href={item.href}
            className={`
              ${
                item.current
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }
              group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
              ${mobile ? "text-base" : ""}
            `}
          >
            <Icon className={`${mobile ? "mr-4 h-6 w-6" : "mr-3 h-5 w-5"} flex-shrink-0`} />
            {item.name}
          </a>
        )
      })}
    </nav>
  )

  if (isMobile) {
    return (
      <div className="min-h-screen bg-background">
        {/* Mobile header */}
        <div className="bg-background border-b border-border px-4 py-3 flex items-center justify-between">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <div className="py-4">
                <div className="mb-6">
                  <h2 className="text-lg font-semibold">MediCare+</h2>
                  {user && (
                    <p className="text-sm text-muted-foreground">
                      {user.name} ({user.role})
                    </p>
                  )}
                </div>
                <NavigationItems mobile />
              </div>
            </SheetContent>
          </Sheet>

          <h1 className="text-lg font-semibold">MediCare+</h1>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {notifications > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs">
                  {notifications}
                </Badge>
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem onClick={onLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Mobile content */}
        <main className="p-4">{children}</main>
      </div>
    )
  }

  // Desktop layout
  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-background border-r border-border overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-4">
            <h1 className="text-xl font-bold">MediCare+</h1>
          </div>

          {user && (
            <div className="mt-5 px-4 py-3 bg-muted/50">
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-muted-foreground">{user.role}</p>
            </div>
          )}

          <div className="mt-5 flex-grow flex flex-col px-4">
            <NavigationItems />
          </div>

          <div className="flex-shrink-0 flex border-t border-border p-4">
            <div className="flex items-center w-full">
              <Button variant="ghost" size="icon" className="relative mr-2">
                <Bell className="h-5 w-5" />
                {notifications > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs">
                    {notifications}
                  </Badge>
                )}
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex-1 justify-start">
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Settings</DropdownMenuItem>
                  <DropdownMenuItem onClick={onLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      {/* Desktop content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none p-6">{children}</main>
      </div>
    </div>
  )
}
