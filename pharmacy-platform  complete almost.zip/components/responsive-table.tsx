"use client"

import type React from "react"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight } from "lucide-react"

interface Column {
  key: string
  label: string
  render?: (value: any, row: any) => React.ReactNode
  mobileHide?: boolean
}

interface ResponsiveTableProps {
  data: any[]
  columns: Column[]
  title?: string
  emptyMessage?: string
}

export function ResponsiveTable({ data, columns, title, emptyMessage = "No data available" }: ResponsiveTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set())

  const toggleRow = (index: number) => {
    const newExpanded = new Set(expandedRows)
    if (newExpanded.has(index)) {
      newExpanded.delete(index)
    } else {
      newExpanded.add(index)
    }
    setExpandedRows(newExpanded)
  }

  // Mobile card view
  const MobileView = () => (
    <div className="md:hidden space-y-4">
      {title && <h3 className="text-lg font-semibold mb-4">{title}</h3>}
      {data.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center text-muted-foreground">{emptyMessage}</CardContent>
        </Card>
      ) : (
        data.map((row, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  {columns[0].render ? columns[0].render(row[columns[0].key], row) : row[columns[0].key]}
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => toggleRow(index)}>
                  {expandedRows.has(index) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {columns.slice(1, 3).map((column) => (
                  <div key={column.key} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{column.label}:</span>
                    <span>{column.render ? column.render(row[column.key], row) : row[column.key]}</span>
                  </div>
                ))}
              </div>

              {expandedRows.has(index) && (
                <div className="mt-4 pt-4 border-t space-y-2">
                  {columns.slice(3).map((column) => (
                    <div key={column.key} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{column.label}:</span>
                      <span>{column.render ? column.render(row[column.key], row) : row[column.key]}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )

  // Desktop table view
  const DesktopView = () => (
    <div className="hidden md:block">
      {title && <h3 className="text-lg font-semibold mb-4">{title}</h3>}
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={column.key} className={column.mobileHide ? "hidden lg:table-cell" : ""}>
                  {column.label}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="text-center py-8 text-muted-foreground">
                  {emptyMessage}
                </TableCell>
              </TableRow>
            ) : (
              data.map((row, index) => (
                <TableRow key={index}>
                  {columns.map((column) => (
                    <TableCell key={column.key} className={column.mobileHide ? "hidden lg:table-cell" : ""}>
                      {column.render ? column.render(row[column.key], row) : row[column.key]}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )

  return (
    <>
      <MobileView />
      <DesktopView />
    </>
  )
}
