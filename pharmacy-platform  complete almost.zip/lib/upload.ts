// File upload utilities
// import { v2 as cloudinary } from "cloudinary"
// import multer from "multer"

// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// })

// export async function uploadToCloudinary(file: Buffer, folder: string): Promise<string> {
//   return new Promise((resolve, reject) => {
//     cloudinary.uploader
//       .upload_stream(
//         {
//           folder: `medicare-plus/${folder}`,
//           resource_type: "auto",
//         },
//         (error, result) => {
//           if (error) reject(error)
//           else resolve(result!.secure_url)
//         },
//       )
//       .end(file)
//   })
// }

// export const upload = multer({
//   storage: multer.memoryStorage(),
//   limits: {
//     fileSize: 5 * 1024 * 1024, // 5MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "application/pdf"]
//     if (allowedTypes.includes(file.mimetype)) {
//       cb(null, true)
//     } else {
//       cb(new Error("Invalid file type"))
//     }
//   },
// })

// File upload utilities - Simplified version without Cloudinary for now
export async function uploadToCloudinary(file: Buffer, folder: string): Promise<string> {
  // Mock upload for development
  const mockUrl = `/uploads/${folder}/${Date.now()}_${Math.random().toString(36).substr(2, 9)}.jpg`
  console.log("File uploaded to:", mockUrl)
  return mockUrl
}

// Simple file handling without multer
export function validateFile(file: any) {
  const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "application/pdf"]
  const maxSize = 5 * 1024 * 1024 // 5MB

  if (!allowedTypes.includes(file.type)) {
    throw new Error("Invalid file type")
  }

  if (file.size > maxSize) {
    throw new Error("File too large")
  }

  return true
}
