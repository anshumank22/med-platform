// Authentication utilities - Fixed version without problematic JWT dependencies
import bcrypt from "bcryptjs"
import type { User } from "./database"

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

// Simple token generation without JWT for now
export function generateToken(user: Partial<User>): string {
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    timestamp: Date.now(),
  }
  return Buffer.from(JSON.stringify(payload)).toString("base64")
}

export function verifyToken(token: string): any {
  try {
    const payload = JSON.parse(Buffer.from(token, "base64").toString())
    // Check if token is not older than 7 days
    if (Date.now() - payload.timestamp > 7 * 24 * 60 * 60 * 1000) {
      throw new Error("Token expired")
    }
    return payload
  } catch (error) {
    throw new Error("Invalid token")
  }
}

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}
