export async function createPaymentOrder(amount: number, orderId: string) {
  // Mock implementation for development
  console.log("Creating payment order:", { amount, orderId })

  // In production, use actual Razorpay SDK:
  /*
  const Razorpay = require('razorpay')
  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  })

  const options = {
    amount: amount, // amount in paise
    currency: "INR",
    receipt: orderId,
  }

  return await razorpay.orders.create(options)
  */

  // Mock response
  return {
    id: `order_${Date.now()}`,
    amount: amount,
    currency: "INR",
    receipt: orderId,
    status: "created",
  }
}

export function verifyPayment(razorpayOrderId: string, razorpayPaymentId: string, razorpaySignature: string): boolean {
  // Mock verification for development
  console.log("Verifying payment:", {
    razorpayOrderId,
    razorpayPaymentId,
    razorpaySignature,
  })

  // In production, use actual verification:
  /*
  const body = razorpayOrderId + "|" + razorpayPaymentId
  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!)
    .update(body.toString())
    .digest("hex")

  return expectedSignature === razorpaySignature
  */

  // Mock verification - always return true for development
  return true
}

export async function createRefund(paymentId: string, amount?: number) {
  console.log("Creating refund:", { paymentId, amount })

  // Mock refund response
  return {
    id: `rfnd_${Date.now()}`,
    payment_id: paymentId,
    amount: amount,
    status: "processed",
  }
}
