import { Pool, type PoolClient } from "pg"

// Global connection pool
let pool: Pool | null = null
let isConnected = false
let connectionAttempts = 0
const MAX_RETRY_ATTEMPTS = 5

// Initialize database connection with retry logic
async function initializeDatabase() {
  if (pool) {
    return pool
  }

  const databaseUrl = process.env.DATABASE_URL

  if (!databaseUrl) {
    console.warn("⚠️ No DATABASE_URL found in environment variables")
    console.log("📝 Using mock data for development")
    return null
  }

  try {
    console.log("🔄 Attempting to connect to PostgreSQL database...")

    pool = new Pool({
      connectionString: databaseUrl,
      ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
      statement_timeout: 30000,
      query_timeout: 30000,
    })

    // Test the connection
    const client = await pool.connect()
    await client.query("SELECT NOW()")
    client.release()

    isConnected = true
    connectionAttempts = 0
    console.log("✅ Successfully connected to PostgreSQL database")

    // Set up error handlers
    pool.on("error", (err) => {
      console.error("❌ PostgreSQL pool error:", err)
      isConnected = false
    })

    pool.on("connect", () => {
      console.log("🔗 New client connected to PostgreSQL")
    })

    return pool
  } catch (error) {
    console.error(`❌ Database connection failed (attempt ${connectionAttempts + 1}):`, error.message)

    connectionAttempts++
    isConnected = false
    pool = null

    if (connectionAttempts < MAX_RETRY_ATTEMPTS) {
      console.log(`🔄 Retrying connection in 5 seconds... (${connectionAttempts}/${MAX_RETRY_ATTEMPTS})`)
      setTimeout(() => initializeDatabase(), 5000)
    } else {
      console.error("❌ Max connection attempts reached. Using mock data.")
    }

    return null
  }
}

// Initialize on module load
initializeDatabase()

// Enhanced query function with automatic reconnection
export async function query(text: string, params?: any[]): Promise<any> {
  const start = Date.now()

  try {
    // Ensure we have a connection
    if (!pool || !isConnected) {
      await initializeDatabase()
    }

    if (!pool || !isConnected) {
      console.log("📝 Using mock data - database not available")
      return handleMockQuery(text, params)
    }

    const result = await pool.query(text, params)
    const duration = Date.now() - start

    console.log("✅ Query executed successfully:", {
      query: text.substring(0, 100) + (text.length > 100 ? "..." : ""),
      duration: `${duration}ms`,
      rows: result.rowCount,
    })

    return result
  } catch (error) {
    const duration = Date.now() - start
    console.error("❌ Database query error:", {
      query: text.substring(0, 100),
      error: error.message,
      duration: `${duration}ms`,
    })

    // If it's a connection error, try to reconnect
    if (error.message.includes("connection") || error.message.includes("ECONNREFUSED")) {
      console.log("🔄 Connection lost, attempting to reconnect...")
      isConnected = false
      pool = null
      await initializeDatabase()
    }

    // Fallback to mock data
    console.log("📝 Falling back to mock data")
    return handleMockQuery(text, params)
  }
}

// Transaction support with error handling
export async function transaction(callback: (client: PoolClient) => Promise<any>) {
  if (!pool || !isConnected) {
    await initializeDatabase()
  }

  if (!pool || !isConnected) {
    throw new Error("Database connection not available")
  }

  const client = await pool.connect()

  try {
    await client.query("BEGIN")
    const result = await callback(client)
    await client.query("COMMIT")
    console.log("✅ Transaction completed successfully")
    return result
  } catch (error) {
    await client.query("ROLLBACK")
    console.error("❌ Transaction failed, rolled back:", error.message)
    throw error
  } finally {
    client.release()
  }
}

// Enhanced health check
export async function healthCheck() {
  try {
    if (!pool || !isConnected) {
      await initializeDatabase()
    }

    if (!pool || !isConnected) {
      return {
        status: "unhealthy",
        database: "disconnected",
        error: "No database connection available",
        timestamp: new Date().toISOString(),
        mock_mode: true,
      }
    }

    const result = await pool.query("SELECT NOW() as timestamp, version() as version")
    const dbInfo = result.rows[0]

    return {
      status: "healthy",
      database: "connected",
      timestamp: dbInfo.timestamp,
      version: dbInfo.version.split(" ")[0] + " " + dbInfo.version.split(" ")[1],
      connection_pool: {
        total: pool.totalCount,
        idle: pool.idleCount,
        waiting: pool.waitingCount,
      },
    }
  } catch (error) {
    console.error("❌ Health check failed:", error.message)
    return {
      status: "unhealthy",
      database: "error",
      error: error.message,
      timestamp: new Date().toISOString(),
    }
  }
}

// Mock data handler for development/fallback
function handleMockQuery(sql: string, params: any[] = []) {
  console.log("🔄 Mock query:", sql.substring(0, 50) + "...")

  // Mock responses for common queries
  if (sql.includes("SELECT * FROM medicines") || sql.includes("SELECT m.* FROM medicines")) {
    return {
      rows: [
        {
          id: "med-1",
          name: "Paracetamol 500mg",
          generic_name: "Acetaminophen",
          manufacturer: "Sun Pharma",
          category: "Pain Relief",
          price: 25.0,
          description: "Effective pain relief and fever reducer",
          dosage_form: "Tablet",
          strength: "500mg",
          requires_prescription: false,
          is_active: true,
          stock_quantity: 100,
          image_url: "/placeholder.svg?height=200&width=200",
        },
        {
          id: "med-2",
          name: "Amoxicillin 250mg",
          generic_name: "Amoxicillin",
          manufacturer: "Cipla",
          category: "Antibiotics",
          price: 85.0,
          description: "Broad-spectrum antibiotic",
          dosage_form: "Capsule",
          strength: "250mg",
          requires_prescription: true,
          is_active: true,
          stock_quantity: 50,
          image_url: "/placeholder.svg?height=200&width=200",
        },
        {
          id: "med-3",
          name: "Cetirizine 10mg",
          generic_name: "Cetirizine",
          manufacturer: "Dr. Reddy's",
          category: "Allergy",
          price: 45.0,
          description: "Antihistamine for allergy relief",
          dosage_form: "Tablet",
          strength: "10mg",
          requires_prescription: false,
          is_active: true,
          stock_quantity: 75,
          image_url: "/placeholder.svg?height=200&width=200",
        },
      ],
    }
  }

  if (sql.includes("SELECT * FROM users WHERE email")) {
    const email = params?.[0]
    if (email === "admin@medicare.com") {
      return {
        rows: [
          {
            id: "admin-1",
            email: "admin@medicare.com",
            password_hash: "$2b$10$hashedpassword",
            role: "admin",
            first_name: "Admin",
            last_name: "User",
            phone: "+1234567890",
            is_verified: true,
            is_active: true,
          },
        ],
      }
    }
    return { rows: [] }
  }

  if (sql.includes("SELECT * FROM doctors")) {
    return {
      rows: [
        {
          id: "doc-1",
          user_id: "user-doc-1",
          first_name: "Dr. Sarah",
          last_name: "Johnson",
          specialization: "Cardiologist",
          experience_years: 10,
          consultation_fee: 500,
          rating: 4.8,
          availability_status: "available",
          bio: "Experienced cardiologist with 10+ years of practice",
        },
      ],
    }
  }

  if (sql.includes("COUNT(*)")) {
    return { rows: [{ count: "0" }] }
  }

  // Default empty response
  return { rows: [] }
}

// Database connection status
export function getDatabaseStatus() {
  return {
    connected: isConnected,
    pool: pool !== null,
    attempts: connectionAttempts,
  }
}

// Force reconnection
export async function reconnectDatabase() {
  console.log("🔄 Forcing database reconnection...")
  isConnected = false
  connectionAttempts = 0

  if (pool) {
    await pool.end()
    pool = null
  }

  return await initializeDatabase()
}

export default pool

// Database schema types (keeping existing types)
export interface User {
  id: string
  email: string
  password_hash: string
  role: "customer" | "doctor" | "pharmacist" | "delivery" | "admin"
  first_name: string
  last_name: string
  phone: string
  address?: string
  city?: string
  state?: string
  pincode?: string
  is_verified: boolean
  is_active: boolean
  created_at: Date
  updated_at: Date
}

export interface Medicine {
  id: string
  name: string
  generic_name?: string
  manufacturer: string
  category: string
  price: number
  description?: string
  side_effects?: string[]
  dosage_form: string
  strength: string
  requires_prescription: boolean
  is_active: boolean
  image_url?: string
  stock_quantity?: number
}

export interface Doctor {
  id: string
  user_id: string
  license_number: string
  specialization: string
  experience_years: number
  consultation_fee: number
  rating: number
  total_consultations: number
  availability_status: "available" | "busy" | "offline"
  bio?: string
  education?: string
  certifications?: string[]
}
