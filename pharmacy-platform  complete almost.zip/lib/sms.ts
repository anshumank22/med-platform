// SMS service - Simplified version without Twilio for now
export async function sendSMS(to: string, message: string) {
  try {
    // For development, just log the SMS
    console.log(`SMS to ${to}: ${message}`)
    // In production, integrate with SMS service like Twilio, AWS SNS, etc.
  } catch (error) {
    console.error("SMS sending failed:", error)
    throw error
  }
}

export async function sendOTPSMS(phone: string, otp: string) {
  const message = `Your MediCare+ verification code is: ${otp}. Valid for 10 minutes.`
  await sendSMS(phone, message)
}

export async function sendDeliveryUpdate(phone: string, orderId: string, status: string) {
  const message = `MediCare+ Order Update: Your order #${orderId} is now ${status}. Track: https://medicareplus.com/track/${orderId}`
  await sendSMS(phone, message)
}
