// Email service - Simplified version without nodemailer for now
export async function sendEmail(to: string, subject: string, html: string) {
  try {
    // For development, just log the email
    console.log(`Email to ${to}: ${subject}`)
    console.log(html)
    // In production, integrate with email service like SendGrid, AWS SES, etc.
  } catch (error) {
    console.error("Email sending failed:", error)
    throw error
  }
}

export async function sendOTPEmail(email: string, otp: string) {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>MediCare+ Verification Code</h2>
      <p>Your verification code is:</p>
      <div style="background: #f0f0f0; padding: 20px; text-align: center; font-size: 24px; font-weight: bold; margin: 20px 0;">
        ${otp}
      </div>
      <p>This code will expire in 10 minutes.</p>
      <p>If you didn't request this code, please ignore this email.</p>
    </div>
  `
  await sendEmail(email, "MediCare+ Verification Code", html)
}

export async function sendAppointmentConfirmation(email: string, appointmentDetails: any) {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Appointment Confirmed</h2>
      <p>Your appointment has been confirmed with the following details:</p>
      <div style="background: #f9f9f9; padding: 20px; margin: 20px 0;">
        <p><strong>Doctor:</strong> ${appointmentDetails.doctorName}</p>
        <p><strong>Date:</strong> ${appointmentDetails.date}</p>
        <p><strong>Time:</strong> ${appointmentDetails.time}</p>
        <p><strong>Type:</strong> ${appointmentDetails.type}</p>
        <p><strong>Fee:</strong> ₹${appointmentDetails.fee}</p>
      </div>
      <p>Please join the consultation 5 minutes before the scheduled time.</p>
    </div>
  `
  await sendEmail(email, "Appointment Confirmation - MediCare+", html)
}
